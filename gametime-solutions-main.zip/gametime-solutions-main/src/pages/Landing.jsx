
import React from "react";
import LandingHeader from "@/components/landing/Header";
import Hero from "@/components/landing/Hero";
import Solutions from "@/components/landing/Solutions";
import AbwabShowcase from "@/components/landing/AbwabShowcase";
import WhyChooseUs from "@/components/landing/WhyChooseUs";
import Team from "@/components/landing/Team";
import Contact from "@/components/landing/Contact";
// import CTA from "@/components/landing/CTA"; // removed
import Footer from "@/components/landing/Footer";

export default function Landing() {
  return (
    <div className="min-h-screen bg-white">
      <LandingHeader />
      <main className="scroll-smooth">
        <Hero />
        <Solutions />
        <AbwabShowcase />
        <WhyChooseUs />
        <Team />
        <Contact />
        {/* <CTA /> merged into AbwabShowcase */}
      </main>
      <Footer />
    </div>
  );
}
