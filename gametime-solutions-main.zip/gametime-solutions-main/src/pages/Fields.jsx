import React from "react";
import CamerasPage from "./Cameras";

export default function Fields() {
  return <CamerasPage />;
}