
import React, { useState, useEffect, useCallback } from "react";
import { User } from "@/api/entities";
import { Academy } from "@/api/entities";
import { Team } from "@/api/entities";
import { Match } from "@/api/entities";
import { Camera } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { createMatch } from "@/api/functions";
import { useToast } from "@/components/ui/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const initialFormData = {
  home_team_id: "",
  away_team_id: "",
  match_date: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
  recording_system_id: "",
  duration: 110,
  status: "planned",
};

export default function NewMatch() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [academy, setAcademy] = useState(null);
  const [teams, setTeams] = useState([]);
  const [cameras, setCameras] = useState([]);
  const [formData, setFormData] = useState(initialFormData);
  const [isCreating, setIsCreating] = useState(false);
  const [showDialog, setShowDialog] = useState(true);

  useEffect(() => {
    // Preselect from URL params if provided
    const urlParams = new URLSearchParams(window.location.search);
    const homeId = urlParams.get('home_team_id');
    const awayId = urlParams.get('away_team_id');
    const recId = urlParams.get('recording_system_id');
    setFormData(prev => ({
      ...prev,
      home_team_id: homeId || prev.home_team_id,
      away_team_id: awayId || prev.away_team_id,
      recording_system_id: recId || prev.recording_system_id
    }));
  }, []); // Run once on mount to read URL params

  const loadData = useCallback(async () => {
    try {
      const user = await User.me();
      const academies = await Academy.filter({ coach_email: user.email });
      if (academies.length > 0) {
        const currentAcademy = academies[0];
        setAcademy(currentAcademy);
        
        const [academyTeams, academyCameras] = await Promise.all([
          Team.filter({ academy_id: currentAcademy.id }),
          Camera.filter({ academy_id: currentAcademy.id })
        ]);
        
        // Restrict teams for coaches to assigned_team_ids if present
        let filteredTeams = academyTeams;
        const assigned = Array.isArray(user.assigned_team_ids) ? new Set(user.assigned_team_ids) : null;
        if ((user.role === 'user' || user.role === 'coach') && assigned && assigned.size > 0) {
          filteredTeams = academyTeams.filter(t => assigned.has(t.id));
        }
        setTeams(filteredTeams);

        setCameras(academyCameras);
      }
    } catch (error) {
      console.error("Could not load data", error);
      toast({
        variant: "destructive",
        title: "Loading Error",
        description: "Error: could not load academy data."
      });
    }
  }, [toast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!academy) {
      toast({
        variant: "destructive",
        title: "Configuration Error",
        description: "Your academy is not configured."
      });
      return;
    }
    
    if (!formData.home_team_id || !formData.away_team_id) {
      toast({
        variant: "destructive",
        title: "Selection Required",
        description: "Please select both a home and away team."
      });
      return;
    }
    
    if (formData.home_team_id === formData.away_team_id) {
      toast({
        variant: "destructive",
        title: "Invalid Selection",
        description: "Home and away teams cannot be the same."
      });
      return;
    }

    if (!formData.recording_system_id) {
      toast({
        variant: "destructive",
        title: "Field Required",
        description: "Please select a field/recording system."
      });
      return;
    }

    setIsCreating(true);
    try {
      const homeTeam = teams.find(t => t.id === formData.home_team_id);
      const awayTeam = teams.find(t => t.id === formData.away_team_id);

      // Calculate end time based on duration
      const startTime = new Date(formData.match_date);
      const endTime = new Date(startTime.getTime() + (formData.duration * 60 * 1000));

      // Create match via Abwab service
      const { data: abwabMatch, error } = await createMatch({
        team_home_id: homeTeam.abwab_team_id,
        team_home_name: homeTeam.name,
        team_away_id: awayTeam.abwab_team_id,
        team_away_name: awayTeam.name,
        start_time: startTime.toISOString(),
        end_time_calendar: endTime.toISOString(),
        recording_system_id: formData.recording_system_id,
        duration: formData.duration
      });

      if (error || !abwabMatch?.abwab_match_id) {
        console.error("Match creation failed:", error); 
        toast({
          variant: "destructive",
          title: "Match Creation Failed",
          description: `Could not create match: ${error?.details || 'Unknown error'}`
        });
        return;
      }

      // Save match in our database
      const matchPayload = {
        ...formData,
        academy_id: academy.id,
        home_team_name: homeTeam.name,
        away_team_name: awayTeam.name,
        abwab_match_id: abwabMatch.abwab_match_id,
        start_time_utc: startTime.toISOString(), 
        end_time_utc: endTime.toISOString() 
      };

      await Match.create(matchPayload);
      
      toast({
        title: "Match Created",
        description: "Match has been successfully scheduled!"
      });
      
      navigate(createPageUrl("Matches"));
    } catch (error) {
      console.error("Error creating match:", error);
      toast({
        variant: "destructive",
        title: "Creation Failed",
        description: `Failed to create match: ${error.message}`
      });
    }
    setIsCreating(false);
  };

  const handleClose = () => {
    setShowDialog(false);
    navigate(createPageUrl("Matches"));
  };

  return (
    <Dialog open={showDialog} onOpenChange={setShowDialog}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-white">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle className="text-2xl font-bold text-slate-900">Schedule New Match</DialogTitle>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={handleClose}
            className="text-slate-500 hover:text-slate-700"
          >
            <X className="w-5 h-5" />
          </Button>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 pt-4">
          {/* Teams Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label className="text-slate-700 font-medium">Home Team*</Label>
              <Select onValueChange={(value) => handleChange('home_team_id', value)} value={formData.home_team_id}>
                <SelectTrigger><SelectValue placeholder="Choose home team" /></SelectTrigger>
                <SelectContent>
                  {teams.map(team => (<SelectItem key={team.id} value={team.id}>{team.name}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-slate-700 font-medium">Away Team*</Label>
              <Select onValueChange={(value) => handleChange('away_team_id', value)} value={formData.away_team_id}>
                <SelectTrigger><SelectValue placeholder="Choose away team" /></SelectTrigger>
                <SelectContent>
                  {teams.map(team => (<SelectItem key={team.id} value={team.id}>{team.name}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Match Details Section */}
          <Card className="border border-slate-200">
            <CardContent className="p-6 space-y-4">
              <h3 className="font-semibold text-lg text-slate-900">Match Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label className="text-slate-700 font-medium">Start Time*</Label>
                  <Input 
                    type="datetime-local" 
                    value={formData.match_date} 
                    onChange={(e) => handleChange('match_date', e.target.value)} 
                    required 
                  />
                </div>
                <div>
                  <Label className="text-slate-700 font-medium">Duration (minutes)*</Label>
                  <Input 
                    type="number"
                    min="30"
                    max="300"
                    value={formData.duration} 
                    onChange={(e) => handleChange('duration', parseInt(e.target.value) || 110)} 
                    required 
                  />
                </div>
                <div className="md:col-span-2">
                  <Label className="text-slate-700 font-medium">Field (Recording System)*</Label>
                  <Select onValueChange={(value) => handleChange('recording_system_id', value)} value={formData.recording_system_id}>
                    <SelectTrigger><SelectValue placeholder="Select field/camera" /></SelectTrigger>
                    <SelectContent>
                      {cameras.map(camera => (
                        <SelectItem key={camera.id} value={camera.abwab_camera_id}>
                          {camera.name} {camera.location && `- ${camera.location}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {cameras.length === 0 && (
                    <p className="text-sm text-slate-500 mt-1">
                      No recording systems found. Please visit the <button type="button" onClick={() => navigate(createPageUrl("Cameras"))} className="text-blue-600 underline">Cameras page</button> to sync your systems.
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-4 pt-4">
            <Button type="button" variant="outline" onClick={handleClose}>Cancel</Button>
            <Button type="submit" disabled={isCreating} className="flex-1 text-white" style={{ backgroundColor: "var(--brand-green)" }}>
              {isCreating ? "Scheduling Match..." : "Schedule Match"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
