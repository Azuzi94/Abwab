
import React, { useEffect, useMemo, useState } from "react";
import { User } from "@/api/entities";
import { Academy } from "@/api/entities";
import { Team } from "@/api/entities";
import { Player } from "@/api/entities";
import { CoachPlayer } from "@/api/entities";
import { UserInvite } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Users, UserPlus, Shield } from "lucide-react";
import { createPageUrl } from "@/utils";
// import { SendEmail } from "@/api/integrations"; // Removed SendEmail import

export default function Coaches() {
  const [me, setMe] = useState(null);
  const [academy, setAcademy] = useState(null);
  const [coaches, setCoaches] = useState([]);
  const [teams, setTeams] = useState([]);
  const [players, setPlayers] = useState([]);
  const [loading, setLoading] = useState(true);

  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState(null);
  const [teamSelection, setTeamSelection] = useState(new Set());
  const [playerSelection, setPlayerSelection] = useState(new Set());
  const [assignOpen, setAssignOpen] = useState(false);

  const [inviteOpen, setInviteOpen] = useState(false);

  // New invite form state
  const [inviteForm, setInviteForm] = useState({
    full_name: "",
    email: "",
    app_role: "coach"
  });
  const [inviting, setInviting] = useState(false);

  const canManage = (u) => u && (u.role === "admin" || u.app_role === "academy_admin");

  const loadData = async () => {
    setLoading(true);
    const u = await User.me();
    setMe(u);
    if (!canManage(u)) {
      setLoading(false);
      return;
    }
    let acad = null;
    if (u.academy_id) {
      acad = { id: u.academy_id };
    } else {
      const found = await Academy.filter({ coach_email: u.email });
      acad = found[0] || null;
    }
    setAcademy(acad);
    if (acad) {
      const [academyUsers, academyTeams, academyPlayers] = await Promise.all([
        User.filter({ academy_id: acad.id }),
        Team.filter({ academy_id: acad.id }),
        Player.filter({ academy_id: acad.id })
      ]);
      setCoaches(academyUsers || []);
      setTeams(academyTeams || []);
      setPlayers(academyPlayers || []);
    }
    setLoading(false);
  };

  useEffect(() => { loadData(); }, []);

  const filteredCoaches = useMemo(() => {
    const s = search.toLowerCase();
    return coaches.filter(c =>
      (c.full_name || "").toLowerCase().includes(s) ||
      (c.email || "").toLowerCase().includes(s) ||
      (c.app_role || "").toLowerCase().includes(s)
    );
  }, [coaches, search]);

  const openAssign = async (coach) => {
    setEditing(coach);
    // Teams from user
    const tset = new Set(coach.assigned_team_ids || []);
    setTeamSelection(tset);
    // Players from CoachPlayer
    const links = await CoachPlayer.filter({ academy_id: academy.id, user_id: coach.id });
    setPlayerSelection(new Set(links.map(l => l.player_id)));
    setAssignOpen(true);
  };

  const toggleTeam = (id) => {
    setTeamSelection(prev => {
      const ns = new Set(prev);
      ns.has(id) ? ns.delete(id) : ns.add(id);
      return ns;
    });
  };

  const togglePlayer = (id) => {
    setPlayerSelection(prev => {
      const ns = new Set(prev);
      ns.has(id) ? ns.delete(id) : ns.add(id);
      return ns;
    });
  };

  const saveAssignments = async () => {
    if (!editing || !academy) return;
    // Update user assigned teams
    await User.update(editing.id, { assigned_team_ids: Array.from(teamSelection) });

    // Sync CoachPlayer mappings
    const existing = await CoachPlayer.filter({ academy_id: academy.id, user_id: editing.id });
    const existingSet = new Set(existing.map(e => e.player_id));
    const newSet = playerSelection;

    // Create new links
    for (const pid of newSet) {
      if (!existingSet.has(pid)) {
        await CoachPlayer.create({ academy_id: academy.id, user_id: editing.id, player_id: pid });
      }
    }
    // Delete removed links
    for (const link of existing) {
      if (!newSet.has(link.player_id)) {
        await CoachPlayer.delete(link.id);
      }
    }

    setAssignOpen(false);
    setEditing(null);
    loadData();
  };

  const handleInviteChange = (k, v) => setInviteForm(prev => ({ ...prev, [k]: v }));

  const submitInvite = async () => {
    if (!academy) return;
    if (!inviteForm.email) {
      alert("Please enter an email to invite.");
      return;
    }
    setInviting(true);
    try {
      // Create invite record with pre-selections
      await UserInvite.create({
        academy_id: academy.id,
        email: inviteForm.email.trim().toLowerCase(),
        full_name: inviteForm.full_name || null,
        app_role: inviteForm.app_role,
        assigned_team_ids: Array.from(teamSelection),
        preassigned_player_ids: Array.from(playerSelection),
        status: "pending",
        invited_by_user_id: me?.id || null,
        invited_by_email: me?.email || null
      });

      // Build a shareable link and invitation text (no external email send)
      const accessUrl = new URL(createPageUrl("Access"), window.location.origin).toString();
      const shareText =
`Hello${inviteForm.full_name ? " " + inviteForm.full_name : ""},

You've been invited to join ${academy.name || "our academy"} on Gametime Solutions as "${inviteForm.app_role}".

To get started:
1) Click this link: ${accessUrl}
2) Sign in with your Google account using this email (${inviteForm.email})
3) You'll be automatically linked to the academy.

Assigned on invite:
- Teams: ${Array.from(teamSelection).length}
- Players: ${Array.from(playerSelection).length}

See you inside!`;

      // Try to copy to clipboard for convenience
      try { await navigator.clipboard.writeText(shareText); } catch (e) {
        console.warn("Failed to copy to clipboard:", e);
      }

      setInviteOpen(false);
      setInviteForm({ full_name: "", email: "", app_role: "coach" });
      setTeamSelection(new Set());
      setPlayerSelection(new Set());

      alert("Invite created. Share the Access link with the coach.\n\nThe invitation message was copied to your clipboard.");
    } catch (error) {
      console.error("Failed to create invite:", error);
      alert("Failed to create invite. Please try again.");
    } finally {
      setInviting(false);
    }
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (!canManage(me)) {
    return (
      <div className="min-h-screen bg-slate-50">
        <div className="p-6">
          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-8 text-center">
              <Shield className="w-8 h-8 mx-auto text-slate-400 mb-2" />
              <h2 className="text-xl font-semibold text-slate-900">Not Authorized</h2>
              <p className="text-slate-600 mt-1">You need academy admin access to view this page.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="p-4 lg:p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Coach Management</h1>
              <p className="text-slate-600">Assign teams and players to your coaches.</p>
            </div>
            <Button onClick={() => { setInviteOpen(true); setTeamSelection(new Set()); setPlayerSelection(new Set());}} variant="outline" className="gap-2">
              <UserPlus className="w-4 h-4" /> Invite Coach
            </Button>
          </div>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2 text-slate-600">
                  <Users className="w-4 h-4" />
                  <span>{filteredCoaches.length} users</span>
                </div>
                <Input
                  placeholder="Search by name, email, or role..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="max-w-xs"
                />
              </div>

              <div className="grid gap-3">
                {filteredCoaches.map((c) => (
                  <div key={c.id} className="flex items-center justify-between p-4 border rounded-lg bg-white">
                    <div className="min-w-0">
                      <div className="font-semibold text-slate-900 truncate">{c.full_name || c.email}</div>
                      <div className="text-sm text-slate-600 truncate">{c.email}</div>
                      <div className="mt-1 flex gap-2 flex-wrap">
                        <Badge variant="secondary">{c.app_role || "coach"}</Badge>
                        {(c.assigned_team_ids || []).slice(0, 3).map(tid => {
                          const t = teams.find(tm => tm.id === tid);
                          return <Badge key={tid} className="bg-blue-50 text-blue-700 border border-blue-200">{t?.name || "Team"}</Badge>;
                        })}
                        {(c.assigned_team_ids || []).length > 3 && (
                          <Badge variant="outline">+{(c.assigned_team_ids || []).length - 3} teams</Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={c.is_active ? "default" : "secondary"}>{c.is_active ? "Active" : "Inactive"}</Badge>
                      <Button size="sm" onClick={() => openAssign(c)}>Assign</Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Assign Modal */}
      <Dialog open={assignOpen} onOpenChange={setAssignOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Assign Teams & Players {editing ? `• ${editing.full_name || editing.email}` : ""}</DialogTitle>
          </DialogHeader>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-2">Teams</h4>
              <div className="max-h-64 overflow-y-auto border rounded-md p-3 space-y-2">
                {teams.length === 0 ? <p className="text-sm text-slate-500">No teams available.</p> :
                  teams.map(t => (
                    <label key={t.id} className="flex items-center gap-2 text-sm">
                      <Checkbox checked={teamSelection.has(t.id)} onCheckedChange={() => toggleTeam(t.id)} />
                      <span>{t.name}</span>
                    </label>
                  ))}
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Players</h4>
              <div className="max-h-64 overflow-y-auto border rounded-md p-3 space-y-2">
                {players.length === 0 ? <p className="text-sm text-slate-500">No players available.</p> :
                  players.map(p => (
                    <label key={p.id} className="flex items-center gap-2 text-sm">
                      <Checkbox checked={playerSelection.has(p.id)} onCheckedChange={() => togglePlayer(p.id)} />
                      <span>{p.first_name} {p.last_name} {p.jersey_number ? `(#${p.jersey_number})` : ""}</span>
                    </label>
                  ))}
              </div>
            </div>
          </div>
          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setAssignOpen(false)}>Cancel</Button>
            <Button onClick={saveAssignments}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Invite Coach Modal (now fully functional) */}
      <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Invite a Coach</DialogTitle>
          </DialogHeader>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <div>
                <Label htmlFor="invite-full-name">Full name</Label>
                <Input
                  id="invite-full-name"
                  value={inviteForm.full_name}
                  onChange={(e) => handleInviteChange("full_name", e.target.value)}
                  placeholder="Optional"
                />
              </div>
              <div>
                <Label htmlFor="invite-email">Email</Label>
                <Input
                  id="invite-email"
                  type="email"
                  value={inviteForm.email}
                  onChange={(e) => handleInviteChange("email", e.target.value)}
                  placeholder="coach@example.com"
                  required
                />
              </div>
              <div>
                <Label htmlFor="invite-role">Role</Label>
                <Select value={inviteForm.app_role} onValueChange={(v) => handleInviteChange("app_role", v)}>
                  <SelectTrigger id="invite-role"><SelectValue placeholder="Select a role" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="coach">Coach</SelectItem>
                    <SelectItem value="academy_admin">Academy Admin</SelectItem>
                    <SelectItem value="analyst">Analyst</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Pre-assign Teams</h4>
                <div className="max-h-40 overflow-y-auto border rounded-md p-3 space-y-2">
                  {teams.length === 0 ? <p className="text-sm text-slate-500">No teams available to pre-assign.</p> :
                    teams.map(t => (
                      <label key={t.id} className="flex items-center gap-2 text-sm">
                        <Checkbox checked={teamSelection.has(t.id)} onCheckedChange={() => toggleTeam(t.id)} />
                        <span>{t.name}</span>
                      </label>
                    ))}
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Pre-assign Players</h4>
                <div className="max-h-40 overflow-y-auto border rounded-md p-3 space-y-2">
                  {players.length === 0 ? <p className="text-sm text-slate-500">No players available to pre-assign.</p> :
                    players.map(p => (
                      <label key={p.id} className="flex items-center gap-2 text-sm">
                        <Checkbox checked={playerSelection.has(p.id)} onCheckedChange={() => togglePlayer(p.id)} />
                        <span>{p.first_name} {p.last_name} {p.jersey_number ? `(#${p.jersey_number})` : ""}</span>
                      </label>
                    ))}
                </div>
              </div>
            </div>
          </div>

          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setInviteOpen(false)}>Cancel</Button>
            <Button onClick={submitInvite} disabled={inviting || !inviteForm.email}>
              {inviting ? "Sending..." : "Send Invite"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
