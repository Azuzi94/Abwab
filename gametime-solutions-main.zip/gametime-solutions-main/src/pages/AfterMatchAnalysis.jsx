
import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Play, Clock, Users, Activity, Eye, CheckCircle2, 
  AlertCircle, Loader, RefreshCw, BarChart3, ListVideo, PlayCircle
} from "lucide-react";
import { Match } from "@/api/entities";
import { Team } from "@/api/entities"; // Added
import { TrackingJob } from "@/api/entities";
import { User } from "@/api/entities";
import { AuditLog } from "@/api/entities"; // Added
import { afterMatchAnalysis } from "@/api/functions";
import { useToast } from "@/components/ui/use-toast";

import TrackingJobCard from "../components/analysis/TrackingJobCard";
import ReviewInterface from "../components/analysis/ReviewInterface";
import PlayerStatsView from "../components/analysis/PlayerStatsView";

export default function AfterMatchAnalysis() {
  const [matches, setMatches] = useState([]);
  const [teams, setTeams] = useState([]); // Added
  const [trackingJobs, setTrackingJobs] = useState([]);
  const [selectedJob, setSelectedJob] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isCreatingJob, setIsCreatingJob] = useState(false); // Added
  const [activeTab, setActiveTab] = useState("jobs");
  const { toast } = useToast();
  const [searchParams, setSearchParams] = useSearchParams(); // Added

  const addAudit = useCallback(async (action, entityId, payload = {}) => {
    try {
      const user = await User.me();
      if (!user?.id || !user?.data?.academy_id) {
        console.warn("Audit log: User or academy ID not found.");
        return;
      }
      await AuditLog.create({
        academy_id: user.data.academy_id,
        actor_user_id: user.id,
        action,
        entity: "TrackingJob",
        entity_id: entityId || null,
        payload_json: payload,
        created_at: new Date().toISOString()
      });
    } catch (e) {
      console.error("Audit log failed:", e);
    }
  }, []);

  const handleCreateJob = useCallback(async (match) => {
    if (!match || isCreatingJob) return;

    setIsCreatingJob(true);
    toast({ title: "Creating tracking job...", description: "This may take a moment." });
    try {
      const homeTeam = teams.find(t => t.id === match.home_team_id);
      const awayTeam = teams.find(t => t.id === match.away_team_id);
      
      if (!homeTeam?.abwab_team_id || !awayTeam?.abwab_team_id) {
          throw new Error("Home or away team is missing the required external ID (abwab_team_id).");
      }

      const { data, error } = await afterMatchAnalysis({
        action: 'create-tracking-job',
        match_id: match.abwab_match_id,
        team_data: {
          home_team: { _id: homeTeam.abwab_team_id, name: homeTeam.name, club_id: homeTeam.club_id },
          away_team: { _id: awayTeam.abwab_team_id, name: awayTeam.name, club_id: awayTeam.club_id },
        }
      });

      if (error || !data?.success) {
        throw new Error(data?.message || error?.details || "Failed to create job.");
      }
      
      await addAudit("create", data.tracking_job.id, { match_id: match.id, external_job_id: data.tracking_job.external_job_id });

      toast({
        title: "Success!",
        description: `Tracking job for match "${match.home_team_name} vs ${match.away_team_name}" created.`,
      });

      // Refresh data and switch to the new job
      const user = await User.me();
      const academyId = user.data?.academy_id;
      const newJobs = await TrackingJob.filter({ academy_id: academyId }, '-created_at');
      setTrackingJobs(newJobs);
      const newJob = newJobs.find(j => j.id === data.tracking_job.id);
      if (newJob) {
        setActiveTab("jobs");
        setSelectedJob(newJob);
      }
    } catch (err) {
      console.error(err);
      toast({ variant: "destructive", title: "Error", description: err.message });
    } finally {
      setIsCreatingJob(false);
    }
  }, [teams, isCreatingJob, toast, addAudit]);

  const loadData = useCallback(async () => {
    setIsLoading(true);
    try {
      const user = await User.me();
      const academyId = user.data?.academy_id;
      if (!academyId) throw new Error("User academy not found.");

      const [userMatches, userTeams, jobs] = await Promise.all([
        Match.filter({ academy_id: academyId, status: "finished" }, '-match_date'),
        Team.filter({ academy_id: academyId }),
        TrackingJob.filter({ academy_id: academyId }, '-created_at')
      ]);

      setMatches(userMatches);
      setTeams(userTeams);
      setTrackingJobs(jobs);

      const matchIdFromUrl = searchParams.get('match_id');
      if (matchIdFromUrl) {
        const targetMatch = userMatches.find(m => m.id === matchIdFromUrl);
        if (targetMatch) {
          const existingJob = jobs.find(j => j.match_id === targetMatch.id);
          if (existingJob) {
            setSelectedJob(existingJob);
            setActiveTab("jobs"); // Keep on jobs tab to see the created job
          } else {
            // Automatically create the job if it doesn't exist
            await handleCreateJob(targetMatch);
          }
        }
        // Clean up URL param
        setSearchParams({}, { replace: true });
      }

    } catch (error) {
      console.error("Error loading analysis data:", error);
      toast({ variant: "destructive", title: "Loading Failed", description: error.message || "An unknown error occurred." });
    } finally {
      setIsLoading(false);
    }
  }, [toast, searchParams, setSearchParams, handleCreateJob]);

  useEffect(() => {
    loadData();
  }, [loadData]); // Added loadData to dependency array as it's a stable callback now

  const refreshJobStatus = async (jobId) => {
    try {
      const { data: response, error } = await afterMatchAnalysis({
        action: 'job-status',
        job_id: jobId
      });

      if (error) {
        toast({
          variant: "destructive",
          title: "Status Check Failed",
          description: error.details || "Failed to check job status"
        });
        return;
      }

      await loadData(); // Refresh the list
      
      if (response.job_status.status === 'REVIEW_REQUIRED') {
        toast({
          title: "Review Required",
          description: "Tracking is complete. Player assignment review needed."
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to check job status"
      });
    }
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      'PENDING': { color: 'bg-yellow-100 text-yellow-800', icon: Clock },
      'PROCESSING': { color: 'bg-blue-100 text-blue-800', icon: Loader },
      'REVIEW_REQUIRED': { color: 'bg-orange-100 text-orange-800', icon: Eye },
      'FINALIZED': { color: 'bg-green-100 text-green-800', icon: CheckCircle2 },
      'FAILED': { color: 'bg-red-100 text-red-800', icon: AlertCircle }
    };

    const config = statusConfig[status] || statusConfig['PENDING'];
    const Icon = config.icon;

    return (
      <Badge className={config.color}>
        <Icon className="w-3 h-3 mr-1" />
        {status.replace('_', ' ')}
      </Badge>
    );
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex items-center gap-2">
          <Loader className="w-6 h-6 animate-spin" />
          <span>Loading analysis data...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-slate-900">After-Match Analysis</h1>
            <p className="text-slate-600">
              Track player movements and generate physical performance statistics
            </p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="jobs">
                <ListVideo className="w-4 h-4 mr-2" />
                Tracking Jobs
              </TabsTrigger>
              <TabsTrigger value="review">
                <Eye className="w-4 h-4 mr-2" />
                Review Interface
              </TabsTrigger>
              <TabsTrigger value="stats">
                <BarChart3 className="w-4 h-4 mr-2" />
                Player Stats
              </TabsTrigger>
            </TabsList>

            <TabsContent value="jobs">
              <div className="space-y-6">
                {/* Matches without tracking jobs */}
                <Card>
                  <CardHeader>
                    <CardTitle>Available Matches</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {matches
                        .filter(match => !trackingJobs.find(job => job.match_id === match.id))
                        .map(match => (
                        <Card key={match.id} className="border-dashed">
                          <CardContent className="p-4">
                            <div className="space-y-3">
                              <div>
                                <h4 className="font-semibold">
                                  {match.home_team_name} vs {match.away_team_name}
                                </h4>
                                <p className="text-sm text-slate-600">
                                  {new Date(match.match_date).toLocaleDateString()}
                                </p>
                              </div>
                              <Button 
                                onClick={() => handleCreateJob(match)} // Updated to handleCreateJob
                                className="w-full"
                                size="sm"
                                disabled={isCreatingJob} // Disable button while creating job
                              >
                                {isCreatingJob ? (
                                  <Loader className="w-4 h-4 mr-2 animate-spin" />
                                ) : (
                                  <PlayCircle className="w-4 h-4 mr-2" /> // Changed icon for clarity
                                )}
                                Start Analysis
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                    {matches.filter(match => !trackingJobs.find(job => job.match_id === match.id)).length === 0 && (
                      <div className="text-center py-8 text-slate-500">
                        <Activity className="w-12 h-12 mx-auto mb-3 opacity-50" />
                        <p>All finished matches have tracking jobs</p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Active tracking jobs */}
                <Card>
                  <CardHeader>
                    <CardTitle>Tracking Jobs</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {trackingJobs.map(job => {
                        const match = matches.find(m => m.id === job.match_id);
                        if (!match) return null;

                        return (
                          <TrackingJobCard 
                            key={job.id}
                            job={job}
                            match={match}
                            onRefresh={() => refreshJobStatus(job.external_job_id)}
                            onSelect={() => { // Updated onSelect to switch tab for review
                              setSelectedJob(job);
                              setActiveTab("review");
                            }}
                          />
                        );
                      })}
                      {trackingJobs.length === 0 && (
                        <div className="text-center py-8 text-slate-500">
                          <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
                          <p>No tracking jobs yet</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="review">
              {selectedJob ? (
                <ReviewInterface 
                  job={selectedJob}
                  onComplete={() => {
                    loadData();
                    toast({
                      title: "Review Complete",
                      description: "Player assignments have been submitted."
                    });
                  }}
                />
              ) : (
                <Card>
                  <CardContent className="p-8 text-center">
                    <Eye className="w-12 h-12 mx-auto mb-4 text-slate-300" />
                    <h3 className="text-lg font-medium mb-2">Select a Tracking Job</h3>
                    <p className="text-slate-600">
                      Choose a job that requires review to start assigning players to tracks
                    </p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="stats">
              <PlayerStatsView jobs={trackingJobs.filter(j => j.status === 'FINALIZED')} />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
