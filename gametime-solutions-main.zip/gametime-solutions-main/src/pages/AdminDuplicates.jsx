import React, { useEffect, useState } from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Merge, RefreshCw } from "lucide-react";
import { findDuplicates } from "@/api/functions";
import { mergePlayers } from "@/api/functions";

export default function AdminDuplicates() {
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [me, setMe] = useState(null);

  const load = async () => {
    setLoading(true);
    const user = await User.me();
    setMe(user);
    const { data } = await findDuplicates({});
    setGroups(data.groups || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  if (!me || me.role !== "admin") {
    return (
      <div className="max-w-5xl mx-auto p-6">
        <Card><CardContent className="p-6 text-red-600">Admins only.</CardContent></Card>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Duplicate Resolution</h1>
        <Button variant="outline" onClick={load}><RefreshCw className="w-4 h-4 mr-2" /> Refresh</Button>
      </div>

      {loading ? (
        <div>Loading...</div>
      ) : groups.length === 0 ? (
        <Card><CardContent className="p-6">No suspected duplicates found.</CardContent></Card>
      ) : (
        groups.map((g, i) => (
          <Card key={i} className="border-0 shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-yellow-600" />
                {g.type === 'phone' ? `Same phone: ${g.key}` : `Same name & DOB`}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {g.players.map(p => (
                <div key={p.id} className="flex items-center justify-between p-3 rounded bg-slate-50">
                  <div>
                    <div className="font-medium">{p.first_name} {p.middle_name} {p.last_name}</div>
                    <div className="text-sm text-slate-600">DOB: {p.date_of_birth || '—'} · Phone: {p.phone_e164 || '—'}</div>
                  </div>
                  <div className="text-xs text-slate-500">ID: {p.id}</div>
                </div>
              ))}
              {g.players.length >= 2 && (
                <div className="flex gap-2">
                  <Button onClick={async () => {
                    // Merge into first as primary for simplicity; in production, show picker and field mapping
                    const primary = g.players[0];
                    for (let j = 1; j < g.players.length; j++) {
                      await mergePlayers({ primary_player_id: primary.id, duplicate_player_id: g.players[j].id });
                    }
                    await load();
                  }}>
                    <Merge className="w-4 h-4 mr-2" /> Merge Group
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))
      )}
    </div>
  );
}