
import React, { useState, useEffect, useCallback } from "react";
import { Camera } from "@/api/entities";
import { Academy } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RefreshCw, Video, MapPin, Clock, Activity, HardDrive, Camera as CameraIcon, Wifi } from "lucide-react";
import { getCameras } from "@/api/functions";
import { useToast } from "@/components/ui/use-toast";
import { format } from "date-fns";

export default function CamerasPage() {
  const [cameras, setCameras] = useState([]);
  const [academy, setAcademy] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const { toast } = useToast();

  // Helper: exponential backoff retry for entity calls (handles 429 Rate Limit)
  const withRetry = useCallback(async (fn, { retries = 3, baseDelay = 400 } = {}) => {
    let lastErr;
    for (let i = 0; i <= retries; i++) {
      try {
        return await fn();
      } catch (err) {
        lastErr = err;
        const status = err?.response?.status || err?.status;
        const msg = (err && (err.message || "")) || "";
        const isRateLimited = status === 429 || /rate limit/i.test(msg);
        const delay = baseDelay * Math.pow(2, i);
        if (i === retries) break; // If this is the last retry, don't delay, just break.
        await new Promise((r) => setTimeout(r, isRateLimited ? delay : baseDelay));
      }
    }
    throw lastErr;
  }, []);

  // Session cache helpers
  const cacheKey = (academyId) => `gt_cameras_${academyId}`;
  const readCachedCameras = useCallback((academyId) => {
    try {
      const raw = sessionStorage.getItem(cacheKey(academyId));
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      // optional: 10 min staleness window
      if (parsed?.ts && Date.now() - parsed.ts < 10 * 60 * 1000) {
        return parsed.cameras || null;
      }
      return parsed?.cameras || null; // Return even if stale, if there's no newer data
    } catch {
      return null;
    }
  }, []);

  const writeCachedCameras = useCallback((academyId, list) => {
    try {
      sessionStorage.setItem(cacheKey(academyId), JSON.stringify({ ts: Date.now(), cameras: list || [] }));
    } catch (e) {
      console.warn("Failed to write to session storage:", e);
    }
  }, []);

  const loadAcademy = useCallback(async () => {
    try {
      const user = await User.me();

      // Prefer user's academy_id to avoid duplicate Academy.filter calls
      if (user?.academy_id) {
        const tempAcademy = { id: user.academy_id };
        setAcademy(tempAcademy);
        return tempAcademy;
      }

      // Fallback: query by coach_email (with retry/backoff)
      const academies = await withRetry(() => Academy.filter({ coach_email: user.email }));
      if (academies.length > 0) {
        setAcademy(academies[0]);
        return academies[0];
      }
    } catch (error) {
      console.error("Error loading academy:", error);
      const msg = (error && (error.message || "")) || "";
      if (error?.response?.status === 429 || /rate limit/i.test(msg)) {
        toast({
          variant: "destructive",
          title: "Too many requests",
          description: "We hit a rate limit while loading your academy. Retrying shortly..."
        });
      }
    }
    return null;
  }, [withRetry, toast]);

  const loadStoredCameras = useCallback(async (academyId) => {
    try {
      // Use retry/backoff to mitigate 429s
      const storedCameras = await withRetry(() => Camera.filter({ academy_id: academyId }));
      setCameras(storedCameras);
      writeCachedCameras(academyId, storedCameras);
    } catch (error) {
      console.error("Error loading stored cameras:", error);
      const msg = (error && (error.message || "")) || "";
      if (error?.response?.status === 429 || /rate limit/i.test(msg)) {
        // Try cache as fallback
        const cached = readCachedCameras(academyId);
        if (cached) {
          setCameras(cached);
          toast({
            title: "Showing cached data",
            description: "We hit a temporary rate limit. Displaying recently cached cameras."
          });
          return;
        }
        toast({
          variant: "destructive",
          title: "Rate limit exceeded",
          description: "Please wait a few seconds and try again."
        });
      }
    }
  }, [toast, withRetry, writeCachedCameras, readCachedCameras]);

  const syncCamerasFromAPI = useCallback(async (academyToSync) => {
    if (!academyToSync) {
        toast({
            variant: "destructive",
            title: "Action Aborted",
            description: "Academy information is not available. Cannot sync cameras.",
        });
        return;
    }
    if (isRefreshing) return; // prevent double clicks

    setIsRefreshing(true);
    try {
      const { data: response, error } = await withRetry(() => getCameras());
      
      if (error) {
        toast({
          variant: "destructive",
          title: "Sync Failed",
          description: `Could not fetch cameras: ${error.details || 'Unknown error'}`
        });
        return;
      }

      const apiCameras = response.cameras || [];
      
      if (apiCameras.length === 0) {
        toast({
          title: "No Cameras Found",
          description: "No recording systems found for your academy."
        });
        await withRetry(() => Camera.deleteWhere({ academy_id: academyToSync.id }));
        await loadStoredCameras(academyToSync.id); // Reload to show empty
        return;
      }
      
      // Minimize DB churn by loading current once (with retry)
      const storedCameras = await withRetry(() => Camera.filter({ academy_id: academyToSync.id }));

      // Update stored cameras with enhanced data
      for (const apiCamera of apiCameras) {
        const existingCamera = storedCameras.find(c => c.abwab_camera_id === apiCamera._id);
        
        const cameraData = {
          name: apiCamera.name || `Recording System ${apiCamera._id.slice(-6)}`,
          location: apiCamera.location || 'Academy Field',
          status: apiCamera.plannable ? 'active' : 'inactive',
          device_state: apiCamera.device_state || {},
          fixed_mounted: apiCamera.fixed_mounted || false,
          plannable: apiCamera.plannable || false,
          box_version: apiCamera.box_version || 'Unknown',
          device_id: apiCamera.device_id || 'Unknown',
          last_synced: new Date().toISOString()
        };
        
        if (existingCamera) {
          // Update existing
          await withRetry(() => Camera.update(existingCamera.id, cameraData));
        } else {
          // Create new
          await withRetry(() => Camera.create({
            academy_id: academyToSync.id,
            abwab_camera_id: apiCamera._id,
            ...cameraData
          }));
        }
      }
      
      // Reload cameras from database
      await loadStoredCameras(academyToSync.id);
      
      toast({
        title: "Cameras Synced",
        description: `Successfully synced ${apiCameras.length} recording systems.`
      });
      
    } catch (error) {
      console.error("Error syncing cameras:", error);
      const msg = (error && (error.message || "")) || "";
      toast({
        variant: "destructive",
        title: error?.response?.status === 429 || /rate limit/i.test(msg) ? "Rate limit exceeded" : "Sync Failed",
        description: error?.response?.status === 429 || /rate limit/i.test(msg) ? "Please wait a moment and try again." : `Error syncing cameras: ${error.message}`
      });
    }
    setIsRefreshing(false);
  }, [isRefreshing, toast, withRetry, loadStoredCameras]);

  useEffect(() => {
    const initializePage = async () => {
      setIsLoading(true);
      const currentAcademy = await loadAcademy();
      if (currentAcademy?.id) {
        // Hydrate quickly from cache (if present) to reduce empty UI on rate limits
        const cached = readCachedCameras(currentAcademy.id);
        if (cached && cached.length > 0) {
          setCameras(cached);
          toast({
            title: "Loading cameras...",
            description: "Displaying cached data while we check for updates."
          });
        }
        
        // Then try live load with retry/backoff
        await loadStoredCameras(currentAcademy.id);
      }
      setIsLoading(false);
    };
    
    initializePage();
  }, [loadAcademy, loadStoredCameras, readCachedCameras]);

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800 border-green-200';
      case 'maintenance': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'inactive': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const formatHeartbeat = (heartbeat) => {
    if (!heartbeat) return 'No signal';
    try {
      return format(new Date(heartbeat), 'MMM d, HH:mm');
    } catch {
      return 'Invalid date';
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex items-center space-x-2">
          <RefreshCw className="w-6 h-6 animate-spin text-blue-600" />
          <span className="text-lg">Loading Cameras...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="p-4 lg:p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Recording Systems</h1>
              <p className="text-slate-600 mt-1">
                Manage your academy's cameras and recording systems.
              </p>
            </div>
            <Button 
              onClick={() => syncCamerasFromAPI(academy)} 
              disabled={isRefreshing || !academy}
              className="text-white"
              style={{ backgroundColor: "var(--brand-navy)" }}
            >
              {isRefreshing ? (
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-2" />
              )}
              Refresh Cameras
            </Button>
          </div>

          {cameras.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              {cameras.map((camera) => (
                <Card key={camera.id} className="hover:shadow-lg transition-shadow border-l-4 border-l-blue-500">
                  <CardHeader className="pb-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-blue-100 rounded-lg">
                          <CameraIcon className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <CardTitle className="text-lg font-semibold truncate">
                            {camera.name}
                          </CardTitle>
                          <p className="text-sm text-slate-500">ID: {camera.abwab_camera_id?.slice(-8) || 'Unknown'}</p>
                        </div>
                      </div>
                      <Badge className={getStatusColor(camera.status)}>
                        {camera.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {camera.location && (
                      <div className="flex items-center space-x-2 text-sm text-slate-600">
                        <MapPin className="w-4 h-4" />
                        <span>{camera.location}</span>
                      </div>
                    )}
                    
                    {camera.device_state && (
                      <div className="space-y-3 pt-2 border-t border-slate-100">
                        <h4 className="text-sm font-medium text-slate-700 flex items-center gap-2">
                          <Activity className="w-4 h-4" />
                          Device Status
                        </h4>
                        
                        {camera.device_state.heartbeat && (
                          <div className="flex justify-between items-center text-sm">
                            <span className="flex items-center gap-2 text-slate-600">
                              <Wifi className="w-3 h-3" />
                              Last Signal:
                            </span>
                            <span className="text-slate-800 font-medium">
                              {formatHeartbeat(camera.device_state.heartbeat)}
                            </span>
                          </div>
                        )}
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-center p-2 bg-slate-50 rounded">
                            <div className="text-xs text-slate-500 mb-1">Left Camera</div>
                            <Badge variant={camera.device_state.left_camera ? "default" : "secondary"} className="text-xs">
                              {camera.device_state.left_camera ? "Active" : "Inactive"}
                            </Badge>
                          </div>
                          <div className="text-center p-2 bg-slate-50 rounded">
                            <div className="text-xs text-slate-500 mb-1">Right Camera</div>
                            <Badge variant={camera.device_state.right_camera ? "default" : "secondary"} className="text-xs">
                              {camera.device_state.right_camera ? "Active" : "Inactive"}
                            </Badge>
                          </div>
                        </div>
                        
                        {camera.device_state.disk_use && (
                          <div>
                            <div className="flex justify-between items-center text-sm mb-2">
                              <span className="flex items-center gap-2 text-slate-600">
                                <HardDrive className="w-3 h-3" />
                                Disk Usage:
                              </span>
                              <span className="text-slate-800 font-medium">
                                {camera.device_state.disk_use}%
                              </span>
                            </div>
                            <Progress 
                              value={camera.device_state.disk_use} 
                              className="h-2"
                              indicatorColor={
                                camera.device_state.disk_use >= 80 
                                  ? 'bg-red-500' 
                                  : camera.device_state.disk_use >= 60 
                                    ? 'bg-yellow-500' 
                                    : 'bg-green-500'
                              }
                            />
                          </div>
                        )}
                      </div>
                    )}
                    
                    <div className="pt-2 border-t border-slate-100">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-slate-500">Type:</span>
                          <p className="font-medium">{camera.fixed_mounted ? 'Fixed' : 'Portable'}</p>
                        </div>
                        <div>
                          <span className="text-slate-500">Version:</span>
                          <p className="font-medium">{camera.box_version || 'Unknown'}</p>
                        </div>
                      </div>
                    </div>
                    
                    {camera.last_synced && (
                      <div className="flex items-center space-x-2 text-xs text-slate-400 pt-2">
                        <Clock className="w-3 h-3" />
                        <span>Last synced: {format(new Date(camera.last_synced), 'MMM d, yyyy hh:mm a')}</span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <Video className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Recording Systems Found</h3>
                <p className="text-gray-600 mb-6">
                  Click the refresh button to sync recording systems from your academy.
                </p>
                <Button onClick={() => syncCamerasFromAPI(academy)} disabled={isRefreshing || !academy}>
                  {isRefreshing ? (
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <RefreshCw className="w-4 h-4 mr-2" />
                  )}
                  Sync Recording Systems
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
