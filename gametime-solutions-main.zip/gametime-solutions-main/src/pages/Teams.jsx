
import React, { useState, useEffect } from "react";
import { Team } from "@/api/entities";
import { Academy } from "@/api/entities";
import { Player } from "@/api/entities";
import { User } from "@/api/entities";
import { Match } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import TeamGrid from "../components/teams/TeamGrid";
import TeamModal from "../components/teams/TeamModal";
import TeamStatsModal from "../components/teams/TeamStatsModal";
import { createTeamWithClub } from "@/api/functions";
import { useToast } from "@/components/ui/use-toast";

export default function TeamsPage() {
  const [teams, setTeams] = useState([]);
  const [players, setPlayers] = useState([]);
  const [academy, setAcademy] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTeam, setEditingTeam] = useState(null);
  const [error, setError] = useState(null);
  const [matches, setMatches] = useState([]);
  const [statsTeam, setStatsTeam] = useState(null);
  const [isStatsOpen, setIsStatsOpen] = useState(false);
  const { toast } = useToast();

  const loadTeams = async () => {
    setIsLoading(true);
    setError(null);
    try {
      if (!User || !User.me) {
        throw new Error("User entity not available");
      }
      if (!Academy || !Academy.filter) {
        throw new Error("Academy entity not available");
      }
      if (!Team || !Team.filter) {
        throw new Error("Team entity not available");
      }
      if (!Player || !Player.filter) {
        throw new Error("Player entity not available");
      }
      if (!Match || !Match.filter) {
        throw new Error("Match entity not available");
      }

      const user = await User.me();
      const academies = await Academy.filter({ coach_email: user.email });
      
      if (academies.length > 0) {
        const userAcademy = academies[0];
        setAcademy(userAcademy);
        
        const [academyTeams, academyPlayers, academyMatches] = await Promise.all([
          Team.filter({ academy_id: userAcademy.id }),
          Player.filter({ academy_id: userAcademy.id }),
          Match.filter({ academy_id: userAcademy.id }, '-match_date')
        ]);

        setTeams(academyTeams.sort((a, b) => a.name.localeCompare(b.name)));
        setPlayers(academyPlayers.sort((a, b) => a.jersey_number - b.jersey_number));
        setMatches(academyMatches || []);
      } else {
        setAcademy(null);
        setTeams([]);
        setPlayers([]);
        setMatches([]);
      }
    } catch (error) {
      console.error("Error loading data:", error);
      setError(`Failed to load teams data: ${error.message}`);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    loadTeams();
  }, []);

  const handleTeamSave = async (teamData) => {
    if (!academy) {
      toast({
        variant: "destructive",
        title: "Action Required",
        description: "Academy information is not available to create a team.",
      });
      return;
    }

    try {
      if (editingTeam) {
        await Team.update(editingTeam.id, {
          name: teamData.name,
          color: teamData.color,
          players: teamData.players,
          formation: teamData.formation,
          coach_ids: teamData.coach_ids
        });
        toast({
          title: "Team Updated",
          description: `Team "${teamData.name}" has been updated successfully.`,
        });
      } else {
        const { data: abwabTeam, error } = await createTeamWithClub({ team_name: teamData.name });

        if (error || !abwabTeam?.abwab_team_id) {
          console.error("Abwab team creation failed:", error);
          toast({
            variant: "destructive",
            title: "Creation Failed",
            description: `Could not create team. Error: ${error?.details || 'Unknown error'}`
          });
          return;
        }

        const newTeamPayload = {
          name: teamData.name,
          color: teamData.color,
          players: teamData.players,
          academy_id: academy.id,
          abwab_team_id: abwabTeam.abwab_team_id,
          club_id: abwabTeam.club_id,
          formation: teamData.formation,
          coach_ids: teamData.coach_ids
        };
        await Team.create(newTeamPayload);
        toast({
          title: "Team Created",
          description: `Team "${teamData.name}" has been created successfully.`,
        });
      }

      setIsModalOpen(false);
      setEditingTeam(null);
      loadTeams();
    } catch (error) {
      console.error("Error saving team:", error);
      toast({
        variant: "destructive",
        title: "Save Failed",
        description: `An unexpected error occurred: ${error.message}`
      });
    }
  };

  const handleEditTeam = (team) => {
    setEditingTeam(team);
    setIsModalOpen(true);
  };

  const handleDeleteTeam = async (teamId) => {
    if (window.confirm("Are you sure you want to delete this team? This action cannot be undone.")) {
      try {
        await Team.delete(teamId);
        loadTeams();
        toast({
          title: "Team Deleted",
          description: "The team has been successfully deleted.",
        });
      } catch (error) {
        console.error("Error deleting team:", error);
        toast({
            variant: "destructive",
            title: "Delete Failed",
            description: "Failed to delete the team. Please try again.",
        });
      }
    }
  };

  const handleViewStats = (team) => {
    setStatsTeam(team);
    setIsStatsOpen(true);
  };

  if (error) {
    return (
      <div className="min-h-screen bg-slate-50 p-6">
        <div className="text-center py-12">
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 max-w-md mx-auto">
            <h3 className="text-lg font-semibold text-red-800 mb-2">Error Loading Teams</h3>
            <p className="text-red-600 mb-4">{error}</p>
            <Button onClick={() => window.location.reload()} className="bg-red-600 hover:bg-red-700 text-white">
              Refresh Page
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="p-4 lg:p-6">
        <div className="max-w-8xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Teams</h1>
              <p className="text-slate-600">
                Manage your academy's teams.
              </p>
            </div>
            <Button onClick={() => setIsModalOpen(true)} className="bg-green-600 hover:bg-green-700">
              <Plus className="w-4 h-4 me-2" />
              New Team
            </Button>
          </div>

          {isLoading ? (
            <div>Loading teams...</div>
          ) : (
            <TeamGrid 
              teams={teams}
              players={players}
              matches={matches}
              onEdit={handleEditTeam}
              onDelete={handleDeleteTeam}
              onViewStats={handleViewStats}
            />
          )}

          <TeamModal
            isOpen={isModalOpen}
            onClose={() => {
              setIsModalOpen(false);
              setEditingTeam(null);
            }}
            onSave={handleTeamSave}
            team={editingTeam}
            players={players}
            teams={teams}
          />
          <TeamStatsModal
            open={isStatsOpen}
            onClose={() => {
              setIsStatsOpen(false);
              setStatsTeam(null); // Clear the team when closing
            }}
            team={statsTeam}
            players={players}
            matches={matches}
          />
        </div>
      </div>
    </div>
  );
}
