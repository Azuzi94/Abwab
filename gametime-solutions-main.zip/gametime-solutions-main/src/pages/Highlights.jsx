
import React, { useState, useEffect, useMemo } from 'react';
import { PlayerPerformance, Player, Academy } from '@/api/entities';
import { User } from '@/api/entities';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Video, Search } from "lucide-react";
import { useLanguage } from "@/components/providers/LanguageProvider";

const HighlightCard = ({ highlight }) => {
  const { clip_url, type, player_name, match_name } = highlight;

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden group border-0">
      <div className="aspect-video bg-black flex items-center justify-center">
        <video controls key={clip_url} className="w-full h-full object-cover">
          <source src={clip_url} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
      <div className="p-4">
        <p className="text-sm font-semibold capitalize text-blue-600">{type.replace('_', ' ')}</p>
        <h3 className="font-bold text-slate-900 truncate">{player_name}</h3>
        <p className="text-xs text-slate-500 truncate">{match_name}</p>
      </div>
    </div>
  );
};

export default function HighlightsPage() {
  const [highlights, setHighlights] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filters, setFilters] = useState({
    search: "",
    player: "all",
    match: "all",
    type: "all",
  });
  
  const [players, setPlayers] = useState([]);
  const [matches, setMatches] = useState([]);
  const { t } = useLanguage();

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      try {
        const user = await User.me();
        const academies = await Academy.filter({ coach_email: user.email });
        if (academies.length > 0) {
          const academyId = academies[0].id;
          const [perfData, playersData] = await Promise.all([
            PlayerPerformance.filter({ academy_id: academyId }),
            Player.filter({ academy_id: academyId })
          ]);
          
          setPlayers(playersData);
          setMatches([]); // No local matches anymore, all from Zone14

          const allHighlights = perfData.flatMap(perf => 
            (perf.highlight_clips || []).map(clip => ({
              ...clip,
              player_id: perf.player_id,
              player_name: playersData.find(p => p.id === perf.player_id)?.first_name + ' ' + playersData.find(p => p.id === perf.player_id)?.last_name,
              match_id: perf.match_id,
              match_name: `Match ${perf.match_id.slice(-6)}`, // Simplified match name
            }))
          );
          setHighlights(allHighlights);
        }
      } catch (error) {
        console.error("Error loading highlights data:", error);
      }
      setIsLoading(false);
    };
    loadData();
  }, []);

  const filteredHighlights = useMemo(() => {
    return highlights.filter(h => {
      const searchLower = filters.search.toLowerCase();
      const typeMatch = filters.type === 'all' || h.type === filters.type;
      const playerMatch = filters.player === 'all' || h.player_id === filters.player;
      const matchMatch = filters.match === 'all' || h.match_id === filters.match;
      const searchTxtMatch = h.player_name.toLowerCase().includes(searchLower) || h.match_name.toLowerCase().includes(searchLower);
      return typeMatch && playerMatch && matchMatch && searchTxtMatch;
    });
  }, [highlights, filters]);

  const uniqueHighlightTypes = [...new Set(highlights.map(h => h.type))];

  if (isLoading) {
    return <div className="p-8">Loading highlights...</div>;
  }

  if (highlights.length === 0) {
    return (
      <div className="min-h-[calc(100vh-200px)] flex flex-col items-center justify-center text-center p-8 bg-slate-50">
        <div className="bg-white p-10 rounded-2xl shadow-lg max-w-lg">
          <Video className="w-16 h-16 text-slate-300 mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-slate-800 mb-3">Your Highlight Reel is Empty</h2>
          <p className="text-slate-600">
            Highlights are automatically generated from processed match videos. Once a match is completed and analyzed, key moments will appear here.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="p-6 lg:p-8">
        <div className="max-w-8xl mx-auto space-y-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">{t('nav.highlights')}</h1>
            <p className="text-slate-600">{t('nav.highlights_desc')}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4 bg-white rounded-xl shadow-sm border">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input placeholder="Search by player or match..." className="pl-10" value={filters.search} onChange={e => setFilters({...filters, search: e.target.value})} />
            </div>
            <Select value={filters.player} onValueChange={value => setFilters({...filters, player: value})}>
              <SelectTrigger><SelectValue placeholder="Filter by Player" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Players</SelectItem>
                {players.map(p => <SelectItem key={p.id} value={p.id}>{p.first_name} {p.last_name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filters.match} onValueChange={value => setFilters({...filters, match: value})}>
              <SelectTrigger><SelectValue placeholder="Filter by Match" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Matches</SelectItem>
                {matches.map(m => <SelectItem key={m.id} value={m.id}>{m.match_name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filters.type} onValueChange={value => setFilters({...filters, type: value})}>
              <SelectTrigger><SelectValue placeholder="Filter by Type" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {uniqueHighlightTypes.map(type => <SelectItem key={type} value={type}>{type.replace('_', ' ')}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredHighlights.map((highlight, index) => (
              <HighlightCard key={`${highlight.clip_url}-${index}`} highlight={highlight} />
            ))}
          </div>

          {filteredHighlights.length === 0 && (
            <div className="text-center py-16 col-span-full">
              <p className="text-slate-500">No highlights match your current filters.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
