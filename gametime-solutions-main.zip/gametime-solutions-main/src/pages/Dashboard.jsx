
import React, { useState, useEffect, Suspense } from "react";
import { Academy } from "@/api/entities";
import { Player } from "@/api/entities";
import { Match } from "@/api/entities";
import { User } from "@/api/entities";
import { Calendar, MapPin } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
// Removed direct import for StatsOverview and RecentMatches as they will be lazy-loaded
import AcademySetup from "../components/dashboard/AcademySetup";
import Alerts from "../components/dashboard/Alerts";
import QuickActions from "../components/dashboard/QuickActions";

// Lazy-loaded components
const LazyStatsOverview = React.lazy(() => import("../components/dashboard/StatsOverview"));
const LazyRecentMatches = React.lazy(() => import("../components/dashboard/RecentMatches"));
import TrendsChart from "../components/dashboard/TrendsChart";

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [academy, setAcademy] = useState(null);
  const [players, setPlayers] = useState([]);
  const [matches, setMatches] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      // First get the current user
      const currentUser = await User.me();
      setUser(currentUser);
      
      // Check if entities are available
      if (!Academy || !Academy.filter) {
        throw new Error("Academy entity not available");
      }
      if (!Player || !Player.filter) {
        throw new Error("Player entity not available");
      }
      if (!Match || !Match.filter) {
        throw new Error("Match entity not available");
      }
      
      // Get user's academy
      const academies = await Academy.filter({ coach_email: currentUser.email });
      if (academies.length > 0) {
        const userAcademy = academies[0];
        setAcademy(userAcademy);
        
        // Load academy data
        const [academyPlayers, academyMatches] = await Promise.all([
          Player.filter({ academy_id: userAcademy.id }),
          Match.filter({ academy_id: userAcademy.id }, '-match_date', 10)
        ]);
        
        setPlayers(academyPlayers || []);
        setMatches(academyMatches || []);
      } else {
        setAcademy(null);
        setPlayers([]);
        setMatches([]);
      }
    } catch (error) {
      console.error("Error loading dashboard:", error);
      // If unauthorized/401, send to Access page
      const msg = (error && (error.message || String(error))) || "";
      if (msg.includes("401") || /unauthorized/i.test(msg)) {
        window.location.href = createPageUrl("Access");
        return;
      }
      setError(`Failed to load dashboard data: ${msg}`);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white p-6 lg:p-8">
        <div className="max-w-7xl mx-auto">
          <div className="h-8 bg-slate-200 rounded w-1/4 mb-10 animate-pulse"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="h-28 bg-slate-200 rounded-xl animate-pulse"></div>
            ))}
          </div>
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 h-96 bg-slate-200 rounded-xl animate-pulse"></div>
            <div className="space-y-8">
              <div className="h-48 bg-slate-200 rounded-xl animate-pulse"></div>
              <div className="h-48 bg-slate-200 rounded-xl animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-white p-6 lg:p-8">
        <div className="text-center py-12">
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 max-w-md mx-auto">
            <h3 className="text-lg font-semibold text-red-800 mb-2">Error Loading Dashboard</h3>
            <p className="text-red-600 mb-4">{error}</p>
            <Button onClick={() => window.location.reload()} className="bg-red-600 hover:bg-red-700 text-white">
              Refresh Page
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (!academy) {
    return <AcademySetup user={user} onAcademyCreated={loadDashboardData} />;
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="p-6 lg:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
            <div>
              <h1 className="text-3xl lg:text-4xl font-bold" style={{ color: '#0B1324' }}>
                Welcome back, {user?.full_name?.split(' ')[0] || 'Coach'}
              </h1>
              <div className="flex items-center gap-2 text-slate-600 mt-2">
                <MapPin className="w-4 h-4" />
                <span>{academy.name}</span>
              </div>
            </div>
            
            <Link to={createPageUrl("NewMatch")}>
              <Button className="shadow-lg hover:opacity-90 text-white" style={{ backgroundColor: "var(--brand-navy)" }}>
                <Calendar className="w-4 h-4 mr-2" />
                New Match
              </Button>
            </Link>
          </div>

          <Suspense fallback={<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"><div className="h-28 bg-slate-200 rounded-xl animate-pulse"></div><div className="h-28 bg-slate-200 rounded-xl animate-pulse"></div><div className="h-28 bg-slate-200 rounded-xl animate-pulse"></div><div className="h-28 bg-slate-200 rounded-xl animate-pulse"></div></div>}>
            <LazyStatsOverview players={players} matches={matches} />
          </Suspense>

          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <Suspense fallback={<div className="h-96 bg-slate-200 rounded-xl animate-pulse"></div>}>
                <LazyRecentMatches matches={matches.slice(0, 5)} />
              </Suspense>
              <TrendsChart matches={matches} />
            </div>
            <div className="space-y-8">
              <Alerts matches={matches} />
              <QuickActions />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
