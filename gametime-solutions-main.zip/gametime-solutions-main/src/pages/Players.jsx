
import React, { useState, useEffect, useCallback, useMemo } from "react";
import { Player } from "@/api/entities";
import { Academy } from "@/api/entities";
import { User } from "@/api/entities";
import { Team } from "@/api/entities";
import { AuditLog } from "@/api/entities";

import PlayerToolbar from "../components/players/PlayerToolbar";
import PlayerFilters from "../components/players/PlayerFilters";
import PlayerGrid from "../components/players/PlayerGrid";
import PlayerTable from "../components/players/PlayerTable";
import PlayerModal from "../components/players/PlayerModal";
import BulkUploadModal from "../components/players/BulkUploadModal";
import BulkEditModal from "../components/players/BulkEditModal";
import PlayerProfileModal from "../components/players/PlayerProfileModal";
import { useLanguage } from "@/components/providers/LanguageProvider";
import { useConfirmDialog } from "@/components/providers/ConfirmDialogProvider";

export default function PlayersPage() {
  const [players, setPlayers] = useState([]);
  const [teams, setTeams] = useState([]);
  const [academy, setAcademy] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [viewMode, setViewMode] = useState("card");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPlayer, setEditingPlayer] = useState(null);
  const [isBulkUploadOpen, setIsBulkUploadOpen] = useState(false);
  const [isBulkEditModalOpen, setIsBulkEditModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [viewingPlayer, setViewingPlayer] = useState(null);
  const [selectedPlayers, setSelectedPlayers] = useState([]);

  const [filters, setFilters] = useState({
    search: "",
    position: "all",
    status: "all",
    ageGroup: "all",
    tags: [],
  });

  const { t } = useLanguage();
  const confirm = useConfirmDialog();

  const addAudit = async (action, entityId, payload = {}) => {
    if (!academy?.id) {
      console.warn("Academy ID not available for audit logging.");
      return;
    }
    try {
      const user = await User.me();
      await AuditLog.create({
        academy_id: academy.id,
        actor_user_id: user.id,
        action,
        entity: "Player",
        entity_id: entityId || null,
        payload_json: payload,
        created_at: new Date().toISOString()
      });
    } catch (e) {
      console.error("Audit log failed:", e);
    }
  };

  const loadPlayers = useCallback(async () => {
    setIsLoading(true);
    try {
      const user = await User.me();
      const academies = await Academy.filter({ coach_email: user.email });

      if (academies.length > 0) {
        const userAcademy = academies[0];
        setAcademy(userAcademy);
        const [academyPlayers, academyTeams] = await Promise.all([
            Player.filter({ academy_id: userAcademy.id }),
            Team.filter({ academy_id: userAcademy.id }),
        ]);

        // Restrict teams if coach
        let filteredTeams = academyTeams;
        if (user.role === 'user' || user.role === 'coach') {
          const assigned = Array.isArray(user.assigned_team_ids) ? new Set(user.assigned_team_ids) : null;
          if (assigned && assigned.size > 0) {
            filteredTeams = academyTeams.filter(t => assigned.has(t.id));
          }
        }
        setTeams(filteredTeams);

        setPlayers(academyPlayers.sort((a, b) => a.jersey_number - b.jersey_number));
      } else {
        setAcademy(null);
        setPlayers([]);
        setTeams([]);
      }
    } catch (error) {
      console.error("Error loading players data:", error);
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    loadPlayers();
  }, [loadPlayers]);

  const handlePlayerSave = async (playerData) => {
    try {
      const dataToSave = {
        ...playerData,
        tags: playerData.tags || [],
      };

      if (editingPlayer) {
        await Player.update(editingPlayer.id, dataToSave);
        await addAudit("update", editingPlayer.id, { fields: Object.keys(dataToSave) });
      } else {
        const created = await Player.create({ ...dataToSave, academy_id: academy.id });
        await addAudit("create", created.id, { fields: Object.keys(dataToSave) });
      }
      setIsModalOpen(false);
      setEditingPlayer(null);
      loadPlayers();
    } catch (error) {
      console.error("Error saving player:", error);
    }
  };

  const handleBulkEditSave = async (playerIds, updates) => {
    try {
      for (const playerId of playerIds) {
        const player = players.find(p => p.id === playerId);
        if (!player) continue;

        const updatedData = { ...player };

        if (updates.status) updatedData.status = updates.status;
        if (updates.preferred_foot) updatedData.preferred_foot = updates.preferred_foot;

        if (updates.addTags || updates.removeTags) {
          let currentTags = player.tags || [];

          if (updates.addTags) {
            currentTags = [...new Set([...currentTags, ...updates.addTags])];
          }

          if (updates.removeTags) {
            currentTags = currentTags.filter(tag => !updates.removeTags.includes(tag));
          }

          updatedData.tags = currentTags;
        }

        await Player.update(playerId, updatedData);
      }

      setIsBulkEditModalOpen(false);
      setSelectedPlayers([]);
      loadPlayers();
    } catch (error) {
      console.error("Error in bulk edit:", error);
    }
  };

  const handleDeletePlayer = async (player) => {
    const fullName = player ? `${player.first_name} ${player.last_name}` : "";
    const ok = await confirm({
      title: t ? t('playersPage.actions.delete') : "Confirm Action",
      message: fullName
        ? `Are you sure you want to delete ${fullName}?`
        : (t ? t('playersPage.delete_confirm') : "Are you sure you want to delete this player?"),
      confirmText: t ? t('playersPage.actions.delete') : "Delete",
      cancelText: t ? t('playersPage.modal.cancel') : "Cancel"
    });
    if (!ok) return;
    try {
      await Player.delete(player.id);
      await addAudit("delete", player.id, { name: `${player.first_name} ${player.last_name}` });
      loadPlayers();
      setSelectedPlayers(prev => prev.filter(id => id !== player.id));
    } catch (error) {
      console.error("Error deleting player:", error);
    }
  };

  const handleBulkDelete = async () => {
    const ok = await confirm({
      title: t ? t('playersPage.actions.delete') : "Confirm Action",
      message: t ? t('playersPage.bulk_delete_confirm', { count: selectedPlayers.length }) : `Are you sure you want to delete ${selectedPlayers.length} selected players?`,
      confirmText: t ? t('playersPage.actions.delete') : "Delete",
      cancelText: t ? t('playersPage.modal.cancel') : "Cancel"
    });
    if (!ok) return;
    try {
      await Promise.all(selectedPlayers.map(id => Player.delete(id)));
      await addAudit("bulk_delete", null, { count: selectedPlayers.length, ids: selectedPlayers });
      loadPlayers();
      setSelectedPlayers([]);
    } catch (error) {
      console.error("Error during bulk delete:", error);
    }
  };

  const handleEditPlayer = (player) => {
    setEditingPlayer(player);
    setIsModalOpen(true);
  };

  const handleViewProfile = (player) => {
    setViewingPlayer(player);
    setIsProfileModalOpen(true);
  };

  const filteredPlayers = useMemo(() => {
    return players.filter(p => {
      const searchLower = filters.search.toLowerCase();
      const nameMatch = `${p.first_name} ${p.last_name}`.toLowerCase().includes(searchLower);
      const jerseyMatch = p.jersey_number.toString().includes(searchLower);

      const getAgeGroup = (age) => {
        if (!age) return null;
        if (age <= 12) return "U12";
        if (age <= 14) return "U14";
        if (age <= 16) return "U16";
        if (age <= 18) return "U18";
        return "Senior";
      };

      const positionMatch = filters.position === 'all' || p.position === filters.position;
      const statusMatch = filters.status === 'all' || p.status === filters.status;
      const ageGroupMatch = filters.ageGroup === 'all' || getAgeGroup(p.age) === filters.ageGroup;
      const tagsMatch = filters.tags.length === 0 || filters.tags.every(tag => p.tags?.includes(tag));

      return (nameMatch || jerseyMatch) && positionMatch && statusMatch && ageGroupMatch && tagsMatch;
    });
  }, [players, filters]);

  const allTags = useMemo(() => {
    const tagsSet = new Set();
    players.forEach(p => {
      p.tags?.forEach(tag => tagsSet.add(tag));
    });
    return Array.from(tagsSet);
  }, [players]);

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="p-4 lg:p-6">
        <div className="max-w-8xl mx-auto">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-slate-900">{t('playersPage.title')}</h1>
            <p className="text-slate-600">
              {t('playersPage.description')}
            </p>
          </div>

          <PlayerToolbar
            onAddPlayer={() => setIsModalOpen(true)}
            onBulkUpload={() => setIsBulkUploadOpen(true)}
            onBulkEdit={() => setIsBulkEditModalOpen(true)}
            onBulkDelete={handleBulkDelete}
            viewMode={viewMode}
            onViewModeChange={setViewMode}
            selectedPlayersCount={selectedPlayers.length}
          />

          <div className="grid md:grid-cols-4 gap-6 mt-4">
            <div>
              <PlayerFilters
                filters={filters}
                onFilterChange={setFilters}
                allTags={allTags}
              />
            </div>

            <main className="md:col-span-3 min-w-0">
              {isLoading ? (
                <div>Loading...</div>
              ) : (
                <>
                  {viewMode === 'card' ? (
                    <PlayerGrid
                      players={filteredPlayers}
                      onEditPlayer={handleEditPlayer}
                      onViewProfile={handleViewProfile}
                      onDelete={handleDeletePlayer}
                    />
                  ) : (
                    <PlayerTable
                      players={filteredPlayers}
                      onEdit={handleEditPlayer}
                      onViewProfile={handleViewProfile}
                      onDelete={handleDeletePlayer}
                      selectedRows={selectedPlayers}
                      onSelect={setSelectedPlayers}
                    />
                  )}
                </>
              )}
            </main>
          </div>
        </div>
      </div>

      <PlayerModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingPlayer(null);
        }}
        onSave={handlePlayerSave}
        player={editingPlayer}
        teams={teams}
        allTags={allTags}
      />

      <BulkUploadModal
        isOpen={isBulkUploadOpen}
        onClose={() => setIsBulkUploadOpen(false)}
        onUploadComplete={loadPlayers}
        academyId={academy?.id}
      />

      <BulkEditModal
        isOpen={isBulkEditModalOpen}
        onClose={() => setIsBulkEditModalOpen(false)}
        onSave={handleBulkEditSave}
        selectedPlayers={selectedPlayers}
        players={players}
      />

      <PlayerProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        player={viewingPlayer}
        onEdit={(player) => {
          setEditingPlayer(player);
          setIsModalOpen(true);
        }}
      />
    </div>
  );
}
