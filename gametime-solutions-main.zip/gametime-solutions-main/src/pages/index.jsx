import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Players from "./Players";

import Matches from "./Matches";

import Mapping from "./Mapping";

import NewMatch from "./NewMatch";

import Teams from "./Teams";

import Landing from "./Landing";

import Analytics from "./Analytics";

import Highlights from "./Highlights";

import Cameras from "./Cameras";

import AdminDuplicates from "./AdminDuplicates";

import Fields from "./Fields";

import Access from "./Access";

import AwaitingApproval from "./AwaitingApproval";

import Coaches from "./Coaches";

import TeamDashboard from "./TeamDashboard";

import AfterMatchAnalysis from "./AfterMatchAnalysis";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Players: Players,
    
    Matches: Matches,
    
    Mapping: Mapping,
    
    NewMatch: NewMatch,
    
    Teams: Teams,
    
    Landing: Landing,
    
    Analytics: Analytics,
    
    Highlights: Highlights,
    
    Cameras: Cameras,
    
    AdminDuplicates: AdminDuplicates,
    
    Fields: Fields,
    
    Access: Access,
    
    AwaitingApproval: AwaitingApproval,
    
    Coaches: Coaches,
    
    TeamDashboard: TeamDashboard,
    
    AfterMatchAnalysis: AfterMatchAnalysis,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Players" element={<Players />} />
                
                <Route path="/Matches" element={<Matches />} />
                
                <Route path="/Mapping" element={<Mapping />} />
                
                <Route path="/NewMatch" element={<NewMatch />} />
                
                <Route path="/Teams" element={<Teams />} />
                
                <Route path="/Landing" element={<Landing />} />
                
                <Route path="/Analytics" element={<Analytics />} />
                
                <Route path="/Highlights" element={<Highlights />} />
                
                <Route path="/Cameras" element={<Cameras />} />
                
                <Route path="/AdminDuplicates" element={<AdminDuplicates />} />
                
                <Route path="/Fields" element={<Fields />} />
                
                <Route path="/Access" element={<Access />} />
                
                <Route path="/AwaitingApproval" element={<AwaitingApproval />} />
                
                <Route path="/Coaches" element={<Coaches />} />
                
                <Route path="/TeamDashboard" element={<TeamDashboard />} />
                
                <Route path="/AfterMatchAnalysis" element={<AfterMatchAnalysis />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}