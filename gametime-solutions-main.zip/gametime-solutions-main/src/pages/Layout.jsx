

import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { Academy } from "@/api/entities";
import { UserInvite } from "@/api/entities";
import { CoachPlayer } from "@/api/entities";
import {
  LayoutDashboard, Users, Calendar, BarChart3, Video,
  Menu, LogOut, Globe, MapPin } from

"lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { LanguageProvider, useLanguage } from "@/components/providers/LanguageProvider";
import { ConfirmDialogProvider } from "@/components/providers/ConfirmDialogProvider";
import { Toaster } from "@/components/ui/toaster";

// Cache the user between remounts to avoid flicker on navigation
let __cachedUser = undefined;

const AppWithProviders = ({ children }) =>
<LanguageProvider>
    <ConfirmDialogProvider>
      {children}
    </ConfirmDialogProvider>
  </LanguageProvider>;


const navConfig = [
{ key: "dashboard", icon: LayoutDashboard },
{ key: "players", icon: Users },
{ key: "teams", icon: Users },
{ key: "matches", icon: Calendar },
{ key: "fields", icon: MapPin }, // renamed from cameras
{ key: "analytics", icon: BarChart3 },
{ key: "highlights", icon: Video },
{ key: "coaches", icon: Users } // NEW: Coach management
];

// Add global brand tokens so even minimal pages (Landing/Access) get the variables
const GlobalBrandStyles = () =>
<style>{`
    :root {
      /* Brand palette */
      --brand-navy: #01203F;   /* Blue 655C */
      --brand-yellow: #FFC600; /* Yellow 123C */
      --brand-red: #E03C31;    /* Red 1787C */
      --brand-green: #006845;  /* Green 7725C */

      /* Legacy aliases for backward compatibility */
      --brand-sky: var(--brand-navy);
      --brand-blue: var(--brand-navy);

      /* Font stacks (use local if available, else safe fallbacks) */
      --font-en: "Gotham", "Inter", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Apple Color Emoji", "Segoe UI Emoji";
      --font-ar: "GE SS", "Cairo", "Tajawal", system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Apple Color Emoji", "Segoe UI Emoji";

      /* Common neutrals */
      --grey-neutral: #F1F5F9;
      --slate-grey: #64748B;
      --surface-elevated: #FFFFFF;
      --text-primary: #0B1324;
      --text-secondary: #475569;
      --shadow-premium: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06);
    }
    html { color-scheme: light; }
    body { font-family: var(--font-en); color: var(--text-primary); }
    html[lang="ar"] body { font-family: var(--font-ar); }

    /* Button hierarchy helpers (opt-in with classes) */
    .btn-primary { background-color: var(--brand-red); color: #fff; }
    .btn-primary:hover { background-color: #CC342B; }
    .btn-secondary { border: 1px solid rgba(1,32,63,0.2); color: var(--brand-navy); }
    .btn-secondary:hover { background-color: rgba(1,32,63,0.06); }

    /* Sidebar typography clarity */
    .sidebar-link-title { font-size: 0.95rem; }
    .sidebar-link-desc { font-size: 0.72rem; }

    /* Logo blending utility */
    .logo-blend { mix-blend-mode: color-burn; }
    .logo-wrap { isolation: isolate; } /* limit blending scope to container */
  `}</style>;



const MainLayout = ({ children, currentPageName }) => {
  const location = useLocation();
  // Initialize from cache so we don't blank the shell on route change
  const [user, setUser] = useState(typeof __cachedUser !== "undefined" ? __cachedUser : undefined);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { t, language, setLanguage } = useLanguage();

  // Load user and auto-fill academy_id if missing
  useEffect(() => {
    const loadUser = async () => {
      try {
        let fetchedUser = await User.me();

        // If the user came through an invite, auto-link academy, role, and assignments
        try {
          const invites = await UserInvite.filter({ email: fetchedUser.email }, '-created_date', 1);
          if (Array.isArray(invites) && invites.length > 0) {
            const inv = invites[0];

            // Set academy if missing
            if (!fetchedUser.academy_id && inv.academy_id) {
              await User.updateMyUserData({ academy_id: inv.academy_id });
              fetchedUser = await User.me();
            }

            // Apply role and pre-assigned teams if not already set
            const patch = {};
            if (!fetchedUser.app_role && inv.app_role) patch.app_role = inv.app_role;
            if ((!Array.isArray(fetchedUser.assigned_team_ids) || fetchedUser.assigned_team_ids.length === 0) && Array.isArray(inv.assigned_team_ids)) {
              patch.assigned_team_ids = inv.assigned_team_ids;
            }
            if (Object.keys(patch).length > 0) {
              await User.updateMyUserData(patch);
              fetchedUser = await User.me();
            }

            // Create CoachPlayer links for preassigned players (idempotent)
            if (fetchedUser.academy_id && Array.isArray(inv.preassigned_player_ids) && inv.preassigned_player_ids.length > 0) {
              const existing = await CoachPlayer.filter({ academy_id: fetchedUser.academy_id, user_id: fetchedUser.id });
              const existingSet = new Set(existing.map((e) => e.player_id));
              for (const pid of inv.preassigned_player_ids) {
                if (!existingSet.has(pid)) {
                  await CoachPlayer.create({ academy_id: fetchedUser.academy_id, user_id: fetchedUser.id, player_id: pid });
                }
              }
            }

            // Mark invite accepted
            if (inv.status !== 'accepted') {
              await UserInvite.update(inv.id, {
                status: 'accepted',
                accepted_user_id: fetchedUser.id, // Corrected from fetchedFuser.id
                accepted_at: new Date().toISOString()
              });
            }
          }
        } catch (e) {
          console.error("Invite processing error:", e);
        }

        // Auto-fill academy from Academy.coach_email if still missing
        if (fetchedUser && !fetchedUser.academy_id) {
          try {
            const academies = await Academy.filter({ coach_email: fetchedUser.email });
            if (Array.isArray(academies) && academies.length > 0) {
              await User.updateMyUserData({ academy_id: academies[0].id });
              // Refresh user object locally after update
              fetchedUser = await User.me();
            }
          } catch (e) {
            console.error("Error auto-filling academy_id:", e);
          }
        }
        __cachedUser = fetchedUser; // update cache
        setUser(fetchedUser);
      } catch (error) {
        // Not authenticated
        __cachedUser = null; // cache unauth state too
        setUser(null);
      }
    };
    // Only fetch if we don't have a cached value, otherwise ensure background refresh for cached values
    if (typeof __cachedUser === "undefined") {
      loadUser();
    } else {
      // Ensure background refresh for cached values
      loadUser();
    }
  }, []);

  // Gate: redirect unauthenticated users to Access for protected pages
  useEffect(() => {
    // Only proceed if user status is explicitly null (meaning not logged in), not just undefined (still loading)
    if (user === null) {
      const publicPages = ["Landing", "Access", "AwaitingApproval"];
      if (!publicPages.includes(currentPageName)) {
        window.location.href = createPageUrl("Access");
      }
    }
  }, [user, currentPageName]);

  // Gate: redirect unapproved/inactive users away from app pages
  useEffect(() => {
    if (user === undefined) return; // Wait for user data to be loaded (or confirmed null/logged out)
    const allowedPagesWithoutApproval = ["Landing", "Access", "AwaitingApproval"];

    if (user !== null && (user.is_approved === false || user.is_active === false) && !allowedPagesWithoutApproval.includes(currentPageName)) {
      window.location.href = createPageUrl("AwaitingApproval");
    }
  }, [user, currentPageName]);

  const canManageCoaches = !!user && (user.role === 'admin' || user.app_role === 'academy_admin');

  const navigationItems = navConfig.
  filter((item) => item.key !== "coaches" || canManageCoaches).
  map((item) => ({
    title: t(`nav.${item.key}`),
    // For 'fields' we want to map it to the 'Cameras' page URL for now, as it's an alias
    url: item.key === 'fields' ? createPageUrl('Cameras') : createPageUrl(item.key.charAt(0).toUpperCase() + item.key.slice(1)),
    icon: item.icon,
    description: t(`nav.${item.key}_desc`)
  }));

  const handleLogout = async () => {
    await User.logout();
    __cachedUser = null;
    window.location.href = createPageUrl("Landing");
  };

  const toggleLanguage = () => {
    setLanguage((prev) => prev === 'en' ? 'ar' : 'en');
  };

  // Special minimal layout for landing-like pages
  if (currentPageName === 'Landing' || currentPageName === 'Access' || currentPageName === 'AwaitingApproval') {
    return (
      <div className="min-h-screen bg-white">
        {children}
      </div>);
  }

  // IMPORTANT: Do NOT return null while loading; keep shell visible to avoid full-page flicker
  // Optionally show a thin progress bar at top while user is loading
  const TopLoader = () =>
  <div className="fixed top-0 left-0 right-0 h-0.5 bg-slate-200 z-[100]">
      <div className="h-full w-1/3 bg-[color:var(--brand-yellow)] animate-pulse"></div>
    </div>;


  const SidebarContent = ({ isMobile = false }) =>
  <div className="flex flex-col h-full sidebar-bg">
    <style>{`
      /* Prevent OS high-contrast from overriding our status colors */
      .no-forced-colors { forced-color-adjust: none; }

      /* New brand gradient for the entire sidebar */
      .sidebar-bg {
        background: linear-gradient(180deg, var(--brand-navy) 0%, #00182F 100%);
      }

      .premium-hover {
        transition: all .2s cubic-bezier(.4,0,.2,1);
      }
      .premium-hover:hover {
        background: rgba(255,255,255,0.06);
        transform: translateX(4px);
        border-left: 3px solid var(--brand-red);
      }

      /* Status gradient bars (kept) */
      .status-gradient { height: 4px; width: 100%; }
      .status-gradient[data-status="planned"] { background: linear-gradient(90deg, #94A3B8, #64748B); }
      .status-gradient[data-status="ready_for_recording"] { background: linear-gradient(90deg, var(--brand-navy), #00182F); }
      .status-gradient[data-status="recording"] { background: linear-gradient(90deg, var(--brand-red), #B32D25); }
      .status-gradient[data-status="recorded"] { background: linear-gradient(90deg, #334155, #0F172A); }
      .status-gradient[data-status="uploading"] { background: linear-gradient(90deg, var(--brand-yellow), #D4A800); }
      .status-gradient[data-status="uploaded"] { background: linear-gradient(90deg, var(--brand-green), #035C36); }
      .status-gradient[data-status="post_processing"] { background: linear-gradient(90deg, var(--brand-yellow), #D4A800); }
      .status-gradient[data-status="finished"],
      .status-gradient[data-status="completed"] { background: linear-gradient(90deg, var(--brand-green), #035C36); }
      .status-gradient[data-status="live"] { background: linear-gradient(90deg, var(--brand-green), #035C36); }
      .status-gradient[data-status="cancelled"],
      .status-gradient[data-status="error"] { background: linear-gradient(90deg, var(--brand-red), #B32D25); }

      /* Decorative background bubble (kept) */
      .status-gradient-bg {
        position: absolute; top: 0; left: 0; width: 100%; height: 100%;
        border-radius: inherit; pointer-events: none; opacity: 0.1; overflow: hidden; z-index: 0;
      }
      .status-gradient-bg::before { content: ""; position: absolute; width: 120px; height: 120px; top: 30%; left: 30%; transform: translate(-50%, -50%); border-radius: 50%; }
      .status-gradient-bg[data-status="planned"]::before { background: radial-gradient(circle at center, #94A3B8, #64748B); }
      .status-gradient-bg[data-status="ready_for_recording"]::before { background: radial-gradient(circle at center, var(--brand-navy), #00182F); }
      .status-gradient-bg[data-status="recording"]::before { background: radial-gradient(circle at center, var(--brand-red), #B32D25); }
      .status-gradient-bg[data-status="recorded"]::before { background: radial-gradient(circle at center, #334155, #0F172A); }
      .status-gradient-bg[data-status="uploading"]::before { background: radial-gradient(circle at center, var(--brand-yellow), #D4A800); }
      .status-gradient-bg[data-status="uploaded"]::before { background: radial-gradient(circle at center, var(--brand-green), #035C36); }
      .status-gradient-bg[data-status="post_processing"]::before { background: radial-gradient(circle at center, var(--brand-yellow), #D4A800); }
      .status-gradient-bg[data-status="finished"]::before,
      .status-gradient-bg[data-status="completed"]::before { background: radial-gradient(circle at center, var(--brand-green), #035C36); }
      .status-gradient-bg[data-status="live"]::before { background: radial-gradient(circle at center, var(--brand-green), #035C36); }
      .status-gradient-bg[data-status="cancelled"]::before,
      .status-gradient-bg[data-status="error"]::before { background: radial-gradient(circle at center, var(--brand-red), #B32D25); }

      /* Smooth Shadows - kept */
      .card-premium { box-shadow: 0 1px 3px 0 rgba(0,0,0,0.1), 0 1px 2px 0 rgba(0,0,0,0.06); transition: box-shadow 0.2s ease; }
      .card-premium:hover { box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -2px rgba(0,0,0,0.05); }

      /* Arabic Typography - kept */
      .arabic-text { font-family: 'Cairo', 'Tajawal', system-ui, sans-serif; font-weight: 500; }
    `}</style>

    {/* Logo Section with blend on gradient */}
    <div className="sidebar-bg px-6 py-6 border-b border-white/10">
      <div className="flex items-center gap-3 logo-wrap">
        <img
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/e329017ef_GametimeAbwab-06t.png"
          alt="Abwab" className="mx-6 h-8 w-auto logo-blend" />


      </div>
    </div>

    {/* Navigation with new active accents */}
    <nav className="sidebar-bg px-4 py-6 flex-1">
      <div className="space-y-1">
        {navigationItems.map((item) => {
          const isActive = item.title === t('nav.fields') ?
          location.pathname.toLowerCase().includes(t('nav.cameras').toLowerCase()) || location.pathname.toLowerCase().includes(t('nav.fields').toLowerCase()) :
          location.pathname.toLowerCase().includes(item.title.toLowerCase());
          return (
            <Link
              key={item.title}
              to={item.url}
              onClick={() => isMobile && setIsMobileMenuOpen(false)}
              className={`flex items-center gap-4 px-4 py-3.5 rounded-lg premium-hover group ${
              isActive ?
              'bg-[rgba(224,60,49,0.16)] text-white border-l-4 border-[color:var(--brand-red)] shadow' :
              'text-slate-200 hover:text-white hover:bg-white/5'}`
              }>

              <item.icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-slate-300 group-hover:text-white'}`} />
              <div className="flex-1">
                <div className="sidebar-link-title font-semibold">{item.title}</div>
                <div className="sidebar-link-desc text-slate-400 group-hover:text-slate-200">{item.description}</div>
              </div>
              {isActive && <div className="w-2 h-2 bg-[color:var(--brand-yellow)] rounded-full"></div>}
            </Link>);

        })}
      </div>
    </nav>

    {/* User Section with gradient background */}
    <div className="sidebar-bg px-4 py-6 border-t border-white/10 space-y-4">
      <Button
        variant="ghost"
        onClick={toggleLanguage}
        className="w-full justify-start text-slate-300 hover:text-white hover:bg-white/10 premium-hover">

        <Globe className="w-4 h-4 me-3" />
        <span className={language === 'ar' ? 'arabic-text' : ''}>
          {language === 'en' ? 'العربية' : 'English'}
        </span>
      </Button>

      {user &&
      <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-white/10">
          <div className="flex items-center gap-3 min-w-0">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[color:var(--brand-green)] to-emerald-500 flex items-center justify-center shadow-md">
                <span className="text-white font-bold text-sm">{user.full_name?.charAt(0) || 'U'}</span>
              </div>
              <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-[color:var(--brand-yellow)] border-2 border-slate-800 rounded-full"></div>
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-white font-semibold text-sm truncate">{user.full_name || t('user.coach')}</div>
              <div className="text-xs truncate text-slate-400">{user.email}</div>
            </div>
          </div>
          <Button
          variant="ghost"
          size="icon"
          onClick={handleLogout}
          className="text-slate-400 hover:text-red-300 hover:bg-red-500/10 premium-hover">

            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      }
    </div>
  </div>;


  return (
    <div className="min-h-screen bg-slate-50">
      {user === undefined && <TopLoader />}
      {/* Desktop Sidebar */}
      <div className="hidden lg:fixed lg:inset-y-0 lg:z-50 lg:w-72 lg:block">
        <div className="h-full overflow-y-auto">
          <SidebarContent />
        </div>
      </div>

      {/* Mobile Header */}
      <div className="lg:hidden bg-white border-b border-slate-200 shadow-sm">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-white border border-slate-200 flex items-center justify-center shadow-md">
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/666395f21_GametimeAbwab-07tas.jpg"
                alt="Abwab logo"
                className="w-7 h-7 object-contain logo-blend" />

            </div>
            <h1 className="text-lg font-bold text-slate-900">{t('header.title')}</h1>
          </div>
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="hover:bg-slate-100 premium-hover">
                <Menu className="w-6 h-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 w-72 max-h-[100vh] overflow-y-auto">
              <SidebarContent isMobile={true} />
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Main Content */}
      <main className="lg:ps-72 min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
        {children}
      </main>
      {/* Powered by footer only for logged-in shell */}
      <footer className="lg:ps-72 bg-white border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Powered by <span className="font-semibold text-[color:var(--brand-red)]">Gametime Solutions</span>
          </span>
          <img
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/e99f9685b_GametimeAbwab-02-trans.jpg"
            alt="Gametime Solutions"
            className="h-6 w-auto opacity-90 logo-blend" />

        </div>
      </footer>
    </div>);

};

export default function Layout({ children, currentPageName }) {
  return (
    <AppWithProviders>
      <GlobalBrandStyles />
      <MainLayout currentPageName={currentPageName}>
        {children}
      </MainLayout>
      <Toaster />
    </AppWithProviders>);

}
