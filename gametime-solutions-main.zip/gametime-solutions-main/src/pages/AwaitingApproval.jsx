import React, { useEffect, useState } from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { ShieldAlert, LogOut } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function AwaitingApproval() {
  const [user, setUser] = useState(null);
  useEffect(() => {
    (async () => {
      try { setUser(await User.me()); } catch {}
    })();
  }, []);

  const handleLogout = async () => {
    await User.logout();
    window.location.href = createPageUrl("Landing");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-6">
      <div className="max-w-lg w-full bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-8 text-white text-center shadow-2xl">
        <div className="mx-auto w-14 h-14 rounded-full bg-yellow-500/20 flex items-center justify-center mb-4">
          <ShieldAlert className="w-7 h-7 text-yellow-300" />
        </div>
        <h1 className="text-2xl font-extrabold">Your Access is Pending Approval</h1>
        <p className="mt-2 text-white/80">
          Thank you {user?.full_name ? `, ${user.full_name.split(' ')[0]}` : ""}. Our team is reviewing your request.
          You’ll receive an email once your account is approved.
        </p>
        <div className="mt-6 flex justify-center">
          <Button onClick={handleLogout} variant="outline" className="text-white border-white/30 hover:bg-white/10">
            <LogOut className="w-4 h-4 mr-2" /> Sign out
          </Button>
        </div>
      </div>
    </div>
  );
}