
import React, { useEffect, useMemo, useState } from "react";
import { Team } from "@/api/entities";
import { Player } from "@/api/entities";
import { Match } from "@/api/entities";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BarChart3, NotebookText, FileText } from "lucide-react";

export default function TeamDashboard() {
  const urlParams = new URLSearchParams(window.location.search);
  const teamId = urlParams.get("team_id");

  const [team, setTeam] = useState(null);
  const [players, setPlayers] = useState([]);
  const [matches, setMatches] = useState([]);
  const [tab, setTab] = useState("overview");

  const byId = (arr) => Object.fromEntries(arr.map(x => [x.id, x]));

  useEffect(() => {
    const load = async () => {
      if (!teamId) return;
      const t = await Team.list();
      const found = t.find(tt => tt.id === teamId);
      setTeam(found || null);
      if (found) {
        const [ps, ms] = await Promise.all([
          Player.filter({}),
          Match.filter({})
        ]);
        setPlayers(ps.filter(p => (found.players || []).includes(p.id)));
        setMatches(ms.filter(m => m.home_team_id === found.id || m.away_team_id === found.id));
      }
    };
    load();
  }, [teamId]);

  const kpis = useMemo(() => {
    if (!team || players.length === 0) return { avgAge: "-", size: 0 };
    const ages = players.map(p => p.age).filter(a => typeof a === 'number');
    const avgAge = ages.length ? Math.round(ages.reduce((a,b) => a+b,0)/ages.length) : "-";
    return { avgAge, size: players.length };
  }, [team, players]);

  const record = useMemo(() => {
    // Filter matches that involve the current team and are considered 'played' (finished or have scores)
    const related = matches.filter(m => m.home_team_id === team?.id || m.away_team_id === team?.id);
    const played = related.filter(m => {
      const s = (m.raw_status || m.status || "").toLowerCase();
      const hasScores = typeof m.home_score === "number" && typeof m.away_score === "number";
      return s === "finished" || s === "completed" || hasScores;
    }).sort((a,b) => {
        // Sort by date/time, most recent first
        const dateA = new Date(a.match_date || a.start_time_utc || 0);
        const dateB = new Date(b.match_date || b.start_time_utc || 0);
        return dateB.getTime() - dateA.getTime();
    });

    let w=0,d=0,l=0;
    played.forEach(m => {
      if (typeof m.home_score !== "number" || typeof m.away_score !== "number") return;
      const isHome = m.home_team_id === team?.id;
      const gf = isHome ? m.home_score : m.away_score; // Goals for
      const ga = isHome ? m.away_score : m.home_score; // Goals against
      if (gf > ga) w++;
      else if (gf === ga) d++;
      else l++;
    });

    const last5 = played.slice(0,5); // Get the 5 most recent played matches
    let w5=0,d5=0,l5=0;
    last5.forEach(m => {
      if (typeof m.home_score !== "number" || typeof m.away_score !== "number") return;
      const isHome = m.home_team_id === team?.id;
      const gf = isHome ? m.home_score : m.away_score;
      const ga = isHome ? m.away_score : m.home_score;
      if (gf > ga) w5++;
      else if (gf === ga) d5++;
      else l5++;
    });
    return { total: played.length, w, d, l, last5: `W${w5} D${d5} L${l5}` };
  }, [matches, team]);

  if (!team) {
    return <div className="p-6">Team not found.</div>;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="p-4 lg:p-6 max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">{team.name}</h1>
          </div>
          <div className="flex gap-2">
            <Button variant={tab === "overview" ? "default" : "outline"} onClick={() => setTab("overview")}><BarChart3 className="w-4 h-4 mr-2" />Overview</Button>
            <Button variant={tab === "notes" ? "default" : "outline"} onClick={() => setTab("notes")}><NotebookText className="w-4 h-4 mr-2" />Notes</Button>
            <Button variant={tab === "reports" ? "default" : "outline"} onClick={() => setTab("reports")}><FileText className="w-4 h-4 mr-2" />Reports</Button>
          </div>
        </div>

        {tab === "overview" && (
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">Roster</h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  {players.map(p => (
                    <div key={p.id} className="p-3 rounded-md border flex items-center justify-between">
                      <div>
                        <div className="font-medium">{p.first_name} {p.last_name}</div>
                        <div className="text-xs text-slate-500 capitalize">{p.position} • #{p.jersey_number || '-'}</div>
                      </div>
                      <Badge className={
                        p.status === 'injured' ? 'bg-rose-100 text-rose-700' :
                        p.status === 'suspended' ? 'bg-orange-100 text-orange-700' :
                        'bg-emerald-100 text-emerald-700'
                      }>{p.status || 'available'}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 space-y-3">
                <h3 className="font-semibold">KPIs</h3>
                <div className="text-sm text-slate-600">Squad Size: <span className="font-semibold text-slate-900">{kpis.size}</span></div>
                <div className="text-sm text-slate-600">Average Age: <span className="font-semibold text-slate-900">{kpis.avgAge}</span></div>
                <div className="text-sm text-slate-600">Recent Matches: <span className="font-semibold text-slate-900">{matches.length}</span></div>
                <div className="text-sm text-slate-600">Matches Played: <span className="font-semibold text-slate-900">{record.total}</span></div>
                <div className="text-sm text-slate-600">Record (W-D-L): <span className="font-semibold text-slate-900">{record.w}-{record.d}-{record.l}</span></div>
                <div className="text-sm text-slate-600">Last 5: <span className="font-semibold text-slate-900">{record.last5}</span></div>
                <div className="text-sm text-slate-600">Formation: <Badge variant="outline">{team.formation || "—"}</Badge></div>
              </CardContent>
            </Card>
          </div>
        )}

        {tab === "notes" && (
          <Card>
            <CardContent className="p-6">
              <p className="text-slate-600 text-sm">Add coaching notes and training objectives (coming soon).</p>
            </CardContent>
          </Card>
        )}

        {tab === "reports" && (
          <Card>
            <CardContent className="p-6">
              <p className="text-slate-600 text-sm">Export lineup sheets and reports (coming soon).</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
