
import React, { useState, useEffect } from 'react';
import { Player, Academy, PlayerPerformance } from '@/api/entities';
import { User } from '@/api/entities';

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, LineChart, Line, PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { TrendingUp, Users, Target, Clock, Download, Filter, BarChart3, Zap } from "lucide-react";
import { useLanguage } from "@/components/providers/LanguageProvider";

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

const StatCard = ({ title, value, icon: Icon, description }) => (
  <Card className="border-0 shadow-lg bg-white">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium text-slate-500">{title}</CardTitle>
      <Icon className="h-4 w-4 text-slate-400" />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
      <p className="text-xs text-slate-500">{description}</p>
    </CardContent>
  </Card>
);

export default function AnalyticsPage() {
  const [players, setPlayers] = useState([]);
  const [performances, setPerformances] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPlayer, setSelectedPlayer] = useState('all');
  const [selectedMetric, setSelectedMetric] = useState('distance_covered');
  const [searchTerm, setSearchTerm] = useState('');
  const { t } = useLanguage();

  useEffect(() => {
    loadAnalyticsData();
  }, []);

  const loadAnalyticsData = async () => {
    setIsLoading(true);
    try {
      const user = await User.me();
      const academies = await Academy.filter({ coach_email: user.email });
      
      if (academies.length > 0) {
        const academy = academies[0];
        const [playersData, performancesData] = await Promise.all([
          Player.filter({ academy_id: academy.id }),
          PlayerPerformance.filter({ academy_id: academy.id })
        ]);
        
        setPlayers(playersData);
        setPerformances(performancesData);
      }
    } catch (error) {
      console.error("Error loading analytics data:", error);
    }
    setIsLoading(false);
  };
  
  const getPlayerName = (playerId) => {
    const player = players.find(p => p.id === playerId);
    return player ? `${player.first_name} ${player.last_name}` : "Unknown Player";
  };

  const topPlayersByMetric = (metric, limit = 5) => {
    return performances
      .sort((a, b) => (b[metric] || 0) - (a[metric] || 0))
      .slice(0, limit)
      .map(p => ({
        name: getPlayerName(p.player_id),
        value: p[metric] || 0
      }));
  };

  if (isLoading) {
    return (
      <div className="p-6 lg:p-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-6">Analytics</h1>
        <div>Loading analytics data...</div>
      </div>
    );
  }

  if (performances.length === 0) {
    return (
      <div className="min-h-[calc(100vh-200px)] flex flex-col items-center justify-center text-center p-8 bg-slate-50">
        <div className="bg-white p-10 rounded-2xl shadow-lg max-w-lg">
          <BarChart3 className="w-16 h-16 text-slate-300 mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-slate-800 mb-3">No Performance Data Available</h2>
          <p className="text-slate-600">
            Analytics and player statistics are generated after a match has been recorded, reviewed, and processed.
            Complete a match cycle to see the data here.
          </p>
        </div>
      </div>
    );
  }

  const topDistancePlayers = topPlayersByMetric('distance_covered');

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="p-6 lg:p-8">
        <div className="max-w-8xl mx-auto space-y-8">
          <h1 className="text-3xl font-bold text-slate-900">{t('nav.analytics')}</h1>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {/* Removed 'Completed Matches' and 'Avg. Distance/Match' due to 'matches' entity removal */}
            <StatCard title="Total Players Analyzed" value={new Set(performances.map(p => p.player_id)).size} icon={Users} description="Unique players with performance data" />
            <StatCard title="Total Goals Scored" value={performances.reduce((acc, p) => acc + (p.goals || 0), 0)} icon={Zap} description="Across all completed matches" />
          </div>

          <div className="grid lg:grid-cols-5 gap-8">
            <Card className="lg:col-span-3 border-0 shadow-lg bg-white">
              <CardHeader>
                <CardTitle>Distance Covered (Top 5)</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={topDistancePlayers}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis label={{ value: 'Meters', angle: -90, position: 'insideLeft' }} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="value" fill="#1B365D" name="Distance (m)" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2 border-0 shadow-lg bg-white">
              <CardHeader>
                <CardTitle>Leaderboards</CardTitle>
              </CardHeader>
              <CardContent>
                {/* Placeholder for more leaderboards */}
                <h4 className="font-semibold text-slate-700 mb-2">Top Speed</h4>
                <ul className="space-y-2">
                  {topPlayersByMetric('top_speed').map((p, i) => (
                    <li key={i} className="flex justify-between items-center text-sm p-2 rounded-md even:bg-slate-50">
                      <span>{p.name}</span>
                      <span className="font-bold">{p.value} km/h</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
