import React, { useState, useEffect } from "react";
import { Match, Player } from "@/api/entities";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { createPageUrl } from "@/utils";

import MappingHeader from "../components/mapping/MappingHeader";
import PlayerRoster from "../components/mapping/PlayerRoster";
import VideoPlayer from "../components/mapping/VideoPlayer";
import TrackList from "../components/mapping/TrackList";
import MappingFooter from "../components/mapping/MappingFooter";

// Mock data for unassigned tracks from video analysis
const generateMockTracks = (players) => {
  return players.slice(0, 5).map((player, index) => ({
    id: `track-${index + 1}`,
    thumbnail: `https://i.pravatar.cc/150?u=track${index}`,
    detectedJersey: player.jersey_number,
    confidence: Math.random() * 0.3 + 0.6, // 60-90%
    assignedPlayerId: null,
  }));
};

export default function Mapping() {
  const location = useLocation();
  const navigate = useNavigate();
  const [match, setMatch] = useState(null);
  const [players, setPlayers] = useState([]);
  const [tracks, setTracks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const matchId = params.get("match_id");
    if (matchId) {
      loadData(matchId);
    } else {
      setIsLoading(false);
    }
  }, [location.search]);

  const loadData = async (matchId) => {
    try {
      const currentMatch = await Match.get(matchId);
      setMatch(currentMatch);

      const academyPlayers = await Player.filter({ academy_id: currentMatch.academy_id });
      setPlayers(academyPlayers);

      setTracks(generateMockTracks(academyPlayers));
    } catch (error) {
      console.error("Error loading mapping data:", error);
    }
    setIsLoading(false);
  };
  
  const onDragEnd = (result) => {
    const { source, destination } = result;
    if (!destination) return;

    // Player from roster is dropped onto a track
    if (source.droppableId === 'player-roster' && destination.droppableId.startsWith('track-')) {
      const trackId = destination.droppableId;
      const playerId = result.draggableId;
      
      setTracks(prevTracks => prevTracks.map(track => 
        track.id === trackId ? { ...track, assignedPlayerId: playerId } : track
      ));
    }
  };
  
  const handleClearAssignment = (trackId) => {
    setTracks(prevTracks => prevTracks.map(track => 
      track.id === trackId ? { ...track, assignedPlayerId: null } : track
    ));
  };
  
  const handlePublish = async () => {
    if (match) {
      await Match.update(match.id, { status: "processing" });
      navigate(createPageUrl("Matches"));
    }
  };

  if (isLoading) {
    return <div className="bg-slate-900 text-white min-h-screen flex items-center justify-center">Loading Mapping Interface...</div>;
  }

  if (!match) {
    return <div className="bg-slate-900 text-white min-h-screen flex items-center justify-center">Match not found.</div>;
  }

  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div className="flex flex-col h-screen bg-slate-100 overflow-hidden">
        <Button 
          variant="outline" 
          onClick={() => navigate(createPageUrl("Matches"))}
          className="absolute top-4 left-4 z-20 bg-white/80 backdrop-blur-sm"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Matches
        </Button>
        
        <MappingHeader match={match} />
        
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-[320px_1fr_380px] gap-4 p-4 min-h-0">
          {/* Left: Player Roster */}
          <PlayerRoster players={players} />

          {/* Center: Video Player */}
          <VideoPlayer match={match} />
          
          {/* Right: Track List */}
          <TrackList 
            tracks={tracks}
            players={players} 
            onClearAssignment={handleClearAssignment}
          />
        </div>
        
        <MappingFooter tracks={tracks} onPublish={handlePublish} />
      </div>
    </DragDropContext>
  );
}