
import React, { useState, useEffect, useMemo } from "react";
import { Match } from "@/api/entities";
import { Academy } from "@/api/entities";
import { Team } from "@/api/entities";
import { Camera } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus, AlertCircle, Video, Loader, RefreshCw } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { isAfter, isBefore, parseISO, startOfDay, endOfDay } from "date-fns";
import { useToast } from "@/components/ui/use-toast";

import MatchFilters from "../components/matches/MatchFilters";
import MatchCard from "../components/matches/MatchCard";
import MatchPagination from "../components/matches/MatchPagination";
import { getMatchUpdate } from "@/api/functions";
import { syncAllMatches } from "@/api/functions";
import MatchDetailsModal from "../components/matches/MatchDetailsModal";

const ITEMS_PER_PAGE = 12;

export default function Matches() {
  const [matches, setMatches] = useState([]);
  const [teams, setTeams] = useState([]);
  const [cameras, setCameras] = useState([]);
  const [academy, setAcademy] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const navigate = useNavigate();
  const { toast } = useToast();

  const [filters, setFilters] = useState({
    status: "all",
    teams: [], // changed from single 'team' to multi-select
    dateFrom: null,
    dateTo: null
  });

  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [selectedMatch, setSelectedMatch] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const user = await User.me();
      const academies = await Academy.filter({ coach_email: user.email });
      if (academies.length > 0) {
        const currentAcademy = academies[0];
        setAcademy(currentAcademy);
        
        const [academyMatches, academyTeams, academyCameras] = await Promise.all([
          Match.filter({ academy_id: currentAcademy.id }, '-match_date'),
          Team.filter({ academy_id: currentAcademy.id }),
          Camera.filter({ academy_id: currentAcademy.id })
        ]);
        
        setMatches(academyMatches);
        setTeams(academyTeams);
        setCameras(academyCameras);
      } else {
        setError("No academy found for the current user's email.");
        setMatches([]);
        setTeams([]);
        setCameras([]);
      }
    } catch (err) {
      console.error("Error loading data:", err);
      setError("Failed to load matches data. Please refresh the page.");
      setMatches([]);
      setTeams([]);
      setCameras([]);
    }
    setIsLoading(false);
  };

  // Sync single match status
  const syncMatchStatus = async (match) => {
    if (!match.abwab_match_id) return;

    // Skip finished/completed matches
    const s = (match.raw_status || match.status || "").toLowerCase();
    if (s === "finished" || s === "completed") {
      return;
    }
    
    try {
      const { data: response, error } = await getMatchUpdate({
        match_id: match.abwab_match_id
      });

      if (error) {
        console.error("Failed to sync match:", error);
        return;
      }

      if (response.success && response.match) {
        // Update the match in database
        await Match.update(match.id, {
          status: response.match.status,
          raw_status: response.match.raw_status,
          duration: response.match.duration ?? match.duration, // Update extra fields
          match_date: response.match.start_time ?? match.match_date, // Update extra fields
          recording_start_time: response.match.recording_start_time ?? match.recording_start_time, // Update extra fields
          end_time: response.match.end_time ?? match.end_time, // Update extra fields
          recording: response.match.recording,
          uploaded: response.match.uploaded,
          live: response.match.live,
          recording_path: response.match.recording_path,
          share_key: response.match.share_key,
          last_updated: response.match.last_updated
        });
        
        // Reload matches to show updated status
        loadData();
      }
    } catch (error) {
      console.error("Error syncing match:", error);
    }
  };

  // Sync all matches
  const syncAllMatchStatuses = async () => {
    setIsSyncing(true);
    try {
      const { data: response, error } = await syncAllMatches();

      if (error) {
        toast({
          variant: "destructive",
          title: "Sync Failed",
          description: `Could not sync matches: ${error.details || 'Unknown error'}`
        });
        return;
      }

      if (response.success && response.matches) {
        // Only consider matches linked to cameras of this academy
        const allowedCameraIds = new Set(cameras.map(c => c.abwab_camera_id));
        const filteredApiMatches = response.matches.filter(m => m.recording_system_id && allowedCameraIds.has(m.recording_system_id));

        let updatedCount = 0;

        for (const apiMatch of filteredApiMatches) {
          const localMatch = matches.find(m => m.abwab_match_id === apiMatch.abwab_match_id);
          if (!localMatch) continue;

          // Skip finished/completed locally
          const localStatus = (localMatch.raw_status || localMatch.status || "").toLowerCase();
          if (localStatus === "finished" || localStatus === "completed") continue;

          await Match.update(localMatch.id, {
            status: apiMatch.status,
            raw_status: apiMatch.raw_status,
            // Update extra fields per request
            duration: apiMatch.duration ?? localMatch.duration,
            match_date: apiMatch.start_time ?? localMatch.match_date, // Changed from match_date to start_time as per API
            recording_start_time: apiMatch.recording_start_time ?? localMatch.recording_start_time,
            end_time: apiMatch.end_time ?? localMatch.end_time,
            recording: apiMatch.recording,
            uploaded: apiMatch.uploaded,
            live: apiMatch.live,
            recording_path: apiMatch.recording_path,
            share_key: apiMatch.share_key,
            last_updated: apiMatch.last_updated
          });
          updatedCount += 1;
        }

        toast({
          title: "Matches Synced",
          description: `Updated ${updatedCount} match${updatedCount === 1 ? '' : 'es'} (excluding finished).`
        });

        // Reload matches to show updated statuses and times
        loadData();
      }
    } catch (error) {
      console.error("Error syncing all matches:", error);
      toast({
        variant: "destructive",
        title: "Sync Failed",
        description: `Error syncing matches: ${error.message}`
      });
    }
    setIsSyncing(false);
  };

  // Filter and paginate matches
  const filteredMatches = useMemo(() => {
    let filtered = matches;

    // Status filter
    if (filters.status !== "all") {
      filtered = filtered.filter(match => (match.status || "").toLowerCase() === filters.status);
    }

    // Multi-team filter
    if (Array.isArray(filters.teams) && filters.teams.length > 0) {
      const teamSet = new Set(filters.teams);
      filtered = filtered.filter(match =>
        teamSet.has(match.home_team_id) || teamSet.has(match.away_team_id)
      );
    }

    // Date range filter
    if (filters.dateFrom || filters.dateTo) {
      filtered = filtered.filter(match => {
        if (!match.match_date) return false;
        
        try {
          const matchDate = parseISO(match.match_date);
          
          if (filters.dateFrom && isBefore(matchDate, startOfDay(filters.dateFrom))) {
            return false;
          }
          
          if (filters.dateTo && isAfter(matchDate, endOfDay(filters.dateTo))) {
            return false;
          }
          
          return true;
        } catch (error) {
          return false;
        }
      });
    }

    return filtered;
  }, [matches, filters]);

  // Pagination
  const totalPages = Math.ceil(filteredMatches.length / ITEMS_PER_PAGE);
  const paginatedMatches = useMemo(() => {
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredMatches.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  }, [filteredMatches, currentPage]);

  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [filters]);

  const handleFilterChange = (newFilters) => {
    setFilters(newFilters);
  };

  const handleClearFilters = () => {
    setFilters({
      status: "all",
      teams: [], // Changed from single 'team' to multi-select array
      dateFrom: null,
      dateTo: null
    });
  };

  const handleViewDetails = (match) => {
    // Removed page-wide sync to avoid full page loading spinner when opening the modal
    // syncMatchStatus(match);
    setSelectedMatch(match);
    setIsDetailsOpen(true);
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex items-center space-x-2">
          <Loader className="w-6 h-6 animate-spin text-blue-600" />
          <span className="text-lg">Loading Matches...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="p-4 lg:p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Matches</h1>
              <p className="text-slate-600 mt-1">Manage and view your academy matches.</p>
            </div>
            <div className="flex gap-3">
              {academy && (
                <>
                  <Button 
                    variant="outline"
                    onClick={syncAllMatchStatuses}
                    disabled={isSyncing}
                    className="hover:bg-[rgba(1,32,63,0.06)]"
                    style={{ borderColor: "var(--brand-navy)", color: "var(--brand-navy)" }}
                  >
                    {isSyncing ? (
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <RefreshCw className="w-4 h-4 mr-2" />
                    )}
                    Sync Status
                  </Button>
                  <Button 
                    onClick={() => navigate(createPageUrl("NewMatch"))} 
                    className="shadow-lg text-white"
                    style={{ backgroundColor: "var(--brand-navy)" }}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    New Match
                  </Button>
                </>
              )}
            </div>
          </div>

          {/* Error Alert */}
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Filters */}
          <MatchFilters
            filters={filters}
            onFilterChange={handleFilterChange}
            teams={teams}
            onClearFilters={handleClearFilters}
          />

          {/* Results Summary */}
          {filteredMatches.length > 0 && (
            <div className="text-sm text-slate-600">
              {filteredMatches.length === matches.length 
                ? `Showing all ${matches.length} matches`
                : `Showing ${filteredMatches.length} of ${matches.length} matches`
              }
            </div>
          )}

          {/* Matches Grid */}
          {paginatedMatches.length > 0 ? (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {paginatedMatches.map((match) => (
                  <MatchCard 
                    key={match.id} 
                    match={match} 
                    onViewDetails={handleViewDetails}
                  />
                ))}
              </div>

              {/* Pagination */}
              <MatchPagination
                currentPage={currentPage}
                totalPages={totalPages}
                totalItems={filteredMatches.length}
                itemsPerPage={ITEMS_PER_PAGE}
                onPageChange={handlePageChange}
              />
            </>
          ) : (
            <Card>
              <CardContent className="text-center py-16">
                <Video className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                <h3 className="text-xl font-medium text-slate-900 mb-2">
                  {matches.length === 0 ? "No Matches Found" : "No Matches Match Your Filters"}
                </h3>
                <p className="text-slate-600 mb-6">
                  {matches.length === 0 
                    ? "You have not created any matches yet."
                    : "Try adjusting your filters or clear them to see all matches."
                  }
                </p>
                {matches.length === 0 && academy ? (
                  <Button 
                    onClick={() => navigate(createPageUrl("NewMatch"))} 
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create Your First Match
                  </Button>
                ) : (
                  <Button variant="outline" onClick={handleClearFilters}>
                    Clear Filters
                  </Button>
                )}
              </CardContent>
            </Card>
          )}

          <MatchDetailsModal
            open={isDetailsOpen}
            onClose={() => { setIsDetailsOpen(false); setSelectedMatch(null); }}
            match={selectedMatch}
            onUpdated={loadData}
            onDeleted={loadData}
          />
        </div>
      </div>
    </div>
  );
}
