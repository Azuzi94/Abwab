import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { LogIn, Shield, Users, MapPin, ChevronRight } from "lucide-react";
import { createPageUrl } from "@/utils";
import { submitAccessRequest } from "@/api/functions";

export default function Access() {
  const [form, setForm] = useState({
    academy_name: "",
    players_count: "",
    fields_count: "",
    contact_name: "",
    contact_email: "",
    contact_phone: "",
    notes: ""
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    (async () => {
      try { setUser(await User.me()); } catch {}
    })();
  }, []);

  const handleChange = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  const handleSignIn = async () => {
    const callback = new URL(createPageUrl("Dashboard"), window.location.origin).toString();
    try {
      await User.loginWithRedirect(callback);
    } catch {
      await User.login();
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    const payload = {
      ...form,
      players_count: parseInt(form.players_count || "0"),
      fields_count: parseInt(form.fields_count || "0")
    };
    const { data } = await submitAccessRequest(payload);
    setSubmitting(false);
    if (data?.success) {
      setSubmitted(true);
    } else {
      alert("Could not submit your request. Please try again.");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 py-10">
      <div className="mx-auto max-w-6xl px-4">
        <div className="mb-8 text-white/90 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center shadow">
              <span className="text-white font-bold">GS</span>
            </div>
            <div>
              <div className="font-extrabold text-lg">Gametime Solutions</div>
              <div className="text-xs text-white/70 -mt-0.5">Abwab Platform Access</div>
            </div>
          </div>
          <Button variant="outline" onClick={handleSignIn} className="text-white border-white/30 hover:bg-white/10">
            <LogIn className="w-4 h-4 mr-2" /> Sign in
          </Button>
        </div>

        <div className="relative rounded-3xl bg-white/5 backdrop-blur-md border border-white/10 shadow-2xl overflow-hidden">
          <div className="grid md:grid-cols-2">
            {/* Left panel - Sign in styling */}
            <div className="p-8 md:p-10">
              <div className="text-white">
                <div className="w-10 h-10 rounded-full bg-indigo-500/90 mb-5"></div>
                <h1 className="text-3xl font-extrabold leading-tight">Abwab Academy Access</h1>
                <p className="mt-1 text-white/80">Welcome! Sign in to continue.</p>
              </div>

              <div className="mt-6 space-y-3">
                <div className="bg-white/10 rounded-lg p-3 text-white/70 text-sm">
                  <Shield className="inline w-4 h-4 mr-2" />
                  Secure Single Sign-On • Privacy-first
                </div>
                <div className="bg-white/10 rounded-lg p-3 text-white/70 text-sm">
                  <Users className="inline w-4 h-4 mr-2" />
                  Team-based permissions (Admin & Coach)
                </div>
              </div>

              <Button onClick={handleSignIn} className="mt-8 w-full bg-emerald-600 hover:bg-emerald-700 shadow-lg">
                <LogIn className="w-4 h-4 mr-2" />
                Sign In
              </Button>

              <p className="mt-3 text-xs text-white/70 text-center">
                No account? Request access using the form.
              </p>
            </div>

            {/* Right panel - Request access form */}
            <div className="p-8 md:p-10 bg-gradient-to-br from-white/5 to-white/10">
              <h3 className="text-white text-2xl font-bold">Request Access</h3>
              <p className="text-white/80 text-sm">Tell us about your academy. We’ll review and approve shortly.</p>

              {submitted ? (
                <div className="mt-6 p-4 rounded-lg bg-emerald-600/10 text-emerald-200 border border-emerald-500/30">
                  Thank you! Your request has been submitted. Our team will reach out after approval.
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="mt-6 grid grid-cols-1 gap-4">
                  <div>
                    <Label className="text-white/80">Academy Name</Label>
                    <Input value={form.academy_name} onChange={(e) => handleChange("academy_name", e.target.value)} className="bg-white/90" required />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-white/80">Number of Players</Label>
                      <Input type="number" min="0" value={form.players_count} onChange={(e) => handleChange("players_count", e.target.value)} className="bg-white/90" required />
                    </div>
                    <div>
                      <Label className="text-white/80">Number of Fields</Label>
                      <Input type="number" min="0" value={form.fields_count} onChange={(e) => handleChange("fields_count", e.target.value)} className="bg-white/90" required />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-white/80">Contact Name</Label>
                      <Input value={form.contact_name} onChange={(e) => handleChange("contact_name", e.target.value)} className="bg-white/90" required />
                    </div>
                    <div>
                      <Label className="text-white/80">Contact Email</Label>
                      <Input type="email" value={form.contact_email} onChange={(e) => handleChange("contact_email", e.target.value)} className="bg-white/90" required />
                    </div>
                  </div>
                  <div>
                    <Label className="text-white/80">Contact Phone (optional)</Label>
                    <Input value={form.contact_phone} onChange={(e) => handleChange("contact_phone", e.target.value)} className="bg-white/90" />
                  </div>
                  <div>
                    <Label className="text-white/80">Notes (optional)</Label>
                    <Input value={form.notes} onChange={(e) => handleChange("notes", e.target.value)} className="bg-white/90" placeholder="Anything else we should know?" />
                  </div>

                  <Button type="submit" disabled={submitting} className="mt-2 bg-indigo-600 hover:bg-indigo-700">
                    {submitting ? "Submitting..." : <>Submit Request <ChevronRight className="w-4 h-4 ml-1" /></>}
                  </Button>
                </form>
              )}
            </div>
          </div>
        </div>

        <div className="text-center text-white/50 text-xs mt-6">
          By requesting access, you agree to abide by our acceptable use and privacy guidelines.
        </div>
      </div>
    </div>
  );
}