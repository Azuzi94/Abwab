import { base44 } from './base44Client';


export const Academy = base44.entities.Academy;

export const Player = base44.entities.Player;

export const PlayerPerformance = base44.entities.PlayerPerformance;

export const Team = base44.entities.Team;

export const Match = base44.entities.Match;

export const Camera = base44.entities.Camera;

export const TeamPlayer = base44.entities.TeamPlayer;

export const AuditLog = base44.entities.AuditLog;

export const TeamAssignment = base44.entities.TeamAssignment;

export const AccessRequest = base44.entities.AccessRequest;

export const CoachPlayer = base44.entities.CoachPlayer;

export const UserInvite = base44.entities.UserInvite;

export const TrackingJob = base44.entities.TrackingJob;

export const TrackAssignment = base44.entities.TrackAssignment;



// auth sdk:
export const User = base44.auth;