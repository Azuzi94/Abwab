import { base44 } from './base44Client';


export const abwabMatches = base44.functions.abwabMatches;

export const abwabRecordingUrl = base44.functions.abwabRecordingUrl;

export const createTeamWithClub = base44.functions.createTeamWithClub;

export const createMatch = base44.functions.createMatch;

export const getCameras = base44.functions.getCameras;

export const getMatchUpdate = base44.functions.getMatchUpdate;

export const syncAllMatches = base44.functions.syncAllMatches;

export const getWatchUrl = base44.functions.getWatchUrl;

export const deleteMatch = base44.functions.deleteMatch;

export const findDuplicates = base44.functions.findDuplicates;

export const mergePlayers = base44.functions.mergePlayers;

export const submitAccessRequest = base44.functions.submitAccessRequest;

export const afterMatchAnalysis = base44.functions.afterMatchAnalysis;

