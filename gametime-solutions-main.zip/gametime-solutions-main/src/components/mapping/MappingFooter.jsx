
import React from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle, AlertCircle } from "lucide-react";

export default function MappingFooter({ tracks, onPublish }) {
  const unassignedCount = tracks.filter(t => !t.assignedPlayerId).length;
  const allAssigned = unassignedCount === 0;

  return (
    <div className="bg-white border-t border-slate-200 p-4 flex justify-between items-center shadow-top z-10">
      <div>
        {allAssigned ? (
          <div className="flex items-center gap-2 text-green-600">
            <CheckCircle className="w-5 h-5" />
            <span className="font-medium">Validation complete. Ready to publish.</span>
          </div>
        ) : (
          <div className="flex items-center gap-2 text-yellow-600">
            <AlertCircle className="w-5 h-5" />
            <span className="font-medium">{unassignedCount} unassigned tracks remaining.</span>
          </div>
        )}
      </div>
      <Button 
        onClick={onPublish}
        disabled={!allAssigned}
        className="shadow-lg disabled:cursor-not-allowed"
        style={{ 
          background: allAssigned ? 'linear-gradient(135deg, #001F3F, #808080)' : '#CCCCCC', 
          color: 'white' 
        }}
      >
        Publish Assignments
      </Button>
    </div>
  );
}
