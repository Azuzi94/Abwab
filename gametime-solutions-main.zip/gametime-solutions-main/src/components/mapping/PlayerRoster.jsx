import React from "react";
import { Draggable, Droppable } from "@hello-pangea/dnd";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { GripVertical } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function PlayerRoster({ players }) {
  return (
    <Card className="flex flex-col h-full border-0 shadow-lg shadow-slate-200/50">
      <CardHeader>
        <CardTitle>Player Roster</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto p-2">
        <Droppable droppableId="player-roster" isDropDisabled={true}>
          {(provided) => (
            <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-2">
              {players.map((player, index) => (
                <Draggable key={player.id} draggableId={player.id} index={index}>
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                      className={`p-3 rounded-lg flex items-center gap-3 transition-shadow ${
                        snapshot.isDragging ? 'bg-blue-100 shadow-xl' : 'bg-white border'
                      }`}
                    >
                      <GripVertical className="w-5 h-5 text-slate-400" />
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={player.photo_url} />
                        <AvatarFallback className="bg-slate-200">
                          {player.first_name[0]}{player.last_name[0]}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-medium text-slate-900">
                          {player.first_name} {player.last_name}
                        </p>
                        <p className="text-sm text-slate-500">#{player.jersey_number}</p>
                      </div>
                      <Badge variant="outline" className="border-green-300 bg-green-50 text-green-700">
                        98%
                      </Badge>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </CardContent>
    </Card>
  );
}