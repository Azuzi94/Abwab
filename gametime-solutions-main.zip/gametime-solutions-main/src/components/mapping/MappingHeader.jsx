
import React from "react";
import { Button } from "@/components/ui/button";

export default function MappingHeader({ match }) {
  return (
    <div className="bg-white/80 backdrop-blur-sm border-b border-slate-200 p-4 flex justify-center items-center relative">
        <div className="text-center">
            <h1 className="text-xl font-bold" style={{ color: '#001F3F' }}>{match.match_name}</h1>
            <p className="text-slate-600">Player Mapping</p>
        </div>
        <div className="absolute right-4 top-1/2 -translate-y-1/2">
            <Button className="shadow-lg" style={{ background: 'linear-gradient(135deg, #001F3F, #808080)', color: 'white' }}>
                Auto-assign (85%)
            </Button>
        </div>
    </div>
  );
}
