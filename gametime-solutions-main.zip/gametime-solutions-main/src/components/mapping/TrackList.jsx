import React from "react";
import { Droppable, Draggable } from "@hello-pangea/dnd";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { UserPlus, X, Check } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function TrackList({ tracks, players, onClearAssignment }) {
  const getPlayerById = (id) => players.find(p => p.id === id);

  const Track = ({ track, player }) => (
    <div className={`p-3 rounded-lg flex items-center gap-3 border ${
      player ? 'border-green-300 bg-green-50' : 'border-dashed bg-slate-50'
    }`}>
      <img src={track.thumbnail} alt="Track thumbnail" className="w-12 h-16 object-cover rounded-md" />
      <div className="flex-1">
        {player ? (
          <>
            <div className="flex items-center gap-2">
              <Avatar className="w-8 h-8">
                <AvatarImage src={player.photo_url} />
                <AvatarFallback>{player.first_name[0]}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-semibold text-slate-900">{player.first_name} {player.last_name}</p>
                <p className="text-sm text-slate-500">#{player.jersey_number}</p>
              </div>
            </div>
            <Badge variant="outline" className="mt-2 text-green-700 bg-white border-green-200">
              <Check className="w-3 h-3 mr-1" /> Assigned
            </Badge>
          </>
        ) : (
          <>
            <p className="font-medium text-slate-600">Unassigned Track</p>
            <p className="text-sm text-slate-400">Drag player here</p>
            <div className="flex items-center gap-2 mt-1">
              <UserPlus className="w-4 h-4 text-slate-400" />
              <p className="text-xs text-slate-500">
                AI Suggests: #{track.detectedJersey} ({(track.confidence * 100).toFixed(0)}%)
              </p>
            </div>
          </>
        )}
      </div>
      {player && (
        <Button variant="ghost" size="icon" onClick={() => onClearAssignment(track.id)}>
          <X className="w-4 h-4 text-red-500" />
        </Button>
      )}
    </div>
  );

  return (
    <Card className="flex flex-col h-full border-0 shadow-lg shadow-slate-200/50">
      <CardHeader>
        <CardTitle>Detected Player Tracks</CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto p-2">
        <div className="space-y-2">
          {tracks.map((track) => (
            <Droppable key={track.id} droppableId={track.id}>
              {(provided, snapshot) => (
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  className={`rounded-lg transition-colors ${
                    snapshot.isDraggingOver ? 'bg-blue-100' : ''
                  }`}
                >
                  <Track track={track} player={getPlayerById(track.assignedPlayerId)} />
                  <div style={{ display: 'none' }}>{provided.placeholder}</div>
                </div>
              )}
            </Droppable>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}