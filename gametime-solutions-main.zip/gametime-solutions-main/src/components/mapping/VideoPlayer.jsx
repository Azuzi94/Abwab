import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Play, Pause, SkipBack, SkipForward, Volume2 } from "lucide-react";
import { Slider } from "@/components/ui/slider";

export default function VideoPlayer({ match }) {
  const events = [
    { type: 'goal', time: 15, description: 'Goal by #10' },
    { type: 'sub', time: 45, description: 'Sub: #7 off, #18 on' },
    { type: 'sprint', time: 62, description: 'Sprint by #11' },
  ];
  const duration = match?.duration_minutes || 90;

  return (
    <Card className="flex flex-col h-full border-0 shadow-lg shadow-slate-200/50">
      <CardContent className="flex-1 flex flex-col p-4">
        {/* Video Player */}
        <div className="flex-1 bg-slate-900 rounded-lg mb-4 relative overflow-hidden">
          {match?.video_url ? (
            <video
              key={match.video_url}
              className="w-full h-full object-contain"
              controls
            >
              <source src={match.video_url} type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <p className="text-white text-2xl font-bold">No Video Available</p>
            </div>
          )}
        </div>
        
        {/* Scrubber / Timeline */}
        <div className="relative h-6 mb-2">
          <Slider defaultValue={[25]} max={100} step={1} className="h-full"/>
          {events.map(event => (
            <div 
              key={event.time} 
              className={`absolute -top-1 w-3 h-3 rounded-full border-2 border-white shadow-md ${
                event.type === 'goal' ? 'bg-green-500' : 
                event.type === 'sub' ? 'bg-yellow-500' : 'bg-blue-500'
              }`}
              style={{ left: `${(event.time / duration) * 100}%` }}
              title={event.description}
            ></div>
          ))}
        </div>
        
        {/* Controls */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button className="text-slate-600 hover:text-slate-900"><SkipBack/></button>
            <button className="w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-lg">
              <Play className="ml-1" />
            </button>
            <button className="text-slate-600 hover:text-slate-900"><SkipForward/></button>
          </div>
          <div className="text-sm text-slate-600">
            22:30 / {duration}:00
          </div>
          <div className="flex items-center gap-2">
            <Volume2 className="text-slate-600"/>
            <Slider defaultValue={[70]} max={100} step={1} className="w-24"/>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}