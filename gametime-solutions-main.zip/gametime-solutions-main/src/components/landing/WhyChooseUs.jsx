import React from "react";
import { Layers, Globe2, BarChart3, Rocket } from "lucide-react";

const items = [
  { icon: Layers, title: "4 Divisions / 1 Connected Ecosystem", desc: "Consulting, product, video, and data—seamlessly integrated." },
  { icon: Globe2, title: "Built in Saudi. Made for Saudi.", desc: "Crafted for the needs of Saudi football academies." },
  { icon: BarChart3, title: "Driven by Data. Designed for Impact.", desc: "Data pipelines, dashboards, and outcomes that matter." },
  { icon: Rocket, title: "Strategy Meets Execution", desc: "From vision to delivery—we own the end‑to‑end journey." },
];

export default function WhyChooseUs() {
  return (
    <section id="why" className="bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <h2 className="text-3xl font-extrabold text-[#1E293B] text-center">Why Abwab</h2>
        <p className="mt-3 text-[#64748B] text-center max-w-2xl mx-auto">An ambitious, Saudi‑born approach to sports innovation.</p>
        <div className="mt-12 grid gap-8 sm:grid-cols-2">
          {items.map((i) => (
            <div key={i.title} className="p-6 rounded-2xl border border-slate-200 bg-white shadow-sm hover:shadow-md transition-shadow flex items-start gap-4">
              <div className="p-3 rounded-xl" style={{ background: 'rgba(1,32,63,0.05)' }}>
                <i.icon className="w-5 h-5" style={{ color: 'var(--brand-navy)' }} />
              </div>
              <div>
                <p className="text-slate-900 font-semibold">{i.title}</p>
                <p className="text-slate-600 text-sm mt-1">{i.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}