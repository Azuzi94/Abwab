import React from "react";
import { Button } from "@/components/ui/button";
import { LogIn } from "lucide-react";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

export default function LandingHeader() {
  const handleLogin = async () => {
    const callback = new URL(createPageUrl("Dashboard"), window.location.origin).toString();
    try {
      await User.loginWithRedirect(callback);
    } catch {
      await User.login();
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white border-b border-slate-200">
      <div className="mx-auto px-4 max-w-7xl sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3 logo-wrap">
          <img
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/e99f9685b_GametimeAbwab-02-trans.jpg"
            alt="Gametime Solutions" className="h-7 w-auto logo-blend" />


        </div>

        <nav className="hidden md:flex items-center gap-6 text-sm text-slate-700">
          <a href="#features" className="hover:text-slate-900">Features</a>
          <a href="#product" className="hover:text-slate-900">Product</a>
          <a href="#why" className="hover:text-slate-900">Why Abwab</a>
          <a href="#team" className="hover:text-slate-900">Team</a>
          <a href="#contact" className="hover:text-slate-900">Contact</a>
        </nav>

      </div>
    </header>);

}