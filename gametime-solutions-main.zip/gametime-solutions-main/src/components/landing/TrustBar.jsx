import React from "react";

export default function TrustBar() {
  return (
    <section className="bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-slate-600">
            Trusted by academies across Riyadh, Jeddah, and Dammam
          </p>
          <div className="flex items-center gap-4 opacity-80">
            <img
              src="https://images.unsplash.com/photo-1542744173-8e7e53415bb0?q=80&w=200&auto=format&fit=crop"
              alt="Partner 1"
              className="h-8 w-auto rounded" />

            <img
              src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=200&auto=format&fit=crop"
              alt="Partner 2"
              className="h-8 w-auto rounded" />

            <img
              src="https://images.unsplash.com/photo-1522669830477-93b22a04125f?q=80&w=200&auto=format&fit=crop"
              alt="Partner 3"
              className="h-8 w-auto rounded" />

            <div className="text-xs text-slate-500">+ many more</div>
          </div>
        </div>
      </div>
    </section>);

}