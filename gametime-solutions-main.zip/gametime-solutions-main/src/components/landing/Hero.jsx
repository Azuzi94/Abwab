
import React from "react";
import { Button } from "@/components/ui/button";
import { LogIn, CalendarDays, Video, Upload, Share2, ArrowRight } from "lucide-react";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";

export default function Hero() {
  const handleLogin = async () => {
    const callback = new URL(createPageUrl("Dashboard"), window.location.origin).toString();
    try {
      await User.loginWithRedirect(callback);
    } catch {
      await User.login();
    }
  };

  return (
    <section
      id="hero"
      className="relative overflow-hidden"
      style={{
        // fallback color ensures contrast even if CSS variables aren't loaded yet
        background: "linear-gradient(180deg, var(--brand-navy, #01203F) 0%, #00182F 100%)"
      }}>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pt-16 pb-20 lg:py-28">
        <div className="grid lg:grid-cols-2 gap-10 items-center">
          {/* Left: Headline + CTAs */}
          <div className="text-white">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/20 bg-white/10 backdrop-blur-sm text-xs">
              Built for Saudi Football
            </div>

            <h1 className="mt-5 font-extrabold leading-tight tracking-tight">
              <span className="block text-4xl sm:text-5xl lg:text-6xl">Turn Matches into</span>
              <span className="block text-4xl sm:text-5xl lg:text-6xl text-[color:var(--brand-yellow)]">Actionable Insights.</span>
            </h1>

            <p className="mt-4 text-white/90 max-w-2xl">
              Abwab powers academies with recording, analysis, and sharing tools—so coaches focus on development, not admin.
            </p>

            <div className="mt-7 flex flex-wrap gap-3">
              <button onClick={handleLogin} className="btn-primary shadow-lg rounded-md px-5 py-3 text-base font-semibold">
                Login to Abwab
              </button>          
            </div>

            {/* Feature bullets */}
            <div className="mt-8 grid grid-cols-2 gap-3 max-w-md">
              <div className="flex items-center gap-2 text-white/90">
                <CalendarDays className="w-4 h-4 text-[color:var(--brand-yellow)]" /> <span className="text-sm">Plan Matches</span>
              </div>
              <div className="flex items-center gap-2 text-white/90">
                <Video className="w-4 h-4 text-emerald-300" /> <span className="text-sm">Record & Upload</span>
              </div>
              <div className="flex items-center gap-2 text-white/90">
                <Upload className="w-4 h-4 text-[color:var(--brand-yellow)]" /> <span className="text-sm">Auto Processing</span>
              </div>
              <div className="flex items-center gap-2 text-white/90">
                <Share2 className="w-4 h-4 text-rose-300" /> <span className="text-sm">Share Highlights</span>
              </div>
            </div>
          </div>

          {/* Right: Feature card */}
          <div className="relative">
            <Card className="bg-white shadow-2xl rounded-2xl overflow-hidden">
              <CardContent className="p-6">
                <div>
                  <div className="text-xs font-semibold" style={{ color: 'var(--brand-red)' }}>Everyday Abwab</div>
                  <h3 className="mt-1 text-2xl font-bold text-slate-900 leading-snug">
                    High‑impact Sessions for Productive Teams
                  </h3>
                </div>

                <div className="mt-5 grid grid-cols-1 gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-rose-100 flex items-center justify-center">
                      <CalendarDays className="w-4 h-4 text-rose-600" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-slate-800">Plan Matches</div>
                      <div className="text-xs text-slate-500">Create fixtures, select fields, set durations</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-sky-100 flex items-center justify-center">
                      <Video className="w-4 h-4 text-sky-700" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-slate-800">Record & Upload</div>
                      <div className="text-xs text-slate-500">Capture tactical and panoramic views</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-amber-100 flex items-center justify-center">
                      <Upload className="w-4 h-4 text-amber-700" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-slate-800">Auto Processing</div>
                      <div className="text-xs text-slate-500">Post‑processing and secure storage</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-purple-100 flex items-center justify-center">
                      <Share2 className="w-4 h-4 text-purple-700" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-slate-800">Share Highlights</div>
                      <div className="text-xs text-slate-500">With coaches, players, and parents</div>
                    </div>
                  </div>
                </div>

                <a href="#product" className="block">
                  <Button className="mt-6 w-full bg-rose-500 hover:bg-rose-600 text-white">
                    See Abwab in Action
                  </Button>
                </a>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>);

}