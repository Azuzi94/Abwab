
import React from "react";

export default function Team() {
  const members = [
    {
      name: "Abdulaziz K. Alrasheed",
      role: "Co‑Founder - CTO",
      photo_url: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/857147906_Abdulaziz.jpg"
    },
    {
      name: "Basem I. AlHobaish",
      role: "Co‑Founder - CEO",
      photo_url: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/09cb3dccb_Basem.jpg"
    },
    {
      name: "Faisal A. Aljahdali",
      role: "Co‑Founder - CMO",
      photo_url: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/f0992cb8d_Faisal.jpg"
    }
  ];

  return (
    <section id="team" className="bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <h2 className="text-3xl font-extrabold text-[#1E293B] text-center">Our Team</h2>
        <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {members.map((m) => (
            <div key={m.name} className="rounded-2xl border border-slate-200 bg-white p-6 text-center shadow-sm hover:shadow-md transition-shadow">
              <div className="w-28 h-28 mx-auto rounded-full overflow-hidden bg-slate-100 ring-4 ring-white shadow">
                <img src={m.photo_url} alt={m.name} className="w-full h-full object-cover" />
              </div>
              <div className="mt-4 font-semibold text-slate-900">{m.name}</div>
              <div className="text-sm text-slate-600">{m.role}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
