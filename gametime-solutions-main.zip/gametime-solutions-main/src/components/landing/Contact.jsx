
import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { SendEmail } from "@/api/integrations";
import { GraduationCap, Wrench, Users } from "lucide-react";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const handle = (k, v) => setForm((s) => ({ ...s, [k]: v }));

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) return;
    setSubmitting(true);
    try {
      await SendEmail({
        to: "hello@gametimesolutions.sa",
        subject: "New website inquiry",
        body: `Name: ${form.name}\nEmail: ${form.email}\nPhone: ${form.phone || "-"}\n\nMessage:\n${form.message}`
      });
      setDone(true);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="contact" className="bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid gap-10 lg:grid-cols-2 items-start">
          {/* Left: Info */}
          <div>
            <h2 className="text-3xl font-extrabold text-slate-900">Get in Touch</h2>
            <p className="mt-4 text-slate-600 leading-relaxed">
              Abwab Sports‑Tech is a leading digital academy dedicated to nurturing the next generation of sports technology professionals.
              We provide cutting‑edge courses and hands‑on experience to help you succeed in the dynamic world of sports tech.
            </p>

            <div className="mt-8 space-y-6">
              <div className="flex gap-4">
                <div className="h-10 w-10 rounded-lg bg-sky-100 flex items-center justify-center">
                  <GraduationCap className="w-5 h-5 text-sky-700" />
                </div>
                <div>
                  <div className="font-semibold text-slate-900">Expert‑Led Courses</div>
                  <p className="text-sm text-slate-600">Learn from industry veterans and academic leaders at the forefront of sports technology.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="h-10 w-10 rounded-lg bg-sky-100 flex items-center justify-center">
                  <Wrench className="w-5 h-5 text-sky-700" />
                </div>
                <div>
                  <div className="font-semibold text-slate-900">Practical Experience</div>
                  <p className="text-sm text-slate-600">Gain invaluable hands‑on experience with real‑world projects and case studies.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="h-10 w-10 rounded-lg bg-sky-100 flex items-center justify-center">
                  <Users className="w-5 h-5 text-sky-700" />
                </div>
                <div>
                  <div className="font-semibold text-slate-900">Career Opportunities</div>
                  <p className="text-sm text-slate-600">Connect with our network of partner companies for internships and job placements.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Form Card */}
          <div className="bg-slate-50 rounded-2xl shadow-sm border border-slate-200">
            <div className="px-6 pt-6">
              <h3 className="text-2xl font-bold text-slate-900 text-center">Contact Us</h3>
              <p className="text-slate-600 text-sm text-center mt-1 mb-6">
                Tell us about your academy—we’ll reach out shortly.
              </p>
            </div>

            <div className="p-6">
              {done ? (
                <div className="p-4 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-center">
                  Thanks! Your message has been sent.
                </div>
              ) : (
                <form onSubmit={onSubmit} className="grid gap-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <Input
                      placeholder="Full name"
                      value={form.name}
                      onChange={(e) => handle("name", e.target.value)}
                      className="h-11"
                    />
                    <Input
                      type="email"
                      placeholder="Email address"
                      value={form.email}
                      onChange={(e) => handle("email", e.target.value)}
                      className="h-11"
                    />
                  </div>
                  <Input
                    placeholder="Phone (optional)"
                    value={form.phone}
                    onChange={(e) => handle("phone", e.target.value)}
                    className="h-11"
                  />
                  <Textarea
                    placeholder="Message"
                    className="min-h-[140px]"
                    value={form.message}
                    onChange={(e) => handle("message", e.target.value)}
                  />
                  <div className="flex justify-center pt-2">
                    <Button
                      type="submit"
                      disabled={submitting}
                      className="h-11 px-6 text-white"
                      style={{ backgroundColor: "var(--brand-navy)" }}
                    >
                      {submitting ? "Sending..." : "Send Message"}
                    </Button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
