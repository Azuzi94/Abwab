
import React from "react";
import { Linkedin, Twitter, Instagram } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-[color:var(--brand-navy)] text-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2 logo-wrap">
          <div className="leading-tight hidden sm:block">
            <div className="text-[color:var(--brand-red)] text-sm font-extrabold sm:text-base">Gametime</div>
            <div className="text-slate-300 pr-8 pl-8 text-xs -mt-0.5">Solutions</div>
          </div>
        </div>

        <div className="flex items-center gap-4 text-white/80">
          <a href="#features" className="hover:text-[color:var(--brand-red)] text-sm">Features</a>
          <a href="#product" className="hover:text-[color:var(--brand-red)] text-sm">Product</a>
          <a href="#why" className="hover:text-[color:var(--brand-red)] text-sm">Why Abwab</a>
          <a href="#team" className="hover:text-[color:var(--brand-red)] text-sm">Team</a>
          <a href="#contact" className="hover:text-[color:var(--brand-red)] text-sm">Contact</a>
        </div>
      </div>
      <div className="text-center text-xs text-white/60 pb-6">
        © {new Date().getFullYear()} Gametime Solutions
      </div>
    </footer>
  );
}
