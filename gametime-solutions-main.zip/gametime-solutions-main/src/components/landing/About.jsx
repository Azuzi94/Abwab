
import React from "react";
import useBrandImages from "./useBrandImages";
import { Skeleton } from "@/components/ui/skeleton";

export default function About() {
  const { images, loading } = useBrandImages();

  return (
    <section className="bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">About Gametime Solutions</h2>
            <p className="mt-4 text-slate-600 leading-relaxed">
              Gametime Solutions is a trusted consulting partner for football academies in Saudi Arabia.
              We combine local expertise with modern digital tools to help academies set up, grow, and
              operate efficiently—so coaches can focus on talent development.
            </p>
            <div className="mt-6 p-4 rounded-xl bg-emerald-50 border border-emerald-100">
              <p className="text-emerald-900 font-medium">
                Our mission: Helping academies grow, manage operations, and develop talent through technology.
              </p>
            </div>
          </div>
          <div className="rounded-2xl overflow-hidden shadow-2xl ring-1 ring-black/5">
            {loading ? (
              <Skeleton className="w-full h-[320px] rounded-2xl" />
            ) : (
              <img
                src={images.aboutUrl || "https://images.unsplash.com/photo-1504033010651-7da24c2bc6c5?q=80&w=2000&auto=format&fit=crop"}
                alt="Team huddle and planning"
                className="w-full h-[320px] object-cover"
              />
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
