import React from "react";
import { ArrowRight } from "lucide-react";

export default function CTA() {
  return (
    <section className="bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="rounded-2xl border border-slate-200 p-8 md:p-12 bg-gradient-to-r from-[#FFF7D1] to-white">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="text-2xl md:text-3xl font-extrabold text-slate-900">Ready to see Abwab in action?</h3>
              <p className="text-slate-600 mt-2">Book a demo or reach out—our team will get back to you within 24 hours.</p>
            </div>
            <a href="#contact" className="inline-flex items-center gap-2 btn-primary rounded-md px-5 py-3 font-semibold">
              Book a Demo <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}