import { useEffect, useState } from "react";
import { GenerateImage } from "@/api/integrations";

const STORAGE_KEY = "gs_brand_images_v1";
const TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

export default function useBrandImages() {
  const [images, setImages] = useState({
    heroUrl: null,
    aboutUrl: null,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    const load = async () => {
      try {
        const cached = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
        const now = Date.now();

        if (cached && cached.expiresAt && cached.expiresAt > now && cached.images) {
          if (!mounted) return;
          setImages(cached.images);
          setLoading(false);
          return;
        }

        // Generate two brand-matched visuals
        const [heroRes, aboutRes] = await Promise.all([
          GenerateImage({
            prompt:
              "Cinematic hero wide shot, Saudi football academy ambiance, evening stadium lights bokeh, subtle pitch patterns, brand palette emerald green and deep blue, professional sports-tech look, glossy lighting, 16:9, no text, ultra-detailed"
          }),
          GenerateImage({
            prompt:
              "Coaches analyzing match and player performance on a sleek tablet dashboard, team huddle in the background, modern sports-tech UI hints, brand palette emerald green and blue, clean professional, 4:3, no text"
          }),
        ]);

        const generated = {
          heroUrl: heroRes?.url || null,
          aboutUrl: aboutRes?.url || null,
        };

        localStorage.setItem(
          STORAGE_KEY,
          JSON.stringify({
            images: generated,
            createdAt: now,
            expiresAt: now + TTL_MS,
          })
        );

        if (!mounted) return;
        setImages(generated);
      } catch {
        // fallbacks will be used automatically
      } finally {
        if (mounted) setLoading(false);
      }
    };

    load();
    return () => {
      mounted = false;
    };
  }, []);

  return { images, loading };
}