import React from "react";
import { CalendarDays, Video, Upload, Share2 } from "lucide-react";

const features = [
  { icon: CalendarDays, title: "Plan Matches", desc: "Create fixtures, assign teams, and manage fields with ease.", color: "var(--brand-yellow)" },
  { icon: Video, title: "Record & Upload", desc: "Capture panoramic and tactical views with streamlined workflows.", color: "var(--brand-navy)" },
  { icon: Upload, title: "Auto Processing", desc: "Post‑processing and secure delivery—all handled automatically.", color: "var(--brand-green)" },
  { icon: Share2, title: "Share Highlights", desc: "Deliver clips to coaches, players, and parents with one click.", color: "var(--brand-red)" }
];

export default function Solutions() {
  return (
    <section id="features" className="bg-white">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20">
        <h2 className="text-3xl font-extrabold text-[#1E293B] text-center">What You Can Do</h2>
        <p className="mt-3 text-[#64748B] text-center max-w-2xl mx-auto">Powerful tools built for Saudi football academies.</p>

        <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => (
            <div key={f.title} className="relative overflow-hidden bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
              <div className="p-6 flex flex-col items-start">
                <div className="p-3 rounded-xl" style={{ background: 'rgba(1,32,63,0.05)' }}>
                  <f.icon className="w-6 h-6" style={{ color: f.color }} />
                </div>
                <h3 className="mt-4 font-semibold text-lg text-slate-900">{f.title}</h3>
                <p className="mt-2 text-slate-600 leading-relaxed">{f.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}