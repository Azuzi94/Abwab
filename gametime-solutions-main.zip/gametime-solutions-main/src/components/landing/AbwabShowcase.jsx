
import React from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { LayoutDashboard, CalendarDays, Users, ArrowRight } from "lucide-react";

const screenshots = {
  dashboard: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/7e5b5bd52_image.png",
  matches: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/a9e2ac3c6_image.png"
};

export default function AbwabShowcase() {
  return (
    <section id="product" className="bg-[#F1F5F9]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
        <div className="max-w-3xl mx-auto text-center">
          <span className="inline-flex items-center gap-2 px-3 py-1 text-xs font-semibold rounded-full bg-[#0369A1]/10 text-[#0369A1]">
            Built for Saudi Academies
          </span>
          <h2 className="mt-4 text-3xl font-extrabold text-[#1E293B]">A glimpse into your academy dashboard</h2>
          <p className="mt-2 text-[#64748B]">Clean, fast, and designed with coaches in mind.</p>
        </div>

        <Card className="mt-8 border-0 shadow-xl overflow-hidden">
          <CardContent className="p-0">
            <div className="bg-gradient-to-b from-[#0369A1] to-[#1E293B] px-4 sm:px-6 lg:px-8 pt-6 pb-4">
              <Tabs defaultValue="dashboard" className="w-full">
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <TabsList className="bg-white/10">
                    <TabsTrigger value="dashboard" className="data-[state=active]:bg-white data-[state=active]:text-slate-900">
                      <LayoutDashboard className="w-4 h-4 mr-2" /> Dashboard
                    </TabsTrigger>
                    <TabsTrigger value="matches" className="data-[state=active]:bg-white data-[state=active]:text-slate-900">
                      <CalendarDays className="w-4 h-4 mr-2" /> Matches
                    </TabsTrigger>
                  </TabsList>
                  <div className="text-xs text-white/80 flex items-center gap-3">
                    <Users className="w-3.5 h-3.5" /> Real product UI shots
                  </div>
                </div>

                <div className="relative mt-5">
                  <div className="absolute -inset-0.5 rounded-2xl blur opacity-40" style={{ background: "linear-gradient(90deg,#E63946,#0369A1)" }}></div>
                  <div className="relative rounded-2xl overflow-hidden bg-white">
                    <TabsContent value="dashboard" className="m-0">
                      <img src={screenshots.dashboard} alt="Dashboard screenshot" className="w-full h-auto" loading="lazy" />
                    </TabsContent>
                    <TabsContent value="matches" className="m-0">
                      <img src={screenshots.matches} alt="Matches screenshot" className="w-full h-auto" loading="lazy" />
                    </TabsContent>
                  </div>
                </div>
              </Tabs>
            </div>
          </CardContent>
        </Card>

        {/* Inline CTA merged with showcase */}
        <div className="mt-8">
          <div className="rounded-2xl border border-slate-200 p-8 md:p-12 bg-gradient-to-r from-[#FFF7D1] to-white">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div>
                <h3 className="text-2xl md:text-3xl font-extrabold text-slate-900">Ready to see Abwab in action?</h3>
                <p className="text-slate-600 mt-2">Book a demo or reach out—our team will get back to you within 24 hours.</p>
              </div>
              <a href="#contact" className="inline-flex items-center gap-2 btn-primary rounded-md px-5 py-3 font-semibold">
                Book a Demo <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
