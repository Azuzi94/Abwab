export const ROLES = {
  ADMIN: "admin",
  COACH: "coach",
};

export function can(resource, action, ctx) {
  const role = (ctx?.user?.role || "coach").toLowerCase();
  const isAdmin = role === ROLES.ADMIN;

  // Resource-action policy
  const policies = {
    players: {
      create: isAdmin || role === ROLES.COACH,
      read: isAdmin || role === ROLES.COACH,
      update: isAdmin || role === ROLES.COACH,
      delete: isAdmin,
    },
    teams: {
      create: isAdmin,
      read: isAdmin || role === ROLES.COACH,
      update: isAdmin,
      delete: isAdmin,
    },
    matches: {
      create: isAdmin || role === ROLES.COACH,
      read: isAdmin || role === ROLES.COACH,
      update: isAdmin || role === ROLES.COACH,
      delete: isAdmin,
    },
    auditlogs: {
      read: isAdmin,
      create: isAdmin, // via backend only
    },
  };

  const res = String(resource || "").toLowerCase();
  const act = String(action || "").toLowerCase();

  if (!policies[res]) return false;
  const rule = policies[res][act];
  return typeof rule === "boolean" ? rule : false;
}

// Optional helper for team scoping
export function isTeamScoped(ctx, teamId) {
  if (!teamId) return false;
  if ((ctx?.user?.role || "").toLowerCase() === ROLES.ADMIN) return true;
  const assigned = new Set(ctx?.assignedTeamIds || ctx?.user?.assigned_team_ids || []);
  return assigned.has(teamId);
}