
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Users, MoreVertical, Pencil, Trash } from 'lucide-react';
import { CalendarDays, BarChart2, FileDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function TeamGrid({ teams, players, matches, onEdit, onDelete, onViewStats }) {
  const teamColors = {
    blue: "border-blue-500",
    red: "border-red-500",
    green: "border-green-500",
    yellow: "border-yellow-500",
    purple: "border-purple-500",
    orange: "border-orange-500",
    pink: "border-pink-500",
    teal: "border-teal-500",
    navy: "border-blue-900",
    gray: "border-gray-500"
  };

  const byId = new Map(players.map(p => [p.id, p]));

  const getAvgAge = (ids=[]) => {
    const list = ids.map(id => byId.get(id)).filter(Boolean).map(p => p.age).filter(a => typeof a === 'number');
    if (list.length === 0) return '-';
    return Math.round(list.reduce((a,b) => a+b, 0) / list.length);
  };

  const getQuickStats = (team) => {
    const related = (matches || []).filter(m => m.home_team_id === team.id || m.away_team_id === team.id).slice(0, 5);
    let w=0,d=0,l=0, gf=0, ga=0;
    related.forEach(m => {
      if (typeof m.home_score === 'number' && typeof m.away_score === 'number') {
        const isHome = m.home_team_id === team.id;
        const forGoals = isHome ? m.home_score : m.away_score;
        const againstGoals = isHome ? m.away_score : m.home_score;
        gf += forGoals; ga += againstGoals;
        if (forGoals > againstGoals) w++;
        else if (forGoals === againstGoals) d++;
        else l++;
      }
    });
    return { w,d,l,gf,ga };
  };

  const nextMatchInfo = (team) => {
    const upcoming = (matches || []).filter(m =>
      (m.home_team_id === team.id || m.away_team_id === team.id) &&
      (m.status === 'planned' || m.status === 'ready_for_recording')
    );
    if (upcoming.length === 0) return null;
    const soonest = upcoming.sort((a,b) => new Date(a.match_date || a.start_time_utc || 0) - new Date(b.match_date || b.start_time_utc || 0))[0];
    return soonest;
  };

  const exportRosterCsv = (team) => {
    const rows = [['Jersey','First Name','Last Name','Position','Status','Age']];
    (team.players || []).forEach(id => {
      const p = byId.get(id);
      if (!p) return;
      rows.push([p.jersey_number || '', p.first_name || '', p.last_name || '', p.position || '', p.status || '', p.age || '']);
    });
    const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], {type: 'text/csv'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${team.name}-roster.csv`; a.click();
    URL.revokeObjectURL(url);
  };
  
  if (teams.length === 0) {
    return (
      <div className="text-center py-20 bg-white rounded-lg shadow">
        <Users className="w-16 h-16 mx-auto text-slate-300" />
        <h3 className="mt-4 text-xl font-semibold text-slate-700">No teams created</h3>
        <p className="mt-2 text-slate-500">Create your first team to start organizing players.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {teams.map(team => {
        const stats = getQuickStats(team);
        const nm = nextMatchInfo(team);
        return (
          <Card key={team.id} className={`border-t-4 ${teamColors[team.color] || 'border-gray-500'} shadow-md relative overflow-hidden`}>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <span className="inline-block w-2 h-2 rounded-full" 
                      style={{ background: team.custom_color_hex || (team.color && teamColors[team.color] ? teamColors[team.color].replace('border-', '') : undefined) }}></span>
                {team.name}
                {team.formation && <Badge variant="outline" className="ml-2">{team.formation}</Badge>}
              </CardTitle>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon"><MoreVertical className="w-4 h-4" /></Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => onEdit(team)}><Pencil className="w-4 h-4 me-2"/>Edit Team</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => exportRosterCsv(team)}><FileDown className="w-4 h-4 me-2" />Export Roster (CSV)</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onViewStats && onViewStats(team)}>
                    <BarChart2 className="w-4 h-4 me-2" />View Stats
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to={createPageUrl(`NewMatch?home_team_id=${team.id}`)} className="w-full flex items-center">
                      <CalendarDays className="w-4 h-4 me-2" />Schedule Match
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onDelete(team.id)} className="text-red-500"><Trash className="w-4 h-4 me-2"/>Delete</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between text-sm text-slate-600">
                <span>{team.players?.length || 0} Players</span>
                {typeof getAvgAge(team.players) === 'number' ? (
                  <span>Avg Age: {getAvgAge(team.players)}</span>
                ) : <span>Avg Age: -</span>}
              </div>

              <div className="mt-3 flex items-center justify-between text-xs text-slate-500">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">W {stats.w}</Badge>
                  <Badge variant="secondary">D {stats.d}</Badge>
                  <Badge variant="secondary">L {stats.l}</Badge>
                </div>
                <div>GF {stats.gf} / GA {stats.ga}</div>
              </div>

              {nm && (
                <div className="mt-3 text-xs text-slate-600 flex items-center gap-2">
                  <CalendarDays className="w-3 h-3" />
                  Next: {nm.home_team_name} vs {nm.away_team_name}
                </div>
              )}

              <div className="mt-4 flex -space-x-2 overflow-hidden">
                {team.players?.slice(0, 7).map(playerId => {
                  const player = byId.get(playerId);
                  if (!player) return null;
                  return (
                    <Avatar key={player.id} className="inline-block h-8 w-8 rounded-full ring-2 ring-white">
                      <AvatarImage src={player.photo_url} />
                      <AvatarFallback>{player.first_name?.[0]}</AvatarFallback>
                    </Avatar>
                  );
                })}
                {team.players?.length > 7 && (
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-200 text-xs font-medium text-slate-600 ring-2 ring-white">
                    +{team.players.length - 7}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
