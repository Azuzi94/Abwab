
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from '@/components/ui/badge';
import { Search, Users, Filter, X } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import FormationPreview from "./FormationPreview";
import { User } from '@/api/entities'; // Assuming User entity is correctly defined and imported

export default function TeamModal({ isOpen, onClose, onSave, team, players = [], teams = [] }) {
  const [formData, setFormData] = useState({ name: '', players: [], color: 'blue', formation: '4-4-2', coach_ids: [] });
  const [playerFilters, setPlayerFilters] = useState({
    search: '',
    position: 'all',
    status: 'all',
    teamStatus: 'all'
  });
  const [coaches, setCoaches] = useState([]);
  
  // Validation config
  const MAX_PLAYERS = 11;
  const MIN_BY_ROLE = { defender: 3, midfielder: 3, forward: 1, goalkeeper: 1 }; // Added goalkeeper to MIN_BY_ROLE

  useEffect(() => {
    if (team) {
      setFormData({
        name: team.name || '',
        players: team.players || [],
        color: team.color || 'blue',
        formation: team.formation || '4-4-2',
        coach_ids: Array.isArray(team.coach_ids) ? team.coach_ids : []
      });
    } else {
      setFormData({ name: '', players: [], color: 'blue', formation: '4-4-2', coach_ids: [] });
    }
    setPlayerFilters({ search: '', position: 'all', status: 'all', teamStatus: 'all' });
  }, [team, isOpen]);

  // Load coaches (admins see all; others see self)
  useEffect(() => {
    (async () => {
      try {
        const me = await User.me();
        let list = [];
        if (me) {
          list.push(me);
          if (me?.role === 'admin' || me?.app_role === 'academy_admin') {
            const all = await User.list();
            list = all.filter(u => u.academy_id === me.academy_id);
          }
        }
        setCoaches(list);
      } catch (error) {
        console.error("Failed to load coaches:", error);
        setCoaches([]);
      }
    })();
  }, []);

  const getPlayerTeamStatus = (playerId) => {
    const playerTeams = teams.filter(t => t.players?.includes(playerId));
    if (playerTeams.length === 0) return 'unassigned';
    if (team && playerTeams.some(t => t.id === team.id)) return 'current_team';
    return 'other_team';
  };

  const filteredPlayers = players.filter(player => {
    const searchMatch = !playerFilters.search ||
      `${player.first_name} ${player.last_name}`.toLowerCase().includes(playerFilters.search.toLowerCase()) ||
      String(player.jersey_number).includes(playerFilters.search);
    
    const positionMatch = playerFilters.position === 'all' || player.position === playerFilters.position;
    const statusMatch = playerFilters.status === 'all' || player.status === playerFilters.status;
    
    const teamStatus = getPlayerTeamStatus(player.id);
    const teamStatusMatch = playerFilters.teamStatus === 'all' || teamStatus === playerFilters.teamStatus;
    
    return searchMatch && positionMatch && statusMatch && teamStatusMatch;
  });

  const handlePlayerToggle = (playerId) => {
    setFormData(prev => {
      const newPlayers = prev.players.includes(playerId)
        ? prev.players.filter(id => id !== playerId)
        : [...prev.players, playerId];
      return { ...prev, players: newPlayers };
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validation rules
    const selectedPlayersData = players.filter(p => formData.players.includes(p.id));
    const gkCount = selectedPlayersData.filter(p => p.position === 'goalkeeper').length;
    const defCount = selectedPlayersData.filter(p => p.position === 'defender').length;
    const midCount = selectedPlayersData.filter(p => p.position === 'midfielder').length;
    const fwdCount = selectedPlayersData.filter(p => p.position === 'forward').length;

    if (!formData.name.trim()) {
      alert("Team name is required.");
      return;
    }

    if (gkCount < MIN_BY_ROLE.goalkeeper) {
      alert(`Team must include at least ${MIN_BY_ROLE.goalkeeper} goalkeeper.`);
      return;
    }
    if (formData.players.length > MAX_PLAYERS) {
      alert(`Max players allowed is ${MAX_PLAYERS}.`);
      return;
    }
    if (defCount < MIN_BY_ROLE.defender || midCount < MIN_BY_ROLE.midfielder || fwdCount < MIN_BY_ROLE.forward) {
      alert(`Team requires at least ${MIN_BY_ROLE.defender} DEF, ${MIN_BY_ROLE.midfielder} MID, ${MIN_BY_ROLE.forward} FWD.`);
      return;
    }

    onSave({
      name: formData.name,
      color: formData.color,
      players: formData.players,
      formation: formData.formation,
      coach_ids: formData.coach_ids
    });
  };

  const clearFilters = () => {
    setPlayerFilters({ search: '', position: 'all', status: 'all', teamStatus: 'all' });
  };

  const colors = ["blue", "red", "green", "yellow", "purple", "orange", "pink", "teal", "navy", "gray"];

  const getTeamStatusColor = (status) => {
    switch (status) {
      case 'unassigned': return 'bg-slate-100 text-slate-700';
      case 'current_team': return 'bg-blue-100 text-blue-700';
      case 'other_team': return 'bg-orange-100 text-orange-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getTeamStatusText = (status) => {
    switch (status) {
      case 'unassigned': return 'Available';
      case 'current_team': return 'Current Team';
      case 'other_team': return 'Other Team';
      default: return '';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-5xl max-h-[90vh] p-0 flex flex-col">
        {/* Sticky Header */}
        <div className="sticky top-0 z-10 bg-white border-b">
          <DialogHeader className="px-6 pt-6 pb-4">
            <DialogTitle className="text-2xl flex items-center gap-2">
              <Users className="w-6 h-6" />
              {team ? 'Edit Team' : 'Create New Team'}
            </DialogTitle>
          </DialogHeader>

          <div className="px-6 pb-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-1">
                <Label htmlFor="name" className="text-base font-medium">Team Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(p => ({ ...p, name: e.target.value }))}
                  placeholder="Enter team name..."
                  className="mt-1 h-11"
                  required
                />
              </div>

              <div>
                <Label htmlFor="color" className="text-base font-medium">Team Color</Label>
                <Select
                  value={formData.color}
                  onValueChange={(value) => setFormData(p => ({ ...p, color: value }))}
                >
                  <SelectTrigger className="mt-1 h-11"><SelectValue placeholder="Select team color" /></SelectTrigger>
                  <SelectContent>
                    {colors.map(c => (
                      <SelectItem key={c} value={c} className="capitalize">
                        <div className="flex items-center gap-2">
                          <div className={`w-4 h-4 rounded-full bg-${c}-500`}></div>
                          {c}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-base font-medium">Formation</Label>
                <Select value={formData.formation} onValueChange={(v) => setFormData(p => ({ ...p, formation: v }))}>
                  <SelectTrigger className="mt-1 h-11"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["4-4-2","4-3-3","3-5-2","3-4-3","4-2-3-1","4-1-4-1","5-3-2","5-4-1"].map(f => (
                      <SelectItem key={f} value={f}>{f}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </div>

        {/* Scrollable Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto">
          <div className="px-6 py-4">
            <Tabs defaultValue="players" className="flex-1 overflow-hidden flex flex-col">
              <TabsList className="w-full justify-start">
                <TabsTrigger value="players">Players</TabsTrigger>
                <TabsTrigger value="coaches">Coaches</TabsTrigger>
                <TabsTrigger value="preview">Preview</TabsTrigger>
              </TabsList>

              <TabsContent value="players" className="flex-1 overflow-hidden flex flex-col pt-4">
                <div className="flex items-center justify-between mb-4">
                  <Label className="text-base font-medium">Select Players ({formData.players.length} selected)</Label>
                  <Button type="button" variant="outline" size="sm" onClick={clearFilters}>
                    <X className="w-4 h-4 mr-1" />
                    Clear Filters
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <Input
                      placeholder="Search players..."
                      value={playerFilters.search}
                      onChange={(e) => setPlayerFilters(p => ({ ...p, search: e.target.value }))}
                      className="pl-10"
                    />
                  </div>

                  <Select
                    value={playerFilters.position}
                    onValueChange={(value) => setPlayerFilters(p => ({ ...p, position: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Position" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Positions</SelectItem>
                      <SelectItem value="goalkeeper">Goalkeeper</SelectItem>
                      <SelectItem value="defender">Defender</SelectItem>
                      <SelectItem value="midfielder">Midfielder</SelectItem>
                      <SelectItem value="forward">Forward</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select
                    value={playerFilters.status}
                    onValueChange={(value) => setPlayerFilters(p => ({ ...p, status: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                      <SelectItem value="injured">Injured</SelectItem>
                      <SelectItem value="suspended">Suspended</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select
                    value={playerFilters.teamStatus}
                    onValueChange={(value) => setPlayerFilters(p => ({ ...p, teamStatus: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Team Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Players</SelectItem>
                      <SelectItem value="unassigned">Available Only</SelectItem>
                      <SelectItem value="current_team">Current Team</SelectItem>
                      <SelectItem value="other_team">Other Teams</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <ScrollArea className="flex-1 rounded-md border">
                  <div className="p-4 space-y-3">
                    {filteredPlayers.length === 0 ? (
                      <div className="text-center py-8 text-slate-500">
                        <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
                        <p>No players match the current filters</p>
                      </div>
                    ) : (
                      filteredPlayers.map(player => {
                        const teamStatus = getPlayerTeamStatus(player.id);
                        const isSelected = formData.players.includes(player.id);
                        
                        return (
                          <div 
                            key={player.id} 
                            className={`flex items-center justify-between p-3 rounded-lg border transition-colors ${
                              isSelected ? 'bg-blue-50 border-blue-200' : 'bg-white hover:bg-slate-50'
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <Avatar className="h-10 w-10">
                                <AvatarImage src={player.photo_url} />
                                <AvatarFallback className="text-sm font-medium">
                                  {player.first_name?.[0]}{player.last_name?.[0]}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-medium">{player.first_name} {player.last_name}</div>
                                <div className="flex items-center gap-2 text-sm text-slate-500">
                                  <span>#{player.jersey_number}</span>
                                  <Badge variant="outline" className="text-xs capitalize">
                                    {player.position}
                                  </Badge>
                                  <Badge className={`text-xs ${getTeamStatusColor(teamStatus)}`}>
                                    {getTeamStatusText(teamStatus)}
                                  </Badge>
                                </div>
                              </div>
                            </div>
                            <Checkbox
                              checked={isSelected}
                              onCheckedChange={() => handlePlayerToggle(player.id)}
                              disabled={!isSelected && formData.players.length >= MAX_PLAYERS} // Disable if max players reached and player not already selected
                            />
                          </div>
                        );
                      })
                    )}
                  </div>
                </ScrollArea>
              </TabsContent>

              <TabsContent value="coaches" className="pt-4">
                <Label className="mb-2 block">Assign Coaches (multi)</Label>
                <div className="rounded-md border p-3 max-h-56 overflow-auto space-y-2">
                  {coaches.length === 0 ? (
                    <div className="text-sm text-slate-500">No coaches available.</div>
                  ) : coaches.map(c => {
                    const checked = formData.coach_ids.includes(c.id);
                    return (
                      <label key={c.id} className="flex items-center gap-3 cursor-pointer">
                        <Checkbox checked={checked} onCheckedChange={() => {
                          setFormData(prev => {
                            const set = new Set(prev.coach_ids);
                            if (checked) set.delete(c.id); else set.add(c.id);
                            return { ...prev, coach_ids: Array.from(set) };
                          });
                        }} />
                        <Avatar className="h-9 w-9">
                          <AvatarImage src={c.photo_url} />
                          <AvatarFallback className="text-xs font-medium">
                            {c.full_name?.[0] || c.email?.[0]}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">{c.full_name || c.email}</div>
                          <div className="text-xs text-slate-500 capitalize">{c.app_role || 'coach'}</div>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </TabsContent>

              <TabsContent value="preview" className="pt-4">
                <FormationPreview formation={formData.formation} selectedPlayerIds={formData.players} playersData={players} />
              </TabsContent>
            </Tabs>
          </div>

          {/* Sticky Footer */}
          <div className="sticky bottom-0 bg-white border-t px-6 py-4 flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" className="bg-green-600 hover:bg-green-700">
              {team ? 'Update Team' : 'Create Team'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
