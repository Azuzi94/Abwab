import React from "react";

function splitFormation(formation) {
  // e.g., "4-3-3" => [4,3,3]
  return (formation || "4-4-2").split("-").map(n => parseInt(n, 10)).filter(Boolean);
}

export default function FormationPreview({ formation = "4-4-2", selectedPlayerIds = [], playersData = [] }) {
  const playersById = React.useMemo(() => {
    const m = new Map();
    playersData.forEach(p => m.set(p.id, p));
    return m;
  }, [playersData]);

  const selected = selectedPlayerIds.map(id => playersById.get(id)).filter(Boolean);

  const gks = selected.filter(p => p.position === "goalkeeper");
  const defs = selected.filter(p => p.position === "defender");
  const mids = selected.filter(p => p.position === "midfielder");
  const fwds = selected.filter(p => p.position === "forward");

  const [dCount, mCount, fCount] = splitFormation(formation);
  const gk = gks[0] ? [gks[0]] : [];
  const line = (arr, count) => arr.slice(0, count);

  const defLine = line(defs, dCount);
  const midLine = line(mids, mCount);
  const fwdLine = line(fwds, fCount);

  const Row = ({ label, players }) => (
    <div className="flex justify-around items-center w-full py-2">
      {players.length === 0 ? (
        <div className="text-xs text-white/80">{label} needed</div>
      ) : players.map(p => (
        <div key={p.id} className="flex flex-col items-center">
          <div className="w-10 h-10 rounded-full bg-white/10 border border-white/30 text-white flex items-center justify-center text-xs font-semibold">
            {p.jersey_number || p.first_name?.[0] || "?"}
          </div>
          <div className="text-[10px] text-white/90 mt-1 text-center w-16 truncate">{p.first_name} {p.last_name}</div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="rounded-xl overflow-hidden border border-emerald-200 shadow-sm">
      <div className="bg-emerald-700 relative">
        <div className="px-3 py-2 text-white text-xs font-semibold bg-emerald-800/70">Live Preview — {formation}</div>
        <div className="p-3">
          <div className="relative w-full" style={{ aspectRatio: "3 / 4" }}>
            <div className="absolute inset-0 bg-gradient-to-b from-emerald-700 to-emerald-800">
              {/* Pitch markings */}
              <div className="absolute inset-3 border border-white/30 rounded-lg"></div>
              <div className="absolute left-1/2 top-3 bottom-3 border-l border-white/20"></div>
              <div className="absolute left-3 right-3 top-8 border-t border-white/20"></div>
              <div className="absolute left-3 right-3 bottom-8 border-b border-white/20"></div>
            </div>
            <div className="absolute inset-3 flex flex-col justify-between">
              <Row label="Forward" players={fwdLine} />
              <Row label="Midfield" players={midLine} />
              <Row label="Defense" players={defLine} />
              <Row label="Goalkeeper" players={gk} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}