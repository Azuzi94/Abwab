import React, { useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export default function TeamStatsModal({ open, onClose, team, players=[], matches=[] }) {
  if (!team) return null;

  const teamPlayers = useMemo(() => players.filter(p => (team.players || []).includes(p.id)), [players, team]);
  const playedMatches = useMemo(() => {
    const related = matches.filter(m => m.home_team_id === team.id || m.away_team_id === team.id);
    return related.filter(m => {
      const s = (m.raw_status || m.status || "").toLowerCase();
      const hasScores = typeof m.home_score === "number" && typeof m.away_score === "number";
      return s === "finished" || s === "completed" || hasScores;
    }).sort((a,b) => new Date(b.match_date || b.start_time_utc || 0) - new Date(a.match_date || a.start_time_utc || 0));
  }, [matches, team]);

  const record = useMemo(() => {
    let w=0,d=0,l=0;
    playedMatches.forEach(m => {
      if (typeof m.home_score !== "number" || typeof m.away_score !== "number") return;
      const isHome = m.home_team_id === team.id;
      const gf = isHome ? m.home_score : m.away_score;
      const ga = isHome ? m.away_score : m.home_score;
      if (gf > ga) w++;
      else if (gf === ga) d++;
      else l++;
    });
    const last5 = playedMatches.slice(0,5);
    let w5=0, d5=0, l5=0;
    last5.forEach(m => {
      if (typeof m.home_score !== "number" || typeof m.away_score !== "number") return;
      const isHome = m.home_team_id === team.id;
      const gf = isHome ? m.home_score : m.away_score;
      const ga = isHome ? m.away_score : m.home_score;
      if (gf > ga) w5++; else if (gf === ga) d5++; else l5++;
    });
    return { total: playedMatches.length, w, d, l, last5: `W${w5} D${d5} L${l5}` };
  }, [playedMatches, team]);

  const positionCounts = useMemo(() => {
    const counts = { goalkeeper:0, defender:0, midfielder:0, forward:0 };
    teamPlayers.forEach(p => { if (counts[p.position] !== undefined) counts[p.position]++; });
    return counts;
  }, [teamPlayers]);

  const formation = team.formation || "4-4-2";
  const [d,m,f] = formation.split("-").map(n => parseInt(n,10)).filter(Boolean);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden p-0">
        <DialogHeader className="sticky top-0 bg-white z-10 border-b px-6 py-4">
          <DialogTitle className="text-xl">{team.name} — Stats</DialogTitle>
        </DialogHeader>

        <div className="p-6 overflow-y-auto max-h-[calc(90vh-5rem)]">
          <Tabs defaultValue="overview">
            <TabsList className="mb-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="formation">Formation</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-3">
                <Card><CardContent className="p-4">
                  <div className="text-xs text-slate-500">Squad Size</div>
                  <div className="text-2xl font-bold">{teamPlayers.length}</div>
                </CardContent></Card>
                <Card><CardContent className="p-4">
                  <div className="text-xs text-slate-500">Average Age</div>
                  <div className="text-2xl font-bold">
                    {(() => {
                      const ages = teamPlayers.map(p => p.age).filter(a => typeof a === "number");
                      if (!ages.length) return "—";
                      return Math.round(ages.reduce((a,b)=>a+b,0)/ages.length);
                    })()}
                  </div>
                </CardContent></Card>
                <Card><CardContent className="p-4">
                  <div className="text-xs text-slate-500">Matches Played</div>
                  <div className="text-2xl font-bold">{record.total}</div>
                  <div className="text-xs text-slate-500 mt-1">Record: W{record.w} D{record.d} L{record.l}</div>
                  <div className="text-xs text-slate-500">Last 5: {record.last5}</div>
                </CardContent></Card>
              </div>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="font-semibold">Recent Matches</div>
                    <Badge variant="outline">{formation}</Badge>
                  </div>
                  <div className="mt-3 space-y-2">
                    {playedMatches.slice(0,5).map(m => {
                      const isHome = m.home_team_id === team.id;
                      const gf = typeof m.home_score === "number" ? (isHome ? m.home_score : m.away_score) : "-";
                      const ga = typeof m.away_score === "number" ? (isHome ? m.away_score : m.home_score) : "-";
                      return (
                        <div key={m.id} className="text-sm flex items-center justify-between rounded border p-2">
                          <div className="truncate">
                            {m.home_team_name} vs {m.away_team_name}
                          </div>
                          <div className="font-semibold">{gf} - {ga}</div>
                        </div>
                      );
                    })}
                    {playedMatches.length === 0 && <div className="text-sm text-slate-500">No completed matches yet.</div>}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="formation">
              <Card>
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="font-semibold">Formation Insights</div>
                    <Badge variant="secondary">{formation}</Badge>
                  </div>
                  <div className="text-sm text-slate-600">
                    Positional workload vs selected squad:
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="p-3 rounded border">
                      <div className="text-xs text-slate-500">Goalkeepers</div>
                      <div className="font-semibold">{positionCounts.goalkeeper} / 1</div>
                    </div>
                    <div className="p-3 rounded border">
                      <div className="text-xs text-slate-500">Defenders</div>
                      <div className="font-semibold">{positionCounts.defender} / {d || "-"}</div>
                    </div>
                    <div className="p-3 rounded border">
                      <div className="text-xs text-slate-500">Midfielders</div>
                      <div className="font-semibold">{positionCounts.midfielder} / {m || "-"}</div>
                    </div>
                    <div className="p-3 rounded border">
                      <div className="text-xs text-slate-500">Forwards</div>
                      <div className="font-semibold">{positionCounts.forward} / {f || "-"}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}