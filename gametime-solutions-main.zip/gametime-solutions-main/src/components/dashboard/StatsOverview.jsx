import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Users, Calendar, Video, TrendingUp } from "lucide-react";
import { format, parseISO } from "date-fns";

export default function StatsOverview({ players, matches }) {
  const upcomingMatches = matches.filter(m => m.status === 'planned');
  const nextMatch = upcomingMatches.sort((a, b) => new Date(a.match_date) - new Date(b.match_date))[0];
  
  const completedMatchesCount = matches.filter(m => m.status === 'completed').length;
  const totalPlayersCount = players.length;
  const liveMatchesCount = matches.filter(m => m.status === 'live').length;

  const stats = [
    {
      title: "Live Matches",
      value: liveMatchesCount,
      icon: Video,
      detail: liveMatchesCount > 0 ? "Currently recording" : "No active recordings",
      isPrimary: liveMatchesCount > 0,
      color: liveMatchesCount > 0 ? "from-red-500 to-red-600" : "from-slate-500 to-slate-600",
      bgColor: liveMatchesCount > 0 ? "bg-red-50" : "bg-slate-50",
      textColor: liveMatchesCount > 0 ? "text-red-700" : "text-slate-700",
    },
    {
      title: "Upcoming Matches",
      value: upcomingMatches.length,
      icon: Calendar,
      detail: nextMatch ? format(parseISO(nextMatch.match_date), "MMM d") : "None scheduled",
      isPrimary: false,
      color: "from-blue-500 to-blue-600",
      bgColor: "bg-blue-50",
      textColor: "text-blue-700",
    },
    {
      title: "Total Players",
      value: totalPlayersCount,
      icon: Users,
      detail: "in your academy",
      isPrimary: false,
      color: "from-green-500 to-green-600",
      bgColor: "bg-green-50", 
      textColor: "text-green-700",
    },
    {
      title: "Completed Matches",
      value: completedMatchesCount,
      icon: TrendingUp,
      detail: "matches analyzed",
      isPrimary: false,
      color: "from-purple-500 to-purple-600",
      bgColor: "bg-purple-50",
      textColor: "text-purple-700",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => (
        <Card
          key={index}
          className="relative overflow-hidden bg-white border-0 shadow-md hover:shadow-xl transition-all duration-300 group hover:scale-[1.02]"
        >
          <div className={`h-1 bg-gradient-to-r ${stat.color}`}></div>
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div className="space-y-3 flex-1">
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-xl ${stat.bgColor} group-hover:scale-110 transition-transform duration-200`}>
                    <stat.icon className={`w-6 h-6 ${stat.textColor}`} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-600 uppercase tracking-wide">
                      {stat.title}
                    </p>
                  </div>
                </div>
                
                <div className="space-y-1">
                  <div className="flex items-baseline gap-2">
                    <p className="text-4xl font-bold text-slate-900 tracking-tight">
                      {stat.value}
                    </p>
                    {stat.isPrimary && (
                      <div className="flex items-center">
                        <div className="w-2 h-2 bg-red-400 rounded-full animate-pulse"></div>
                      </div>
                    )}
                  </div>
                  <p className="text-sm text-slate-500 font-medium">
                    {stat.detail}
                  </p>
                </div>
              </div>
            </div>
            
            {/* Subtle background pattern */}
            <div className="absolute top-0 right-0 w-32 h-32 opacity-5">
              <div className={`w-full h-full bg-gradient-to-br ${stat.color} rounded-full transform translate-x-16 -translate-y-16`}></div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}