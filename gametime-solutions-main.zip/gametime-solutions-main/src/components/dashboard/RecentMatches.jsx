
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, Clock, Eye } from "lucide-react";
import { format, isValid, parseISO } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function RecentMatches({ matches }) {
  const getStatusInfo = (status) => {
    switch (status) {
      case 'completed': return { text: 'Completed', color: 'bg-green-100 text-green-800 border-green-200' };
      case 'live': return { text: 'Live', color: 'bg-red-100 text-red-800 border-red-200' };
      case 'planned': return { text: 'Planned', color: 'bg-slate-100 text-slate-800 border-slate-200' };
      default: return { text: status ? status.charAt(0).toUpperCase() + status.slice(1) : 'Unknown', color: 'bg-gray-100 text-gray-800 border-gray-200' };
    }
  };

  const formatDate = (dateString) => {
    const date = parseISO(dateString);
    return isValid(date) ? format(date, 'MMM d, yyyy • hh:mm a') : 'Invalid date';
  };

  if (matches.length === 0) {
    return (
      <Card className="border-0 shadow-xl shadow-slate-200/50">
        <CardHeader><CardTitle className="flex items-center gap-2"><Calendar className="w-5 h-5 text-blue-600" />Recent Matches</CardTitle></CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-900 mb-2">No matches yet</h3>
            <p className="text-slate-500 mb-6">Start by creating your first match recording.</p>
            <Link to={createPageUrl("NewMatch")}><Button className="bg-gradient-to-r from-blue-600 to-cyan-500">Create First Match</Button></Link>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-0 shadow-xl bg-white">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2 text-slate-800"><Calendar className="w-5 h-5" />Recent Matches</CardTitle>
        <Link to={createPageUrl("Matches")}><Button variant="outline" size="sm">View All</Button></Link>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {matches.map((match) => {
            const statusInfo = getStatusInfo(match.status);
            return (
              <div key={match.id} className="p-4 rounded-xl border border-slate-200 hover:shadow-md transition-shadow duration-200 bg-white">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold text-slate-900">{match.home_team_name} vs {match.away_team_name}</h3>
                      <Badge className={`${statusInfo.color}`}>{statusInfo.text}</Badge>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-slate-500">
                      <div className="flex items-center gap-1"><Clock className="w-3 h-3" />{formatDate(match.match_date)}</div>
                      {match.venue && (<div className="flex items-center gap-1"><MapPin className="w-3 h-3" />{match.venue}</div>)}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {match.status === 'completed' && (
                      <div className="text-right">
                        <div className="font-bold text-lg text-slate-900">{match.home_score} - {match.away_score}</div>
                      </div>
                    )}
                    <Button variant="ghost" size="icon" onClick={() => alert("Coming soon!")}><Eye className="w-4 h-4" /></Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
