
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, ListTodo, Video } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Alerts({ matches }) {
  // These statuses are no longer available from the Zone14 API source
  // const needsReviewCount = matches.filter(m => m.status === 'needs_review').length;
  // const needsMappingCount = matches.filter(m => m.status === 'needs_mapping').length;

  const alerts = [];
  
  // The logic that pushed alerts is now removed.

  if (alerts.length === 0) {
    return null; // Don't render if there are no alerts
  }

  return (
    <Card className="border-0 shadow-lg bg-white">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-slate-800">
          <AlertTriangle className="w-5 h-5 text-yellow-500" />
          Alerts
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {alerts.map((alert) => (
          <Link to={alert.link} key={alert.id} className="block hover:bg-slate-50 p-3 rounded-lg -m-3">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-yellow-100 rounded-full">
                <alert.icon className="w-4 h-4 text-yellow-600" />
              </div>
              <div>
                <p className="font-semibold text-slate-800">{alert.title}</p>
                <p className="text-sm text-slate-500">{alert.description}</p>
              </div>
            </div>
          </Link>
        ))}
      </CardContent>
    </Card>
  );
}
