import React, { useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip } from "recharts";
import { format, parseISO } from "date-fns";

export default function TrendsChart({ matches = [] }) {
  const data = useMemo(() => {
    const map = new Map();
    matches.forEach(m => {
      const d = m.match_date || m.start_time_utc;
      if (!d) return;
      const day = format(parseISO(d), "MMM d");
      map.set(day, (map.get(day) || 0) + 1);
    });
    return Array.from(map.entries()).map(([date, count]) => ({ date, count })).slice(-14);
  }, [matches]);

  return (
    <Card className="border-0 shadow-xl bg-white">
      <CardContent className="p-6">
        <div className="text-slate-800 font-semibold mb-2">Match Activity (last 2 weeks)</div>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data}>
              <defs>
                <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#01203F" stopOpacity={0.5}/>
                  <stop offset="95%" stopColor="#01203F" stopOpacity={0.05}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="date" stroke="#94a3b8" />
              <YAxis allowDecimals={false} stroke="#94a3b8" />
              <Tooltip />
              <Area type="monotone" dataKey="count" stroke="#01203F" fill="url(#colorCount)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}