
import React, { useState } from "react";
import { Academy } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Trophy, MapPin, Calendar } from "lucide-react";

export default function AcademySetup({ user, onAcademyCreated }) {
  const [formData, setFormData] = useState({
    name: "",
    location: "",
    founded_year: new Date().getFullYear(),
    coach_email: user?.email || ""
  });
  const [isCreating, setIsCreating] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsCreating(true);
    
    try {
      await Academy.create(formData);
      onAcademyCreated();
    } catch (error) {
      console.error("Error creating academy:", error);
    }
    
    setIsCreating(false);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6" style={{ backgroundColor: '#0B2845' }}>
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 bg-white/10 backdrop-blur-sm">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/9f9d5d3fb_image.png" 
              alt="Abwab Logo" 
              className="w-12 h-12 object-contain"
            />
          </div>
          <h1 className="text-3xl font-bold mb-2" style={{ color: '#FAF7F2' }}>Welcome to Abwab</h1>
          <p style={{ color: 'rgba(250, 247, 242, 0.7)' }}>Let's set up your football academy</p>
        </div>

        <Card className="border-0 shadow-2xl bg-white/10 backdrop-blur-lg">
          <CardHeader>
            <CardTitle className="text-center" style={{ color: '#FAF7F2' }}>Create Your Academy</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name" style={{ color: '#FAF7F2' }}>Academy Name</Label>
                <Input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleChange('name', e.target.value)}
                  placeholder="e.g., Elite Football Academy"
                  required
                  className="h-12"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="location" style={{ color: '#FAF7F2' }}>Location</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                  <Input
                    id="location"
                    type="text"
                    value={formData.location}
                    onChange={(e) => handleChange('location', e.target.value)}
                    placeholder="City, Country"
                    className="h-12 pl-12"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="founded_year" style={{ color: '#FAF7F2' }}>Founded Year</Label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                  <Input
                    id="founded_year"
                    type="number"
                    min="1900"
                    max={new Date().getFullYear()}
                    value={formData.founded_year}
                    onChange={(e) => handleChange('founded_year', parseInt(e.target.value))}
                    className="h-12 pl-12"
                  />
                </div>
              </div>

              <Button
                type="submit"
                disabled={isCreating || !formData.name}
                className="w-full h-12 shadow-lg hover:opacity-90"
                style={{ backgroundColor: '#006C35', color: '#FAF7F2' }}
              >
                {isCreating ? "Creating Academy..." : "Create Academy"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
