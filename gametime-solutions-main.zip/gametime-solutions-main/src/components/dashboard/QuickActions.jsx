import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlayCircle, Users, Eye, Target } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function QuickActions() {
  const actions = [
    {
      id: "record",
      icon: PlayCircle,
      label: "Start Recording",
      description: "Go to your matches to start a new recording.",
      link: createPageUrl("Matches"),
    },
    {
      id: "assign",
      icon: Users,
      label: "Manage Players",
      description: "Add new players or edit your current roster.",
      link: createPageUrl("Players"),
    },
    {
      id: "review",
      icon: Eye,
      label: "Review Matches",
      description: "Review recordings and analyze completed matches.",
      link: createPageUrl("Matches"),
    },
  ];

  return (
    <Card className="border-0 shadow-lg bg-white">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-slate-800">
          <Target className="w-5 h-5" />
          Quick Actions
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {actions.map((action) => (
          <Link to={action.link} key={action.id}>
            <Button variant="outline" className="w-full justify-start h-auto p-3 text-left border-slate-200 hover:bg-slate-50 hover:border-slate-300">
              <action.icon className="w-5 h-5 mr-3 text-slate-500" />
              <div>
                <p className="font-semibold text-slate-800">{action.label}</p>
                <p className="text-xs text-slate-500 font-normal">{action.description}</p>
              </div>
            </Button>
          </Link>
        ))}
      </CardContent>
    </Card>
  );
}