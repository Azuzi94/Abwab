
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Filter, X, CheckSquare } from "lucide-react";
import { format } from "date-fns";
import { Checkbox } from "@/components/ui/checkbox";

export default function MatchFilters({ filters, onFilterChange, teams, onClearFilters }) {
  const statusOptions = [
    { value: "all", label: "All Status" },
    { value: "planned", label: "Planned" },
    { value: "ready_for_recording", label: "Ready for Recording" },
    { value: "recording", label: "Recording" },
    { value: "recorded", label: "Recorded" },
    { value: "uploading", label: "Uploading" },
    { value: "uploaded", label: "Uploaded" },
    { value: "post_processing", label: "Post Processing" },
    { value: "finished", label: "Finished" },
    { value: "error", label: "Error" }
  ];

  const hasActiveFilters =
    filters.status !== "all" ||
    (Array.isArray(filters.teams) && filters.teams.length > 0) ||
    filters.dateFrom ||
    filters.dateTo;

  const teamList = teams || [];
  const selectedTeams = Array.isArray(filters.teams) ? filters.teams : [];

  const toggleTeam = (teamId) => {
    const exists = selectedTeams.includes(teamId);
    const next = exists
      ? selectedTeams.filter((t) => t !== teamId)
      : [...selectedTeams, teamId];
    onFilterChange({ ...filters, teams: next });
  };

  const clearTeams = () => onFilterChange({ ...filters, teams: [] });

  return (
    <Card className="mb-6">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-500" />
            <h3 className="font-medium text-slate-900">Filters</h3>
          </div>
          {hasActiveFilters && (
            <Button variant="ghost" size="sm" onClick={onClearFilters}>
              <X className="w-4 h-4 mr-1" />
              Clear All
            </Button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Status Filter */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Status</Label>
            <Select
              value={filters.status}
              onValueChange={(value) => onFilterChange({ ...filters, status: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                {statusOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Teams Multi-Select */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Teams</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-between">
                  <span className="truncate">
                    {selectedTeams.length === 0
                      ? "All Teams"
                      : `${selectedTeams.length} selected`}
                  </span>
                  <CheckSquare className="w-4 h-4 ml-2 opacity-60" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-64 p-3">
                <div className="max-h-56 overflow-auto pr-1">
                  {teamList.map((team) => {
                    const checked = selectedTeams.includes(team.id);
                    return (
                      <label
                        key={team.id}
                        className="flex items-center gap-2 py-1.5 cursor-pointer"
                      >
                        <Checkbox
                          checked={checked}
                          onCheckedChange={() => toggleTeam(team.id)}
                        />
                        <span className="text-sm">{team.name}</span>
                      </label>
                    );
                  })}
                </div>
                <div className="flex justify-between mt-3">
                  <Button variant="ghost" size="sm" onClick={clearTeams}>
                    Clear
                  </Button>
                  {/* The 'Done' button action here is effectively a no-op if toggleTeam already updates state */}
                  {/* It can serve as a visual cue or to close the popover. */}
                  <Button variant="outline" size="sm" onClick={() => { /* Popover closes on interaction outside or on next render */ }}>
                    Done
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
          </div>

          {/* Date From Filter */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">From Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {filters.dateFrom ? format(filters.dateFrom, "MMM d, yyyy") : "Select date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={filters.dateFrom}
                  onSelect={(date) => onFilterChange({ ...filters, dateFrom: date })}
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Date To Filter */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">To Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {filters.dateTo ? format(filters.dateTo, "MMM d, yyyy") : "Select date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={filters.dateTo}
                  onSelect={(date) => onFilterChange({ ...filters, dateTo: date })}
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
