
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, Trophy, Eye, Play, CalendarClock, Video, CircleDot, Clapperboard, Upload, FileCheck, Cog, CheckCircle2, XCircle } from "lucide-react";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { BarChart3 } from "lucide-react";


// Local 12h formatting helpers
const fmtDateLocal = (iso) => {
  if (!iso) return "TBD";
  try {return format(new Date(iso), "MMM d, yyyy");} catch {return "TBD";}
};
const fmtTime12Local = (iso) => {
  if (!iso) return "";
  try {return format(new Date(iso), "hh:mm a");} catch {return "";}
};

// Unified status mapping (icon + colors)
const getStatusVisual = (rawStatus) => {
  const s = (rawStatus || "").toLowerCase();
  switch (s) {
    case "planned":
      return { label: "Planned", Icon: CalendarClock, gradient: "from-slate-400 to-slate-500", iconBg: "bg-slate-50", iconColor: "text-slate-600", textColor: "text-slate-700", dotColor: "text-slate-500" };
    case "ready_for_recording":
      return { label: "Ready", Icon: Video, gradient: "from-blue-500 to-blue-600", iconBg: "bg-blue-50", iconColor: "text-blue-600", textColor: "text-blue-700", dotColor: "text-blue-600" };
    case "recording":
      return { label: "Recording", Icon: CircleDot, gradient: "from-red-600 to-red-700", iconBg: "bg-red-50", iconColor: "text-red-600", textColor: "text-red-700", dotColor: "text-red-600" };
    case "recorded":
      return { label: "Recorded", Icon: Clapperboard, gradient: "from-indigo-500 to-purple-600", iconBg: "bg-indigo-50", iconColor: "text-indigo-600", textColor: "text-indigo-700", dotColor: "text-indigo-600" };
    case "uploading":
      return { label: "Uploading", Icon: Upload, gradient: "from-orange-500 to-orange-600", iconBg: "bg-orange-50", iconColor: "text-orange-600", textColor: "text-orange-700", dotColor: "text-orange-600" };
    case "uploaded":
      return { label: "Uploaded", Icon: FileCheck, gradient: "from-teal-500 to-emerald-600", iconBg: "bg-teal-50", iconColor: "text-teal-600", textColor: "text-teal-700", dotColor: "text-teal-600" };
    case "post_processing":
      return { label: "Post Processing", Icon: Cog, gradient: "from-yellow-400 to-yellow-500", iconBg: "bg-yellow-50", iconColor: "text-yellow-600", textColor: "text-yellow-700", dotColor: "text-yellow-600" };
    case "finished":
    case "completed":
      return { label: "Finished", Icon: CheckCircle2, gradient: "from-green-600 to-green-700", iconBg: "bg-green-50", iconColor: "text-green-700", textColor: "text-green-800", dotColor: "text-green-700" };
    case "live":
      return { label: "Live", Icon: CircleDot, gradient: "from-green-500 to-green-600", iconBg: "bg-green-50", iconColor: "text-green-600", textColor: "text-green-700", dotColor: "text-green-600" };
    case "cancelled": // Added explicit cancelled status
      return { label: "Cancelled", Icon: XCircle, gradient: "from-red-500 to-red-600", iconBg: "bg-red-50", iconColor: "text-red-600", textColor: "text-red-700", dotColor: "text-red-600" };
    case "error":
      return { label: "Error", Icon: XCircle, gradient: "from-red-500 to-red-600", iconBg: "bg-red-50", iconColor: "text-red-600", textColor: "text-red-700", dotColor: "text-red-600" };
    default:
      return { label: s || "Unknown", Icon: Calendar, gradient: "from-slate-500 to-slate-600", iconBg: "bg-slate-50", iconColor: "text-slate-600", textColor: "text-slate-700", dotColor: "text-slate-500" };
  }
};

export default function MatchCard({ match, onViewDetails }) {
  const visuals = getStatusVisual(match.raw_status || match.status);

  const formatMatchDate = (dateStr) => {
    try {
      if (dateStr) {
        return {
          date: fmtDateLocal(dateStr) || "TBD",
          time: fmtTime12Local(dateStr) || ""
        };
      }
      return { date: "TBD", time: "" };
    } catch {
      return { date: "TBD", time: "" };
    }
  };

  const { date, time } = formatMatchDate(match.match_date);
  const statusLower = (match.raw_status || match.status || "").toLowerCase();
  const scoreStatuses = ["finished", "recorded", "uploaded", "uploading", "post_processing"];
  const hasScore = scoreStatuses.includes(statusLower) &&
  match.home_score !== undefined && match.away_score !== undefined;

  // Helper for "Last updated"
  const fmtUpdated = (iso) => {
    if (!iso) return null;
    try {return format(new Date(iso), "MMM d, yyyy hh:mm a");} catch {return null;}
  };
  const lastUpdatedText = fmtUpdated(match.last_updated);

  return (
    <Card className="group relative overflow-hidden bg-white hover:shadow-xl transition-all duration-300 border-0 shadow-md hover:scale-[1.02]">
      {/* Brand status accent bar (consistent across devices) */}
      <div className="status-gradient no-forced-colors" data-status={statusLower}></div>

      {/* Soft decorative background using same status colors */}
      <div className="pointer-events-none absolute top-0 right-0 w-32 h-32 opacity-[0.06] no-forced-colors">
        <div className="w-full h-full rounded-full transform translate-x-16 -translate-y-16 status-gradient-bg" data-status={statusLower}></div>
      </div>
      
      <CardContent className="p-6 flex flex-col h-full">
        <div className="flex-grow">
          {/* Header with Icon, Title and Status line (modified) */}
          <div className="flex items-start gap-3 mb-5">
            <div className={`p-3 rounded-xl ${visuals.iconBg}`}>
              <visuals.Icon className={`w-5 h-5 ${visuals.iconColor}`} />
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-bold text-slate-900 group-hover:text-slate-700 transition-colors leading-tight">
                {match.home_team_name} <span className="text-slate-400 font-normal">vs</span> {match.away_team_name}
              </h3>
              {/* Status line under title WITHOUT icon */}
              <div className={`mt-1 ${visuals.textColor}`}>
                <span className="text-sm font-medium">{visuals.label}</span>
              </div>
            </div>
          </div>

          {/* Match Details Grid */}
          <div className="grid grid-cols-1 gap-4 mb-6">
            {/* Date and Time */}
            <div className="flex items-center gap-3 text-slate-600">
              <div className="flex items-center justify-center w-8 h-8 bg-slate-100 rounded-lg">
                <Calendar className="w-4 h-4 text-slate-500" />
              </div>
              <div>
                <div className="font-semibold text-slate-900 text-sm">{date}</div>
                {time && <div className="text-xs text-slate-500">{time}</div>}
              </div>
            </div>

            {/* Score */}
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-8 h-8 bg-slate-100 rounded-lg">
                <Trophy className="w-4 h-4 text-slate-500" />
              </div>
              <div className="flex items-center gap-3">
                <span className="text-sm font-medium text-slate-600">Score:</span>
                {hasScore ?
                <div className="flex items-center gap-3 bg-slate-50 px-4 py-2 rounded-lg">
                    <span className="text-2xl font-bold text-slate-900 min-w-[24px] text-center">{match.home_score}</span>
                    <div className="w-px h-6 bg-slate-300"></div>
                    <span className="text-2xl font-bold text-slate-900 min-w-[24px] text-center">{match.away_score}</span>
                  </div> :

                <div className="flex items-center gap-2 text-slate-400 bg-slate-50 px-4 py-2 rounded-lg">
                    <span className="text-lg">-</span>
                    <div className="w-px h-4 bg-slate-300"></div>
                    <span className="text-lg">-</span>
                  </div>
                }
              </div>
            </div>

            {/* Venue if available */}
            {match.venue &&
            <div className="flex items-center gap-3 text-slate-600">
                <div className="flex items-center justify-center w-8 h-8 bg-slate-100 rounded-lg">
                  <MapPin className="w-4 h-4 text-slate-500" />
                </div>
                <div>
                  <div className="font-medium text-slate-700 text-sm">{match.venue}</div>
                </div>
              </div>
            }
          </div>
        </div>

        {lastUpdatedText &&
        <div className="text-slate-500 mt-3 mb-1 text-xs">
            Last updated: {lastUpdatedText}
          </div>
        }

        {/* Action Buttons */}
        <div className="pt-4 border-t border-slate-100 mt-auto">
          <div className="flex items-center gap-2">
            <Button
              className="flex-1 bg-gradient-to-r from-slate-900 to-slate-800 hover:from-slate-800 hover:to-slate-700 text-white shadow-lg hover:shadow-xl transition-all duration-200 group/btn"
              onClick={() => onViewDetails(match)}>

              <Eye className="w-4 h-4 mr-2 group-hover/btn:scale-110 transition-transform" />
              View Details
            </Button>
            {statusLower === 'finished' &&
              <Link to={createPageUrl(`AfterMatchAnalysis?match_id=${match.id}`)} className="flex-1">
                <Button variant="outline" className="w-full border-slate-300 hover:bg-slate-100">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Analyze
                </Button>
              </Link>
            }
          </div>
        </div>
      </CardContent>
    </Card>);

}
