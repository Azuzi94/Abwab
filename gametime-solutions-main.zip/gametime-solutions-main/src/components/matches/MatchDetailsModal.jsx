
import React from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { CalendarDays, Clock, Video, Map, Trash2, CircleDot, CalendarClock, Clapperboard, Upload, FileCheck, Cog, CheckCircle2, XCircle, BarChart3 } from "lucide-react";
import { getMatchUpdate } from "@/api/functions";
import { Match } from "@/api/entities";
import { useToast } from "@/components/ui/use-toast";
import { useNavigate, Link } from "react-router-dom"; // Added Link
import { getWatchUrl } from "@/api/functions";
import { deleteMatch } from "@/api/functions";
import { format, parseISO } from "date-fns";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useConfirmDialog } from "@/components/providers/ConfirmDialogProvider";

// Local helpers for 12h date/time
const fmtDateOnly = (iso) => {
  if (!iso) return "";
  try {
    const d = typeof iso === "string" ? parseISO(iso) : new Date(iso);
    return format(d, "MMM d, yyyy");
  } catch {
    return "";
  }
};
const fmtTimeOnly = (iso) => {
  if (!iso) return "";
  try {
    const d = typeof iso === "string" ? parseISO(iso) : new Date(iso);
    return format(d, "hh:mm a");
  } catch {
    return "";
  }
};

// Unified status visuals for modal
const statusVisual = (raw) => {
  const s = (raw || "").toLowerCase();
  switch (s) {
    case "planned": return { label: "Planned", textColor: "text-slate-700", iconColor: "text-slate-600", Icon: CalendarClock, gradient: "from-slate-400 to-slate-500" };
    case "ready_for_recording": return { label: "Ready", textColor: "text-blue-700", iconColor: "text-blue-600", Icon: Video, gradient: "from-blue-500 to-blue-600" };
    case "recording": return { label: "Recording", textColor: "text-red-700", iconColor: "text-red-600", Icon: CircleDot, gradient: "from-red-600 to-red-700" };
    case "recorded": return { label: "Recorded", textColor: "text-indigo-700", iconColor: "text-indigo-600", Icon: Clapperboard, gradient: "from-indigo-500 to-purple-600" };
    case "uploading": return { label: "Uploading", textColor: "text-orange-700", iconColor: "text-orange-600", Icon: Upload, gradient: "from-orange-500 to-orange-600" };
    case "uploaded": return { label: "Uploaded", textColor: "text-teal-700", iconColor: "text-teal-600", Icon: FileCheck, gradient: "from-teal-500 to-emerald-600" };
    case "post_processing": return { label: "Post Processing", textColor: "text-yellow-700", iconColor: "text-yellow-600", Icon: Cog, gradient: "from-yellow-400 to-yellow-500" };
    case "finished":
    case "completed": return { label: "Finished", textColor: "text-green-800", iconColor: "text-green-700", Icon: CheckCircle2, gradient: "from-green-600 to-green-700" };
    case "live": return { label: "Live", textColor: "text-green-700", iconColor: "text-green-600", Icon: CircleDot, gradient: "from-green-500 to-green-600" };
    case "error": return { label: "Error", textColor: "text-red-700", iconColor: "text-red-600", Icon: XCircle, gradient: "from-red-500 to-red-600" };
    default: return { label: raw || "Unknown", textColor: "text-slate-700", iconColor: "text-slate-600", Icon: CalendarClock, gradient: "from-slate-500 to-slate-600" };
  }
};

export default function MatchDetailsModal({ open, onClose, match, onUpdated, onDeleted }) {
  const [loading, setLoading] = React.useState(false);
  const [details, setDetails] = React.useState(null);
  const [error, setError] = React.useState(null);
  const [actionLoading, setActionLoading] = React.useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  const confirm = useConfirmDialog();

  const [videoUrls, setVideoUrls] = React.useState(null);
  const [selectedView, setSelectedView] = React.useState("panoramic");

  const combined = (details?.status || details?.raw_status || match?.raw_status || match?.status || "").toLowerCase();
  const visuals = statusVisual(combined);

  const titleText = () => {
    const home = details?.team_home?.name || match?.home_team_name;
    const away = details?.team_away?.name || match?.away_team_name;
    if (!home && !away) return "";
    return `${home || ""}${home && away ? " vs " : ""}${away || ""}`;
  };

  const fetchDetails = async () => {
    if (!match?.abwab_match_id) {
      setDetails(null);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const { data, error } = await getMatchUpdate({ match_id: match.abwab_match_id });
      if (error || !data?.match) {
        setError("Couldn't load details. Please retry.");
      } else {
        setDetails(data.match);
      }
    } catch (e) {
      setError("Couldn't load details. Please retry.");
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    if (open) {
      fetchDetails();
      // Reset video URLs when modal opens or match changes to prevent stale videos
      setVideoUrls(null); 
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, match?.abwab_match_id]);

  const onDeleteMatch = async () => {
    if (!match?.abwab_match_id) return;
    const msgTitle = "Confirm Action";
    const msgBody = `This action cannot be undone. Delete match${titleText() ? ` "${titleText()}"` : ""}?`;
    const ok = await confirm({
      title: msgTitle,
      message: msgBody,
      confirmText: "Delete",
      cancelText: "Cancel"
    });
    if (!ok) return;

    setActionLoading(true);
    const { data, error } = await deleteMatch({ match_id: match.abwab_match_id });
    if (error || data?.error) {
      toast({ variant: "destructive", title: "Unable to delete match" });
      setActionLoading(false);
      return;
    }
    if (match?.id) {
      await Match.delete(match.id);
    }
    toast({ title: "Match deleted." });
    setActionLoading(false);
    onDeleted?.();
    onClose();
  };

  const onWatch = async () => {
    if (!match?.abwab_match_id) return;
    setActionLoading(true);
    try {
      const { data } = await getWatchUrl({ match_id: match.abwab_match_id });
      if (!data?.success || (!data?.panoramic_view && !data?.tactical_view)) {
        toast({ variant: "destructive", title: "Video is not yet available. Only finished matches have replay URLs." });
        setVideoUrls(null); // Clear any previous URLs
        return;
      }
      setVideoUrls({ panoramic: data.panoramic_view, tactical: data.tactical_view });
      // Set default view to panoramic if available, otherwise tactical
      setSelectedView(data.panoramic_view ? "panoramic" : (data.tactical_view ? "tactical" : null));
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <DialogHeader className="space-y-1">
          <div className="flex items-start gap-3">
            <div className={`p-3 rounded-xl bg-white border`}>
              <visuals.Icon className={`w-5 h-5 ${visuals.iconColor}`} />
            </div>
            <div className="flex-1">
              <DialogTitle className="text-xl font-semibold">Match Details</DialogTitle>
              {!!(details?.team_home?.name || match?.home_team_name || details?.team_away?.name || match?.away_team_name) && (
                <div className="text-slate-600 mt-1">
                  {(details?.team_home?.name || match?.home_team_name) || ""}{(details?.team_home?.name || match?.home_team_name) && (details?.team_away?.name || match?.away_team_name) ? " vs " : ""}{(details?.team_away?.name || match?.away_team_name) || ""}
                </div>
              )}
              {/* Status under title WITHOUT icon (avoid duplication) */}
              <div className={`mt-1 ${visuals.textColor}`}>
                <span className="text-sm font-medium">{visuals.label}</span>
              </div>
            </div>
          </div>
        </DialogHeader>

        {/* Main content */}
        <div className="space-y-5">
          {loading && <div className="py-6 text-center text-slate-500">Loading details...</div>}
          {!loading && error && <div className="py-3 text-center text-red-600">{error}</div>}

          {!loading && !error &&
          <>
            {/* Summary strip - styled like dashboard card */}
            <div className="relative bg-white rounded-xl shadow-md border-0 p-4 grid grid-cols-1 md:grid-cols-4 gap-3 items-center">
              <div className="status-gradient no-forced-colors rounded-t-xl" data-status={combined}></div>
              <div className="pointer-events-none absolute top-0 right-0 w-28 h-28 opacity-[0.06]">
                <div className="w-full h-full rounded-full transform translate-x-10 -translate-y-10 status-gradient-bg no-forced-colors" data-status={combined}></div>
              </div>
              {(details?.start_time || match?.match_date) &&
                <div className="flex items-center gap-2 text-slate-700">
                  <CalendarDays className="w-4 h-4" />
                  <span className="font-medium">{fmtDateOnly(details?.start_time || match?.match_date)}</span>
                </div>
              }
              {(details?.duration || match?.duration) &&
                <div className="flex items-center gap-2 text-slate-700">
                  <Clock className="w-4 h-4" />
                  <span>{details?.duration || match?.duration} minutes</span>
                </div>
              }
              {(details?.live || match?.live) &&
                <div className="inline-flex items-center gap-1 text-green-700 bg-green-50 border border-green-200 px-2 py-1 rounded">
                  <CheckCircle2 className="w-4 h-4" />
                  <span className="text-sm font-medium">Live</span>
                </div>
              }
            </div>

            {/* Teams block - two card-style panels */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {(details?.team_home?.name || match?.home_team_name) &&
                <div className="rounded-xl bg-white shadow-md border-0 p-4">
                  <div className="text-xs uppercase text-slate-500 mb-1">Home Team</div>
                  <div className="text-slate-900 font-semibold">
                    {details?.team_home?.name || match?.home_team_name}
                  </div>
                  {details?.team_home?.club?.name && 
                    <div className="text-slate-500 text-sm">{details.team_home.club.name}</div>
                  }
                </div>
              }
              {(details?.team_away?.name || match?.away_team_name) &&
                <div className="rounded-xl bg-white shadow-md border-0 p-4">
                  <div className="text-xs uppercase text-slate-500 mb-1">Away Team</div>
                  <div className="text-slate-900 font-semibold">
                    {details?.team_away?.name || match?.away_team_name}
                  </div>
                  {details?.team_away?.club?.name && 
                    <div className="text-slate-500 text-sm">{details.team_away.club.name}</div>
                  }
                </div>
              }
            </div>

            {/* Timeline block - labels and time-only */}
            {(details?.recording_start_time || details?.end_time) &&
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 rounded-xl bg-white shadow-md border-0 p-4">
                {details?.recording_start_time &&
                  <div>
                    <div className="text-xs uppercase text-slate-500">Match Start Time</div>
                    <div className="text-slate-800">{fmtTimeOnly(details.recording_start_time)}</div>
                  </div>
                }
                {details?.end_time &&
                  <div className="md:border-l md:pl-4">
                    <div className="text-xs uppercase text-slate-500">Match End Time</div>
                    <div className="text-slate-800">{fmtTimeOnly(details.end_time)}</div>
                  </div>
                }
              </div>
            }

            {/* Metadata row - Created By and Field side by side */}
            {(match?.created_by || details?.recording_system || match?.recording_system) &&
              <div className="rounded-xl bg-white shadow-md border-0 p-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {match?.created_by &&
                    <div>
                      <div className="text-xs uppercase text-slate-500">Created By</div>
                      <div className="text-slate-800 break-all">{match.created_by}</div>
                    </div>
                  }
                  {(details?.recording_system || match?.recording_system) &&
                    <div>
                      <div className="text-xs uppercase text-slate-500">Field</div>
                      <div className="text-slate-800">{details?.recording_system || match?.recording_system}</div>
                    </div>
                  }
                </div>
              </div>
            }

            {/* Inline video player (only shown once URLs fetched and not null) */}
            {videoUrls && (videoUrls.panoramic || videoUrls.tactical) && (
              <div className="rounded-xl bg-white shadow-md border-0 p-0 overflow-hidden">
                <div className="status-gradient no-forced-colors" data-status={combined}></div>
                <div className="p-4">
                  <Tabs value={selectedView} onValueChange={setSelectedView}>
                    <TabsList className="mb-3">
                      {videoUrls.panoramic && <TabsTrigger value="panoramic">Panoramic View</TabsTrigger>}
                      {videoUrls.tactical && <TabsTrigger value="tactical">Tactical View</TabsTrigger>}
                    </TabsList>
                    {videoUrls.panoramic && (
                      <TabsContent value="panoramic" className="m-0">
                        <div className="aspect-video w-full bg-black rounded-lg overflow-hidden">
                          <video src={videoUrls.panoramic} controls className="w-full h-full" />
                        </div>
                      </TabsContent>
                    )}
                    {videoUrls.tactical && (
                      <TabsContent value="tactical" className="m-0">
                        <div className="aspect-video w-full bg-black rounded-lg overflow-hidden">
                          <video src={videoUrls.tactical} controls className="w-full h-full" />
                        </div>
                      </TabsContent>
                    )}
                  </Tabs>
                </div>
              </div>
            )}
          </>
          }
        </div>

        {/* Actions */}
        {!loading &&
          <DialogFooter className="flex flex-col md:flex-row gap-2 md:justify-between mt-2">
            <div className="flex flex-wrap gap-2">
              {combined === "planned" &&
                <Button variant="destructive" onClick={onDeleteMatch} disabled={actionLoading}>
                  <Trash2 className="w-4 h-4 mr-2" />
                  {actionLoading ? "Deleting..." : "Delete Match"}
                </Button>
              }
              {/* Only finished matches should attempt to play video */}
              {combined === "finished" && (
                <>
                  <Button variant="default" onClick={onWatch} disabled={actionLoading} className="bg-slate-900 hover:bg-slate-800">
                    <Video className="w-4 h-4 mr-2" />
                    {actionLoading ? "Loading..." : "Watch Video"}
                  </Button>
                  {/* "Start Analysis" button */}
                  {match?.id && (
                    <Link to={`/AfterMatchAnalysis?match_id=${match?.id}`} onClick={onClose}>
                      <Button variant="outline">
                        <BarChart3 className="w-4 h-4 mr-2" />
                        Start Analysis
                      </Button>
                    </Link>
                  )}
                </>
              )}
            </div>
            <Button variant="outline" onClick={onClose}>Close</Button>
          </DialogFooter>
        }
      </DialogContent>
    </Dialog>
  );
}
