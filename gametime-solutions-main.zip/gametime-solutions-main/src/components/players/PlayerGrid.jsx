
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { User, MoreVertical, UserX, Pencil, Trash } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useLanguage } from '@/components/providers/LanguageProvider';

export default function PlayerGrid({ players, onEditPlayer, onDelete, onSelect, selectedRows, onViewProfile }) {
  const { t } = useLanguage();

  const getPositionColor = (position) => {
    switch (position) {
      case 'goalkeeper': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'defender': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'midfielder': return 'bg-green-100 text-green-800 border-green-200';
      case 'forward': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'injured': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'suspended': return 'bg-red-100 text-red-800 border-red-200';
      case 'inactive': return 'bg-slate-100 text-slate-800 border-slate-200';
      case 'active': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  if (players.length === 0) {
    return (
      <div className="text-center py-20 bg-white rounded-lg shadow">
        <UserX className="w-16 h-16 mx-auto text-slate-300" />
        <h3 className="mt-4 text-xl font-semibold text-slate-700">{t('playersPage.grid.no_players_title')}</h3>
        <p className="mt-2 text-slate-500">{t('playersPage.grid.no_players_desc')}</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {players.map((player) => (
        <Card key={player.id} className="group border-0 shadow-lg shadow-slate-200/50 hover:shadow-xl hover:shadow-slate-200/60 transition-all duration-300 overflow-hidden bg-white">
          <CardContent className="p-0 relative">
            {/* Player Photo Background */}
            <div className="w-full h-48 bg-slate-200 flex items-center justify-center overflow-hidden">
              <Avatar className="w-full h-full rounded-none">
                  <AvatarImage src={player.photo_url} alt={`${player.first_name} ${player.last_name}`} className="object-cover w-full h-full" />
                  <AvatarFallback className="w-full h-full bg-gradient-to-r from-blue-500 to-cyan-400 text-white text-3xl font-bold flex items-center justify-center rounded-none">
                      {player.first_name?.[0]}{player.last_name?.[0]}
                  </AvatarFallback>
              </Avatar>
            </div>

            {/* Jersey Number */}
            <div className="absolute top-2 left-2 z-10">
              <div className="w-8 h-8 bg-slate-900 text-white rounded-md flex items-center justify-center text-sm font-bold shadow-md">
                {player.jersey_number}
              </div>
            </div>

            {/* Menu */}
            <div className="absolute top-2 right-2 z-10 flex items-center gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full bg-black/20 hover:bg-black/30 text-white transition-colors">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-white border border-slate-200 shadow-lg">
                  <DropdownMenuItem onClick={() => onViewProfile(player)} className="hover:bg-slate-50 transition-colors">
                    <User className="w-4 h-4 me-2"/>
                    {t('playersPage.actions.view_profile')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onEditPlayer(player)} className="hover:bg-slate-50 transition-colors">
                    <Pencil className="w-4 h-4 me-2"/>
                    {t('playersPage.actions.edit')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onDelete(player)} className="text-red-500 hover:bg-red-50 transition-colors">
                    <Trash className="w-4 h-4 me-2"/>
                    {t('playersPage.actions.delete')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            
            {/* Player Info Overlay */}
            <div 
              className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent text-white z-10 cursor-pointer hover:from-black/90 transition-all duration-200"
              onClick={() => onViewProfile(player)}
            >
                <div className="flex items-center gap-3 mb-2">
                    <Avatar className="w-12 h-12 ring-2 ring-white shadow-lg">
                        <AvatarImage src={player.photo_url} />
                        <AvatarFallback className="bg-gradient-to-r from-blue-500 to-cyan-400 text-white text-xl font-bold">
                            {player.first_name?.[0]}{player.last_name?.[0]}
                        </AvatarFallback>
                    </Avatar>
                    <div>
                        <h3 className="text-lg font-bold truncate">{player.first_name} {player.last_name}</h3>
                        <span className="text-sm">{t('playersPage.grid.age', { age: player.age })}</span>
                    </div>
                </div>
                <div className="flex gap-2 mt-2">
                    <Badge className={`${getPositionColor(player.position)} border-0`}>{t(`playersPage.positions.${player.position}`)}</Badge>
                    <Badge className={`${getStatusColor(player.status)} border-0`}>{t(`playersPage.statuses.${player.status}`)}</Badge>
                </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
