import React from 'react';
import { Button } from "@/components/ui/button";
import { Download, Plus, Trash, Pencil, Upload, LayoutGrid, List } from 'lucide-react';
import { useLanguage } from '@/components/providers/LanguageProvider';

export default function PlayerToolbar({ 
  onAddPlayer, 
  onBulkUpload, 
  onExport, 
  onBulkEdit, 
  onBulkDelete, 
  selectedPlayersCount, 
  viewMode, 
  onViewModeChange 
}) {
  const { t } = useLanguage();
  
  return (
    <div className="bg-white p-3 rounded-xl shadow-sm border border-slate-200">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          {selectedPlayersCount > 0 ? (
            <>
              <span className="text-sm font-medium text-slate-600 border-r pe-2 me-1">
                {t('playersPage.toolbar.selected', { count: selectedPlayersCount })}
              </span>
              <Button variant="outline" size="sm" onClick={onBulkEdit}>
                <Pencil className="w-4 h-4 me-2" />
                {t('playersPage.toolbar.bulk_edit')}
              </Button>
              <Button variant="destructive" size="sm" onClick={onBulkDelete}>
                <Trash className="w-4 h-4 me-2" />
                {t('playersPage.toolbar.delete')}
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" size="sm" onClick={onExport}>
                <Download className="w-4 h-4 me-2" />
                {t('playersPage.toolbar.export')}
              </Button>
              <Button variant="outline" size="sm" onClick={onBulkUpload}>
                <Upload className="w-4 h-4 me-2" />
                {t('playersPage.toolbar.bulk_upload')}
              </Button>
              <Button size="sm" onClick={onAddPlayer}>
                <Plus className="w-4 h-4 me-2" />
                {t('playersPage.toolbar.add')}
              </Button>
            </>
          )}
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-200 rounded-lg">
          <Button
            variant={viewMode === 'card' ? 'secondary' : 'ghost'}
            size="icon"
            onClick={() => onViewModeChange('card')}
            aria-label="Card view"
          >
            <LayoutGrid className="w-4 h-4" />
          </Button>
          <Button
            variant={viewMode === 'table' ? 'secondary' : 'ghost'}
            size="icon"
            onClick={() => onViewModeChange('table')}
            aria-label="Table view"
          >
            <List className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}