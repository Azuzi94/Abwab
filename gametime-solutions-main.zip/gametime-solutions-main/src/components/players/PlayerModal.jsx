
import React, { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogFooter, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { CalendarIcon, UploadCloud, User, Badge as BadgeIcon } from "lucide-react";
import { format, differenceInYears } from "date-fns";
import { useToast } from "@/components/ui/use-toast";
import { UploadFile } from "@/api/integrations";
import { useLanguage } from "@/components/providers/LanguageProvider";
import { Badge } from "@/components/ui/badge";
import { TeamPlayer } from "@/api/entities";
import { Player } from "@/api/entities"; // Assuming Player entity exists for duplicate checks

const getInitialData = (player) => ({
    first_name: player?.first_name || "",
    middle_name: player?.middle_name || "",
    last_name: player?.last_name || "",
    phone_e164: player?.phone_e164 || "",
    jersey_number: player?.jersey_number || "",
    date_of_birth: player?.date_of_birth ? new Date(player.date_of_birth) : null,
    height: player?.height || "",
    weight: player?.weight || "",
    preferred_foot: player?.preferred_foot || "right",
    position: player?.position || "",
    team_id: player?.team_id || "",
    status: player?.status || "active",
    tags: player?.tags || [],
    notes: player?.notes || "",
    photo_url: player?.photo_url || "",
    guardian_name: player?.guardian_name || "",
    guardian_phone: player?.guardian_phone || ""
});

export default function PlayerModal({ isOpen, onClose, onSave, player, teams, allTags = [] }) {
    const [formData, setFormData] = useState(getInitialData(player));
    const [photoPreview, setPhotoPreview] = useState(null);
    const [photoFile, setPhotoFile] = useState(null);
    const [errors, setErrors] = useState({});
    const [isSaving, setIsSaving] = useState(false);
    const [tagInput, setTagInput] = useState("");
    const [suggestedTags, setSuggestedTags] = useState([]);
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [duplicate, setDuplicate] = useState(null);
    const fileInputRef = useRef(null);
    const { toast } = useToast();
    const { t } = useLanguage();

    useEffect(() => {
        setFormData(getInitialData(player));
        setPhotoPreview(player?.photo_url || null);
        setPhotoFile(null);
        setErrors({});
        setDuplicate(null);
    }, [player, isOpen]);

    const handlePhotoChange = (e) => {
        const file = e.target.files[0];
        if (file && file.type.startsWith("image/")) {
            setPhotoFile(file);
            setPhotoPreview(URL.createObjectURL(file));
        }
    };
    
    // NEW: Normalize SA phone helper
    const normalizeSaudiPhone = (val) => {
        if (!val) return "";
        let s = String(val).trim();
        // keep digits and plus, drop spaces/dashes
        s = s.replace(/[^\d+]/g, "");
        // strip leading +
        let digits = s.startsWith("+") ? s.slice(1) : s;
        // handle 00xx prefix
        if (digits.startsWith("00")) digits = digits.slice(2);
        // drop country code if present
        if (digits.startsWith("966")) digits = digits.slice(3);
        // drop leading 0 (e.g., 05xxxxxxxx)
        if (digits.startsWith("0")) digits = digits.slice(1);
        // final E.164 for KSA
        return "+966" + digits;
    };

    // EDIT: tag input change -> compute suggestions
    const handleTagInputChange = (e) => {
      const value = e.target.value;
      setTagInput(value);
      const v = value.trim().toLowerCase();
      if (!v) {
        setSuggestedTags([]);
        setShowSuggestions(false);
        return;
      }
      const suggestions = (allTags || [])
        .filter(t => t.toLowerCase().includes(v) && !formData.tags.includes(t))
        .slice(0, 8);
      setSuggestedTags(suggestions);
      setShowSuggestions(suggestions.length > 0);
    };

    const handleTagKeyDown = (e) => {
      if (e.key === 'Enter' || e.key === ',') {
        e.preventDefault();
        const newTag = tagInput.trim();
        if (newTag && !formData.tags.includes(newTag)) {
          setFormData(prev => ({...prev, tags: [...prev.tags, newTag]}));
        }
        setTagInput("");
        setSuggestedTags([]);
        setShowSuggestions(false);
      }
    };
    
    const removeTag = (tagToRemove) => {
      setFormData(prev => ({...prev, tags: prev.tags.filter(tag => tag !== tagToRemove)}));
    };

    const selectSuggestedTag = (tag) => {
      if (!formData.tags.includes(tag)) {
        setFormData(prev => ({...prev, tags: [...prev.tags, tag]}));
      }
      setTagInput("");
      setSuggestedTags([]);
      setShowSuggestions(false);
    };

    const validate = () => {
        const newErrors = {};
        const e164Regex = /^\+?[1-9]\d{6,14}$/;

        // Normalize then validate
        const normalizedPhone = normalizeSaudiPhone(formData.phone_e164);
        const withPhone = { ...formData, phone_e164: normalizedPhone };

        if (!withPhone.first_name) newErrors.first_name = t('playersPage.modal.errors.first_name_req');
        if (!withPhone.last_name) newErrors.last_name = t('playersPage.modal.errors.last_name_req');
        // jersey_number is no longer a required field based on outline
        if (!withPhone.position) newErrors.position = t('playersPage.modal.errors.position_req');
        if (!withPhone.photo_url && !photoFile) newErrors.photo = t('playersPage.modal.errors.photo_req');

        if (!withPhone.phone_e164 || !e164Regex.test(withPhone.phone_e164)) {
            newErrors.phone_e164 = t('playersPage.modal.errors.phone_e164_invalid'); // "Valid E.164 phone is required (e.g., +966512345678)."
        } else {
            // apply normalized value back if it changed
            if (withPhone.phone_e164 !== formData.phone_e164) {
              setFormData(prev => ({ ...prev, phone_e164: withPhone.phone_e164 }));
            }
        }
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    // EDIT: also normalize on blur for better UX
    const handlePhoneBlur = () => {
      const normalized = normalizeSaudiPhone(formData.phone_e164);
      setFormData(prev => ({ ...prev, phone_e164: normalized }));
    };

    const checkDuplicates = async () => {
        setDuplicate(null); // Reset duplicate status before checking
        // Only check if phone_e164 is not empty, otherwise it will incorrectly block valid inputs.
        if (!formData.phone_e164) {
          // If phone is empty, check only by name+DOB, or not at all if phone is primary identifier.
          // For now, if phone is empty, skip phone-based duplicate check.
        } else {
            // Phone uniqueness
            const existing = await Player.filter({ phone_e164: formData.phone_e164 });
            const conflict = existing.find(p => !player || p.id !== player.id);
            if (conflict) {
                setDuplicate({ type: 'phone', player: conflict });
                return conflict;
            }
        }
        
        // Same name + DOB
        if (formData.first_name && formData.last_name && formData.date_of_birth) {
            const nameMatches = await Player.filter({
                first_name: formData.first_name,
                last_name: formData.last_name,
                date_of_birth: format(formData.date_of_birth, 'yyyy-MM-dd')
            });
            const candidate = nameMatches.find(p => !player || p.id !== player.id);
            if (candidate) {
                setDuplicate({ type: 'name_dob', player: candidate });
                return candidate;
            }
        }
        setDuplicate(null);
        return null;
    };

    const linkToExisting = async () => {
        if (!duplicate?.player) return;
        if (!formData.team_id) {
          toast({ variant: "destructive", title: t('playersPage.modal.toast.select_team_to_link') }); // "Select a team to link this player."
          return;
        }
        setIsSaving(true);
        try {
            await TeamPlayer.create({ team_id: formData.team_id, player_id: duplicate.player.id, role: null });
            toast({ title: t('playersPage.modal.toast.linked_to_existing') }); // "Linked to existing player."
            onClose();
        } catch (error) {
            console.error("Error linking player:", error);
            toast({ variant: "destructive", title: t('playersPage.modal.toast.error_title'), description: error.message });
        } finally {
            setIsSaving(false);
        }
    };

    const handleSave = async () => {
        if (!validate()) return;
        
        // Ensure phone is normalized before duplicate check/save, in case validate didn't run or field wasn't blurred
        const normalized = normalizeSaudiPhone(formData.phone_e164);
        if (normalized !== formData.phone_e164) {
          setFormData(prev => ({ ...prev, phone_e164: normalized }));
        }

        const conflict = await checkDuplicates();
        if (conflict) {
          toast({ 
              variant: "destructive", 
              title: t('playersPage.modal.toast.duplicate_title'), // "Duplicate detected"
              description: t('playersPage.modal.toast.duplicate_description') // "This player may already exist. You can link instead."
          });
          return; // Stop saving, allow user to decide to link
        }

        setIsSaving(true);
        let uploadedPhotoUrl = formData.photo_url;

        try {
            if (photoFile) {
                const { file_url } = await UploadFile({ file: photoFile });
                if (!file_url) throw new Error("File upload failed.");
                uploadedPhotoUrl = file_url;
            }

            const age = formData.date_of_birth ? differenceInYears(new Date(), formData.date_of_birth) : null;
            
            const dataToSave = {
                ...formData,
                photo_url: uploadedPhotoUrl,
                date_of_birth: formData.date_of_birth ? format(formData.date_of_birth, 'yyyy-MM-dd') : null,
                age: age,
                height: formData.height ? parseInt(formData.height) : null,
                weight: formData.weight ? parseInt(formData.weight) : null,
                jersey_number: formData.jersey_number ? parseInt(formData.jersey_number) : null
            };
            
            await onSave(dataToSave);
            toast({ title: player ? t('playersPage.modal.toast.update_success') : t('playersPage.modal.toast.create_success') });
            onClose();

        } catch (error) {
            console.error("Error saving player:", error);
            toast({ variant: "destructive", title: t('playersPage.modal.toast.error_title'), description: error.message });
        } finally {
            setIsSaving(false);
        }
    };
    
    const getInputClass = (field) => errors[field] ? "border-red-500" : "border-slate-300";

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-4xl p-0 max-h-[90vh] overflow-y-auto">
                <DialogHeader className="p-6 pb-0">
                    <DialogTitle className="text-2xl font-bold">{player ? t('playersPage.modal.edit_title') : t('playersPage.modal.create_title')}</DialogTitle>
                    <DialogDescription>{t('playersPage.modal.description')}</DialogDescription>
                </DialogHeader>

                <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-8">
                    {/* Left Column */}
                    <div className="md:col-span-2 space-y-6">
                        <h3 className="text-lg font-semibold border-b pb-2">{t('playersPage.modal.player_info')}</h3>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                            <div>
                                <Label htmlFor="first_name">{t('playersPage.modal.first_name')}</Label>
                                <Input id="first_name" value={formData.first_name} onChange={e => setFormData({...formData, first_name: e.target.value})} className={getInputClass('first_name')} />
                                {errors.first_name && <p className="text-red-500 text-xs mt-1">{errors.first_name}</p>}
                            </div>
                            <div>
                                <Label htmlFor="middle_name">{t('playersPage.modal.middle_name')}</Label>
                                <Input id="middle_name" value={formData.middle_name} onChange={e => setFormData({...formData, middle_name: e.target.value})} />
                            </div>
                            <div>
                                <Label htmlFor="last_name">{t('playersPage.modal.last_name')}</Label>
                                <Input id="last_name" value={formData.last_name} onChange={e => setFormData({...formData, last_name: e.target.value})} className={getInputClass('last_name')} />
                                {errors.last_name && <p className="text-red-500 text-xs mt-1">{errors.last_name}</p>}
                            </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                            <div className="sm:col-span-2">
                                <Label htmlFor="phone_e164">{t('playersPage.modal.player_phone_e164')}</Label>
                                <Input
                                  id="phone_e164"
                                  value={formData.phone_e164}
                                  onChange={e => setFormData({...formData, phone_e164: e.target.value})}
                                  onBlur={handlePhoneBlur}
                                  className={getInputClass('phone_e164')}
                                  placeholder="+9665xxxxxxx"
                                />
                                {errors.phone_e164 && <p className="text-red-500 text-xs mt-1">{errors.phone_e164}</p>}
                            </div>
                            <div className="flex items-end">
                              {duplicate && (
                                <Button variant="destructive" type="button" onClick={linkToExisting} className="w-full">
                                  {t('playersPage.modal.link_existing_player_button')}
                                </Button>
                              )}
                            </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <Label htmlFor="jersey_number">{t('playersPage.modal.jersey')}</Label>
                                <Input id="jersey_number" type="number" value={formData.jersey_number} onChange={e => setFormData({...formData, jersey_number: e.target.value})} className={getInputClass('jersey_number')} />
                                {errors.jersey_number && <p className="text-red-500 text-xs mt-1">{errors.jersey_number}</p>}
                            </div>
                            <div>
                              <Label htmlFor="date_of_birth">{t('playersPage.modal.dob')}</Label>
                              <Popover>
                                  <PopoverTrigger asChild>
                                      <Button variant="outline" className={`w-full justify-start font-normal ${!formData.date_of_birth && "text-muted-foreground"} ${getInputClass('date_of_birth')}`}>
                                          <CalendarIcon className="mr-2 h-4 w-4" />
                                          {formData.date_of_birth ? format(formData.date_of_birth, "PPP") : <span>{t('playersPage.modal.pick_date')}</span>}
                                      </Button>
                                  </PopoverTrigger>
                                  <PopoverContent className="w-auto p-0">
                                      <Calendar
                                          mode="single"
                                          captionLayout="dropdown-buttons"
                                          fromYear={1980}
                                          toYear={new Date().getFullYear()}
                                          selected={formData.date_of_birth}
                                          onSelect={date => setFormData({...formData, date_of_birth: date})}
                                          initialFocus
                                      />
                                  </PopoverContent>
                              </Popover>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                            <div>
                                <Label htmlFor="height">{t('playersPage.modal.height')}</Label>
                                <Input id="height" type="number" placeholder="e.g. 180" value={formData.height} onChange={e => setFormData({...formData, height: e.target.value})} />
                            </div>
                            <div>
                                <Label htmlFor="weight">{t('playersPage.modal.weight')}</Label>
                                <Input id="weight" type="number" placeholder="e.g. 75" value={formData.weight} onChange={e => setFormData({...formData, weight: e.target.value})} />
                            </div>
                             <div>
                                <Label htmlFor="preferred_foot">{t('playersPage.modal.pref_foot')}</Label>
                                <Select value={formData.preferred_foot} onValueChange={value => setFormData({...formData, preferred_foot: value})}>
                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="right">{t('playersPage.modal.right')}</SelectItem>
                                        <SelectItem value="left">{t('playersPage.modal.left')}</SelectItem>
                                        <SelectItem value="both">{t('playersPage.modal.both')}</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <Label htmlFor="position">{t('playersPage.modal.position')}</Label>
                                <Select value={formData.position} onValueChange={value => setFormData({...formData, position: value})}>
                                    <SelectTrigger className={getInputClass('position')}><SelectValue placeholder={t('playersPage.modal.select_pos')} /></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="goalkeeper">{t('playersPage.positions.goalkeeper')}</SelectItem>
                                        <SelectItem value="defender">{t('playersPage.positions.defender')}</SelectItem>
                                        <SelectItem value="midfielder">{t('playersPage.positions.midfielder')}</SelectItem>
                                        <SelectItem value="forward">{t('playersPage.positions.forward')}</SelectItem>
                                    </SelectContent>
                                </Select>
                                {errors.position && <p className="text-red-500 text-xs mt-1">{errors.position}</p>}
                            </div>
                            <div>
                                <Label htmlFor="team">{t('playersPage.modal.team')}</Label>
                                <Select value={formData.team_id} onValueChange={value => setFormData({...formData, team_id: value})}>
                                    <SelectTrigger><SelectValue placeholder={t('playersPage.modal.assign_team')} /></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value={null}>{t('playersPage.modal.no_team')}</SelectItem>
                                        {teams?.map(team => (
                                            <SelectItem key={team.id} value={team.id}>{team.name}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        <div>
                            <Label>{t('playersPage.modal.status')}</Label>
                            <RadioGroup value={formData.status} onValueChange={value => setFormData({...formData, status: value})} className="flex items-center gap-4 mt-2">
                                <div className="flex items-center space-x-2"><RadioGroupItem value="active" id="s-active" /><Label htmlFor="s-active">{t('playersPage.statuses.active')}</Label></div>
                                <div className="flex items-center space-x-2"><RadioGroupItem value="inactive" id="s-inactive" /><Label htmlFor="s-inactive">{t('playersPage.statuses.inactive')}</Label></div>
                                <div className="flex items-center space-x-2"><RadioGroupItem value="injured" id="s-injured" /><Label htmlFor="s-injured">{t('playersPage.statuses.injured')}</Label></div>
                            </RadioGroup>
                        </div>
                        
                        <h3 className="text-lg font-semibold border-b pb-2">{t('playersPage.modal.guardian_info')}</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <Label htmlFor="guardian_name">{t('playersPage.modal.guardian_name')}</Label>
                                <Input id="guardian_name" value={formData.guardian_name} onChange={e => setFormData({...formData, guardian_name: e.target.value})} />
                            </div>
                            <div>
                                <Label htmlFor="guardian_phone">{t('playersPage.modal.guardian_phone')}</Label>
                                <Input id="guardian_phone" placeholder="+9665xxxxxxx" value={formData.guardian_phone} onChange={e => setFormData({...formData, guardian_phone: e.target.value})} />
                            </div>
                        </div>

                    </div>

                    {/* Right Column */}
                    <div className="space-y-6">
                         <h3 className="text-lg font-semibold border-b pb-2">{t('playersPage.modal.player_profile')}</h3>
                        
                        <div>
                            <Label>{t('playersPage.modal.photo')}</Label>
                            <div 
                                className={`mt-2 flex justify-center items-center p-4 w-48 h-48 mx-auto rounded-full border-2 border-dashed cursor-pointer ${errors.photo ? 'border-red-500' : 'border-slate-300'}`}
                                onClick={() => fileInputRef.current.click()}
                            >
                                <input type="file" ref={fileInputRef} onChange={handlePhotoChange} accept="image/*" className="hidden" />
                                {photoPreview ? (
                                    <Avatar className="w-full h-full">
                                        <AvatarImage src={photoPreview} alt="Player photo" className="object-cover" />
                                        <AvatarFallback><User /></AvatarFallback>
                                    </Avatar>
                                ) : (
                                    <div className="text-center text-slate-500">
                                        <UploadCloud className="mx-auto h-8 w-8" />
                                        <p className="mt-1 text-sm">{t('playersPage.modal.upload_photo')}</p>
                                    </div>
                                )}
                            </div>
                            {errors.photo && <p className="text-red-500 text-xs mt-1 text-center">{errors.photo}</p>}
                        </div>

                        <div>
                            <Label htmlFor="tags">{t('playersPage.modal.tags')}</Label>
                            <div className="mt-2 flex flex-wrap gap-2">
                              {formData.tags.map(tag => (
                                <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                                  {tag}
                                  <button type="button" onClick={() => removeTag(tag)} className="text-muted-foreground hover:text-foreground">&times;</button>
                                </Badge>
                              ))}
                            </div>
                            <div className="relative">
                              <Input
                                  id="tags"
                                  placeholder={t('playersPage.modal.tags_placeholder')}
                                  value={tagInput}
                                  onChange={handleTagInputChange}
                                  onKeyDown={handleTagKeyDown}
                                  onFocus={() => setShowSuggestions(suggestedTags.length > 0)}
                                  onBlur={() => setTimeout(() => setShowSuggestions(false), 100)} // Delay hiding to allow click
                                  className="mt-2"
                              />
                              {showSuggestions && suggestedTags.length > 0 && (
                                <div className="absolute z-20 mt-1 w-full bg-white border border-slate-200 rounded-md shadow-md max-h-40 overflow-auto">
                                  {suggestedTags.map((tag) => (
                                    <button
                                      type="button"
                                      key={tag}
                                      onClick={() => selectSuggestedTag(tag)}
                                      className="w-full text-left px-3 py-2 hover:bg-slate-50"
                                    >
                                      {tag}
                                    </button>
                                  ))}
                                </div>
                              )}
                            </div>
                        </div>

                        <div>
                            <Label htmlFor="notes">{t('playersPage.modal.notes')}</Label>
                            <Textarea id="notes" placeholder={t('playersPage.modal.notes_placeholder')} value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} className="mt-2" />
                        </div>
                    </div>
                </div>

                <DialogFooter className="p-6 pt-0 flex flex-col sm:flex-row sm:justify-between items-center sm:items-end gap-2">
                    {duplicate && (
                        <div className="flex flex-col items-center sm:items-start text-sm text-red-500">
                            {t('playersPage.modal.duplicate_info', { type: duplicate.type === 'phone' ? t('playersPage.modal.duplicate_type_phone') : t('playersPage.modal.duplicate_type_name_dob') })}
                            <Button variant="link" onClick={linkToExisting} disabled={isSaving} className="p-0 h-auto underline text-red-500 hover:text-red-600">
                                {t('playersPage.modal.link_existing_player')}
                            </Button>
                        </div>
                    )}
                    <div className="flex gap-2">
                        <Button variant="outline" onClick={onClose} disabled={isSaving}>{t('playersPage.modal.cancel')}</Button>
                        <Button onClick={handleSave} disabled={isSaving}>
                            {isSaving ? (player ? t('playersPage.modal.saving') : t('playersPage.modal.creating')) : (player ? t('playersPage.modal.save_changes') : t('playersPage.modal.create_player'))}
                        </Button>
                    </div>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
