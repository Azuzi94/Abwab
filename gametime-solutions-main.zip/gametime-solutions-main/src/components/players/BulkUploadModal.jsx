
import React, { useState } from 'react';
import { Player } from '@/api/entities';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertCircle, CheckCircle, UploadCloud, Loader2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { UploadFile, ExtractDataFromUploadedFile } from '@/api/integrations';
import { useLanguage } from '@/components/providers/LanguageProvider';
import { AuditLog } from '@/api/entities';
import { User } from '@/api/entities';

const REQUIRED_FIELDS = ['first_name', 'last_name', 'jersey_number', 'position'];

const EXTRACTION_SCHEMA = {
  type: "object",
  properties: {
    players: {
      type: "array",
      items: {
        type: "object",
        properties: {
          first_name: { type: "string", description: "Player's first name" },
          last_name: { type: "string", description: "Player's last name" },
          jersey_number: { type: "string", description: "Jersey number as a string, e.g., '7'" },
          position: { type: "string", description: "Primary position, e.g., 'forward', 'defender'" },
          age: { type: "string", description: "Player's age as a string" },
          height: { type: "string", description: "Player's height in cm as a string" },
          weight: { type: "string", description: "Player's weight in kg as a string" },
          photo_url: { type: "string", description: "URL to player's photo" },
          preferred_foot: { type: "string", description: "e.g., 'left', 'right', 'both'" },
          status: { type: "string", description: "e.g., 'active', 'injured'" },
          tags: { type: "string", description: "Comma-separated list of tags, e.g., 'captain,trialist'" }
        },
        required: REQUIRED_FIELDS
      }
    }
  }
};

export default function BulkUploadModal({ isOpen, onClose, onUploadComplete, academyId }) {
  const [step, setStep] = useState(1); // 1: Upload, 2: Preview, 3: Complete
  const [file, setFile] = useState(null);
  const [parsedData, setParsedData] = useState([]);
  const [errors, setErrors] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadError, setUploadError] = useState(null);
  const { t } = useLanguage();

  const handleFileChange = async (event) => {
    const uploadedFile = event.target.files[0];
    if (uploadedFile) {
      // Security: basic validation
      const allowedTypes = ["text/csv", "application/vnd.ms-excel"];
      const MAX_SIZE_BYTES = 5 * 1024 * 1024; // 5MB limit
      if (!allowedTypes.includes(uploadedFile.type) && !uploadedFile.name.toLowerCase().endsWith(".csv")) {
        setUploadError("Please upload a valid CSV file.");
        return;
      }
      if (uploadedFile.size > MAX_SIZE_BYTES) {
        setUploadError("CSV file is too large. Please keep it under 5MB.");
        return;
      }

      setIsProcessing(true);
      setUploadError(null);
      setFile(uploadedFile);
      try {
        const { file_url } = await UploadFile({ file: uploadedFile });
        if (!file_url) {
          throw new Error("File upload failed, please try again.");
        }

        const extractionResult = await ExtractDataFromUploadedFile({
          file_url,
          json_schema: EXTRACTION_SCHEMA
        });

        if (extractionResult.status === 'error' || !extractionResult.output?.players) {
           throw new Error(extractionResult.details || "Could not extract data from the file. Please check the CSV format and column headers.");
        }
        
        const extractedPlayers = extractionResult.output.players;
        const validatedData = validateData(extractedPlayers);
        setParsedData(validatedData.validRows);
        setErrors(validatedData.errors);
        setStep(2);
      } catch (error) {
        setUploadError(error.message);
        setStep(1);
      } finally {
        setIsProcessing(false);
      }
    }
  };

  const validateData = (data) => {
    const validRows = [];
    const errors = [];
    data.forEach((row, index) => {
      let rowIsValid = true;
      const missingFields = REQUIRED_FIELDS.filter(field => !row[field] || String(row[field]).trim() === '');
      if (missingFields.length > 0) {
        errors.push({ index, message: `Row ${index + 2}: Missing required fields: ${missingFields.join(', ')}` });
        rowIsValid = false;
      }
      if (row.jersey_number && isNaN(parseInt(row.jersey_number, 10))) {
        errors.push({ index, message: `Row ${index + 2}: Jersey number must be a number.` });
        rowIsValid = false;
      }

      if (rowIsValid) {
        validRows.push(row);
      }
    });
    return { validRows, errors };
  };

  const handleUpload = async () => {
    setIsProcessing(true);
    try {
        const playersToCreate = parsedData.map(row => ({
            ...row,
            academy_id: academyId,
            age: row.age ? parseInt(row.age, 10) : null,
            jersey_number: row.jersey_number ? parseInt(row.jersey_number, 10) : null,
            height: row.height ? parseInt(row.height, 10) : null,
            weight: row.weight ? parseInt(row.weight, 10) : null,
            tags: row.tags ? String(row.tags).split(',').map(t => t.trim()) : [],
            status: row.status || 'active',
        }));
      
      await Player.bulkCreate(playersToCreate);
      // Security: audit who imported what
      try {
        const user = await User.me();
        await AuditLog.create({
          academy_id: academyId,
          actor_user_id: user.id,
          action: "bulk_import",
          entity: "Player",
          entity_id: null,
          payload_json: { count: playersToCreate.length },
          created_at: new Date().toISOString()
        });
      } catch (e) {
        console.error("Audit log (bulk import) failed:", e);
      }

      setStep(3);
    } catch (error) {
      console.error("Bulk upload failed", error);
      setUploadError("An error occurred during the final import. Please check your data and try again.");
      setStep(2);
    }
    setIsProcessing(false);
  };
  
  const handleDownloadTemplate = () => {
    const headers = [
      "first_name", "last_name", "jersey_number", "position",
      "age", "height", "weight", "photo_url", "preferred_foot",
      "status", "tags"
    ];
    // Example row to guide the user
    const exampleRow = [
      "John", "Doe", "10", "forward", "22", "180", "75",
      "http://example.com/photo.jpg", "right", "active", "trialist,fast"
    ];

    const csvContent = [
      headers.join(','),
      exampleRow.join(',')
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", "player_upload_template.csv");
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };
  
  const resetState = () => {
    setStep(1);
    setFile(null);
    setParsedData([]);
    setErrors([]);
    setUploadError(null);
    onClose();
    onUploadComplete();
  };
  
  const renderStep1 = () => (
    <div>
      {uploadError && (
        <div className="mb-4 p-3 bg-red-50 text-red-700 border border-red-200 rounded-lg flex items-center gap-3">
          <AlertCircle className="w-5 h-5" />
          <div>
            <h4 className="font-bold">{t('playersPage.bulk_upload.error_title')}</h4>
            <p className="text-sm">{uploadError}</p>
          </div>
        </div>
      )}
      <Label 
        htmlFor="csv-upload" 
        className="mt-4 p-12 border-2 border-dashed rounded-lg text-center cursor-pointer block border-slate-300 hover:border-blue-500 hover:bg-blue-50"
      >
        {isProcessing ? (
          <div className="flex flex-col items-center gap-2 text-slate-500">
            <Loader2 className="w-8 h-8 animate-spin" />
            <span>{t('playersPage.bulk_upload.processing')}</span>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2 text-slate-500">
            <UploadCloud className="w-8 h-8" />
            <span>{t('playersPage.bulk_upload.dropzone_text')}</span>
          </div>
        )}
        <Input id="csv-upload" type="file" accept=".csv" onChange={handleFileChange} className="hidden" disabled={isProcessing} />
      </Label>
      <Button
        type="button"
        variant="link"
        onClick={handleDownloadTemplate}
        className="p-0 h-auto text-sm text-blue-600 hover:underline mt-4"
      >
        {t('playersPage.bulk_upload.download_template')}
      </Button>
    </div>
  );

  const renderStep2 = () => (
    <div>
      <h3 className="text-lg font-semibold">{t('playersPage.bulk_upload.preview_title')}</h3>
      <p className="text-slate-500 mb-4">{t('playersPage.bulk_upload.preview_desc', { count: parsedData.length, errors: errors.length })}</p>
      
      {errors.length > 0 && (
        <div className="mb-4 max-h-32 overflow-y-auto p-3 bg-red-50 text-red-700 border border-red-200 rounded-lg">
          <h4 className="font-bold mb-2">{t('playersPage.bulk_upload.errors_found')}</h4>
          <ul className="text-sm list-disc ps-5 space-y-1">
            {errors.slice(0, 5).map(err => <li key={err.index}>{err.message}</li>)}
          </ul>
          {errors.length > 5 && <p className="text-sm mt-2">{t('playersPage.bulk_upload.more_errors', { count: errors.length - 5 })}</p>}
        </div>
      )}

      <div className="max-h-64 overflow-y-auto border rounded-lg">
        <Table>
          <TableHeader className="sticky top-0 bg-slate-50">
            <TableRow>
              {REQUIRED_FIELDS.map(field => <TableHead key={field}>{field.replace('_', ' ')}</TableHead>)}
            </TableRow>
          </TableHeader>
          <TableBody>
            {parsedData.slice(0, 10).map((row, index) => (
              <TableRow key={index}>
                {Object.values(row).map((val, j) => <TableCell key={j}>{String(val)}</TableCell>)}
              </TableRow>
            ))}
          </TableBody>
        </Table>
        {parsedData.length > 10 && <div className="p-2 text-center text-sm text-slate-500 bg-slate-50">...and {parsedData.length - 10} more rows</div>}
      </div>

      <DialogFooter className="mt-6">
        <Button variant="outline" onClick={() => setStep(1)} disabled={isProcessing}>{t('playersPage.bulk_upload.back')}</Button>
        <Button onClick={handleUpload} disabled={isProcessing || parsedData.length === 0}>
          {isProcessing ? (
            <><Loader2 className="me-2 w-4 h-4 animate-spin" />{t('playersPage.bulk_upload.importing')}</>
          ) : (
            t('playersPage.bulk_upload.import_button', { count: parsedData.length })
          )}
        </Button>
      </DialogFooter>
    </div>
  );

  const renderStep3 = () => (
    <div className="text-center p-8">
      <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
      <h3 className="text-2xl font-bold">{t('playersPage.bulk_upload.complete_title')}</h3>
      <p className="text-slate-500 mt-2">{t('playersPage.bulk_upload.complete_desc', { count: parsedData.length })}</p>
      <DialogFooter className="mt-8 justify-center">
        <Button onClick={resetState}>{t('playersPage.bulk_upload.done')}</Button>
      </DialogFooter>
    </div>
  );

  const renderContent = () => {
    switch(step) {
      case 1: return renderStep1();
      case 2: return renderStep2();
      case 3: return renderStep3();
      default: return null;
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={!isProcessing ? onClose : undefined}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{t('playersPage.bulk_upload.title')}</DialogTitle>
        </DialogHeader>
        {renderContent()}
        <DialogFooter>
          {step === 1 && <Button variant="outline" onClick={onClose} disabled={isProcessing}>Cancel</Button>}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
