import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { User, Calendar, Ruler, Weight, MapPin, Activity, Edit, Shirt } from "lucide-react";
import { useLanguage } from "@/components/providers/LanguageProvider";

export default function PlayerProfileModal({ isOpen, onClose, player, onEdit }) {
  const { t } = useLanguage();

  if (!player) return null;

  const getPositionColor = (position) => {
    switch (position) {
      case 'goalkeeper':return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'defender':return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'midfielder':return 'bg-green-100 text-green-800 border-green-200';
      case 'forward':return 'bg-red-100 text-red-800 border-red-200';
      default:return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active':return 'bg-green-100 text-green-800';
      case 'inactive':return 'bg-gray-100 text-gray-800';
      case 'injured':return 'bg-orange-100 text-orange-800';
      case 'suspended':return 'bg-red-100 text-red-800';
      default:return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto p-0">
        <DialogHeader className="p-6">
          <DialogTitle className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <User className="w-5 h-5" />
              {t('playersPage.profile.title')}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                onClose();
                onEdit(player);
              }} className="bg-background mx-6 px-5 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border border-input hover:bg-accent hover:text-accent-foreground h-9 rounded-md">

              <Edit className="w-4 h-4 me-2" />
              {t('playersPage.actions.edit')}
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 p-6 pt-0">
          {/* Header Section */}
          <div className="flex items-start gap-6 p-6 bg-slate-50 rounded-lg">
            <div className="relative">
              <Avatar className="w-24 h-24 ring-4 ring-white shadow-lg">
                <AvatarImage src={player.photo_url} />
                <AvatarFallback className="bg-gradient-to-r from-blue-500 to-cyan-400 text-white text-2xl font-bold">
                  {player.first_name?.[0]}{player.last_name?.[0]}
                </AvatarFallback>
              </Avatar>
              <div className="absolute -top-2 -right-2 w-8 h-8 bg-slate-900 text-white rounded-lg flex items-center justify-center text-sm font-bold shadow-md">
                {player.jersey_number}
              </div>
            </div>
            
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-slate-900 mb-2">
                {player.first_name} {player.last_name}
              </h2>
              <div className="flex items-center gap-3 mb-3">
                <Badge className={`${getPositionColor(player.position)} border`}>
                  <Shirt className="w-3 h-3 me-1" />
                  {t(`playersPage.positions.${player.position}`)}
                </Badge>
                <Badge className={getStatusColor(player.status)}>
                  <Activity className="w-3 h-3 me-1" />
                  {t(`playersPage.statuses.${player.status}`)}
                </Badge>
              </div>
              {player.tags && player.tags.length > 0 &&
              <div className="flex flex-wrap gap-2">
                  {player.tags.map((tag) =>
                <Badge key={tag} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                )}
                </div>
              }
            </div>
          </div>

          {/* Basic Information */}
          <Card>
            <CardHeader><CardTitle className="text-lg">{t('playersPage.profile.basic_info')}</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {player.age &&
                <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-slate-400" />
                    <div>
                      <div className="text-sm text-slate-500">{t('playersPage.modal.age')}</div>
                      <div className="font-semibold">{t('playersPage.profile.age_years', { age: player.age })}</div>
                    </div>
                  </div>
                }
                {player.height &&
                <div className="flex items-center gap-2">
                    <Ruler className="w-4 h-4 text-slate-400" />
                    <div>
                      <div className="text-sm text-slate-500">{t('playersPage.modal.height')}</div>
                      <div className="font-semibold">{t('playersPage.profile.height_cm', { height: player.height })}</div>
                    </div>
                  </div>
                }
                {player.weight &&
                <div className="flex items-center gap-2">
                    <Weight className="w-4 h-4 text-slate-400" />
                    <div>
                      <div className="text-sm text-slate-500">{t('playersPage.modal.weight')}</div>
                      <div className="font-semibold">{t('playersPage.profile.weight_kg', { weight: player.weight })}</div>
                    </div>
                  </div>
                }
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-slate-400" />
                  <div>
                    <div className="text-sm text-slate-500">{t('playersPage.modal.pref_foot')}</div>
                    <div className="font-semibold capitalize">{t(`playersPage.modal.${player.preferred_foot || 'right'}`)}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Performance Stats Placeholder */}
          <Card>
            <CardHeader><CardTitle className="text-lg">{t('playersPage.profile.recent_perf')}</CardTitle></CardHeader>
            <CardContent>
              <div className="text-center py-8 text-slate-500">
                <Activity className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                <p>{t('playersPage.profile.perf_placeholder')}</p>
              </div>
            </CardContent>
          </Card>

          {/* Match History Placeholder */}
          <Card>
            <CardHeader><CardTitle className="text-lg">{t('playersPage.profile.match_history')}</CardTitle></CardHeader>
            <CardContent>
              <div className="text-center py-8 text-slate-500">
                <Calendar className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                <p>{t('playersPage.profile.history_placeholder')}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>);

}