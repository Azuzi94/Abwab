
import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, User, Pencil, Trash, UserX } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useLanguage } from '@/components/providers/LanguageProvider';

export default function PlayerTable({ 
  players, 
  onEdit, // Renamed from onEditPlayer
  onViewProfile,
  onDelete, // New prop for delete action
  selectedRows, // Renamed from selectedPlayers
  onSelect // Renamed from setSelectedPlayers, now acts as the setter for selectedRows
}) {
  const { t } = useLanguage();

  const handleSelectAll = (checked) => {
    if (checked) {
      onSelect(players.map(p => p.id));
    } else {
      onSelect([]);
    }
  };

  const handleSelectOne = (id, checked) => {
    if (checked) {
      onSelect([...selectedRows, id]);
    } else {
      onSelect(selectedRows.filter(pid => pid !== id));
    }
  };

  // Helper function to get status-specific CSS classes
  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return "bg-green-100 text-green-800";
      case 'inactive': return "border border-input bg-background text-foreground"; // Mimics variant="outline"
      case 'injured': return "bg-orange-100 text-orange-800";
      case 'suspended': return "bg-red-100 text-red-800";
      default: return "bg-secondary text-secondary-foreground"; // Mimics variant="secondary"
    }
  };

  if (players.length === 0) {
    return (
      <div className="text-center py-20 bg-white rounded-lg shadow-sm border border-slate-200">
        <UserX className="w-16 h-16 mx-auto text-slate-300" />
        <h3 className="mt-4 text-xl font-semibold text-slate-700">{t('playersPage.grid.no_players_title')}</h3>
        <p className="mt-2 text-slate-500">{t('playersPage.grid.no_players_desc')}</p>
      </div>
    );
  }
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200">
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-slate-50/50">
            <TableHead className="w-[50px]">
              <Checkbox
                checked={selectedRows.length === players.length && players.length > 0}
                onCheckedChange={handleSelectAll}
              />
            </TableHead>
            <TableHead>{t('playersPage.table.name')}</TableHead>
            <TableHead className="w-[100px]">{t('playersPage.table.jersey')}</TableHead>
            <TableHead>{t('playersPage.table.position')}</TableHead>
            <TableHead>{t('playersPage.table.age')}</TableHead>
            <TableHead>{t('playersPage.table.status')}</TableHead>
            <TableHead>{t('playersPage.table.tags')}</TableHead>
            <TableHead className="w-[50px] text-right">{t('playersPage.table.actions')}</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {players.map(player => (
            <TableRow key={player.id} className="hover:bg-slate-50/50 transition-colors">
              <TableCell>
                <Checkbox
                  checked={selectedRows.includes(player.id)}
                  onCheckedChange={(checked) => handleSelectOne(player.id, checked)}
                />
              </TableCell>
              <TableCell>
                <div 
                  className="flex items-center gap-3 cursor-pointer hover:text-blue-600 transition-colors"
                  onClick={() => onViewProfile(player)}
                >
                  <Avatar>
                    <AvatarImage src={player.photo_url} />
                    <AvatarFallback>{player.first_name[0]}{player.last_name[0]}</AvatarFallback>
                  </Avatar>
                  <span className="font-medium">{player.first_name} {player.last_name}</span>
                </div>
              </TableCell>
              <TableCell>#{player.jersey_number}</TableCell>
              <TableCell>{t(`playersPage.positions.${player.position}`)}</TableCell>
              <TableCell>{player.age}</TableCell>
              <TableCell>
                <Badge className={getStatusColor(player.status)}>
                  {t(`playersPage.statuses.${player.status}`)}
                </Badge>
              </TableCell>
              <TableCell>
                <div className="flex flex-wrap gap-1">
                  {player.tags?.slice(0, 2).map(tag => (
                    <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
                  ))}
                  {player.tags?.length > 2 && (
                    <Badge variant="outline" className="text-xs">+{player.tags.length - 2}</Badge>
                  )}
                </div>
              </TableCell>
              <TableCell className="text-right">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="hover:bg-slate-100 transition-colors">
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-white border border-slate-200 shadow-lg">
                    <DropdownMenuItem onClick={() => onViewProfile(player)} className="hover:bg-slate-50 transition-colors">
                      <User className="w-4 h-4 mr-2" />
                      {t('playersPage.actions.view_profile')}
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onEdit(player)} className="hover:bg-slate-50 transition-colors">
                      <Pencil className="w-4 h-4 mr-2" />
                      {t('playersPage.actions.edit')}
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => onDelete(player)} className="text-red-500 hover:bg-red-50 transition-colors">
                      <Trash className="w-4 h-4 mr-2" />
                      {t('playersPage.actions.delete')}
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
