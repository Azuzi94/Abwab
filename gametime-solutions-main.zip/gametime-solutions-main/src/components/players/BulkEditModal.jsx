
import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter, // Added DialogFooter import
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Users, Tag } from "lucide-react";
import { useLanguage } from '@/components/providers/LanguageProvider'; // Added useLanguage import

export default function BulkEditModal({ isOpen, onClose, onSave, selectedPlayers, players }) {
  const [formData, setFormData] = useState({
    status: "",
    preferred_foot: "",
    tags: [],
    addTags: [],
    removeTags: []
  });
  const [fieldsToUpdate, setFieldsToUpdate] = useState({
    status: false,
    preferred_foot: false,
    tags: false
  });
  const [isSaving, setIsSaving] = useState(false);
  const [currentTag, setCurrentTag] = useState("");
  const { t } = useLanguage(); // Initialize useLanguage hook

  const selectedPlayerData = players.filter(p => selectedPlayers.includes(p.id));
  
  useEffect(() => {
    if (isOpen) {
      // Reset form when modal opens
      setFormData({
        status: "",
        preferred_foot: "",
        tags: [],
        addTags: [],
        removeTags: []
      });
      setFieldsToUpdate({
        status: false,
        preferred_foot: false,
        tags: false
      });
    }
  }, [isOpen]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    
    try {
      const updates = {};
      
      if (fieldsToUpdate.status && formData.status) {
        updates.status = formData.status;
      }
      
      if (fieldsToUpdate.preferred_foot && formData.preferred_foot) {
        updates.preferred_foot = formData.preferred_foot;
      }
      
      if (fieldsToUpdate.tags) {
        updates.addTags = formData.addTags;
        updates.removeTags = formData.removeTags;
      }
      
      await onSave(selectedPlayers, updates);
    } catch (error) {
      console.error("Error in bulk edit:", error);
    }
    
    setIsSaving(false);
  };

  const handleFieldToggle = (field) => {
    setFieldsToUpdate(prev => ({ ...prev, [field]: !prev[field] }));
  };

  const handleAddTag = () => {
    if (currentTag && !formData.addTags.includes(currentTag)) {
      setFormData(prev => ({ 
        ...prev, 
        addTags: [...prev.addTags, currentTag] 
      }));
      setCurrentTag("");
    }
  };

  const handleRemoveAddTag = (tagToRemove) => {
    setFormData(prev => ({ 
      ...prev, 
      addTags: prev.addTags.filter(tag => tag !== tagToRemove) 
    }));
  };

  const handleToggleRemoveTag = (tag) => {
    setFormData(prev => {
      const isRemoving = prev.removeTags.includes(tag);
      return {
        ...prev,
        removeTags: isRemoving 
          ? prev.removeTags.filter(t => t !== tag)
          : [...prev.removeTags, tag]
      };
    });
  };

  // Get all unique tags from selected players
  const allTagsFromSelected = [...new Set(
    selectedPlayerData.flatMap(p => p.tags || [])
  )];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            {t('playersPage.bulk_edit.title_selected', { count: selectedPlayers.length })}
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Status Update */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="update-status"
                checked={fieldsToUpdate.status}
                onCheckedChange={() => handleFieldToggle('status')}
              />
              <Label htmlFor="update-status" className="font-medium">{t('playersPage.bulk_edit.update_status')}</Label>
            </div>
            {fieldsToUpdate.status && (
              <Select
                value={formData.status}
                onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder={t('playersPage.bulk_edit.select_status')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">{t('playersPage.statuses.active')}</SelectItem>
                  <SelectItem value="inactive">{t('playersPage.statuses.inactive')}</SelectItem>
                  <SelectItem value="injured">{t('playersPage.statuses.injured')}</SelectItem>
                  <SelectItem value="suspended">{t('playersPage.statuses.suspended')}</SelectItem>
                </SelectContent>
              </Select>
            )}
          </div>

          {/* Preferred Foot Update */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="update-foot"
                checked={fieldsToUpdate.preferred_foot}
                onCheckedChange={() => handleFieldToggle('preferred_foot')}
              />
              <Label htmlFor="update-foot" className="font-medium">{t('playersPage.bulk_edit.update_foot')}</Label>
            </div>
            {fieldsToUpdate.preferred_foot && (
              <Select
                value={formData.preferred_foot}
                onValueChange={(value) => setFormData(prev => ({ ...prev, preferred_foot: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder={t('playersPage.bulk_edit.select_foot')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="right">{t('playersPage.modal.right')}</SelectItem>
                  <SelectItem value="left">{t('playersPage.modal.left')}</SelectItem>
                  <SelectItem value="both">{t('playersPage.modal.both')}</SelectItem>
                </SelectContent>
              </Select>
            )}
          </div>

          {/* Tags Update */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="update-tags"
                checked={fieldsToUpdate.tags}
                onCheckedChange={() => handleFieldToggle('tags')}
              />
              <Label htmlFor="update-tags" className="font-medium">{t('playersPage.bulk_edit.update_tags')}</Label>
            </div>
            {fieldsToUpdate.tags && (
              <div className="space-y-4">
                {/* Add Tags */}
                <div>
                  <Label className="text-sm font-medium mb-2 block">{t('playersPage.bulk_edit.add_tags')}</Label>
                  <div className="flex"> {/* Original had gap-2 here, outline changed to just flex */}
                    <Input
                      value={currentTag}
                      onChange={(e) => setCurrentTag(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
                      placeholder={t('playersPage.modal.add_tag_placeholder')}
                      className="flex-1" // Preserve flex-1 from original
                    />
                    <Button type="button" size="icon" className="ms-2" onClick={handleAddTag}> {/* Changed from text button to icon button */}
                      <Tag className="w-4 h-4"/>
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2"> {/* Original had gap-2 here, outline changed to gap-1 */}
                    {formData.addTags.map(tag => (
                      <Badge key={tag} variant="secondary" className="bg-green-100 text-green-800">
                        {tag}
                        <button 
                          type="button" 
                          onClick={() => handleRemoveAddTag(tag)} 
                          className="ms-1 font-bold" // Changed from ml-1 hover:text-green-600 to ms-1 and text from '×' to 'x'
                        >
                          x
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Remove Tags */}
                {allTagsFromSelected.length > 0 && (
                  <div>
                    <Label className="text-sm font-medium mb-2 block">{t('playersPage.bulk_edit.remove_tags')}</Label>
                    <div className="flex flex-wrap gap-2">
                      {allTagsFromSelected.map(tag => (
                        <Badge 
                          key={tag} 
                          variant={formData.removeTags.includes(tag) ? 'destructive' : 'secondary'} // Changed variant logic
                          className="cursor-pointer" // Simplified classname
                          onClick={() => handleToggleRemoveTag(tag)}
                        >
                          {tag}
                          {/* Removed the 'x' span from here based on outline */}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Actions */}
          <DialogFooter> {/* Changed from div to DialogFooter */}
            <Button type="button" variant="outline" onClick={onClose}>
              {t('playersPage.modal.cancel')}
            </Button>
            <Button 
              type="submit" 
              disabled={isSaving || !Object.values(fieldsToUpdate).some(Boolean)}
              // className="bg-blue-600 hover:bg-blue-700" // Removed classname based on outline
            >
              {isSaving ? t('playersPage.bulk_edit.updating') : t('playersPage.bulk_edit.update_button', { count: selectedPlayers.length })}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
