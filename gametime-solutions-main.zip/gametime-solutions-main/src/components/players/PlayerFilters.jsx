import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Filter, Search, Tag } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useLanguage } from '@/components/providers/LanguageProvider';

export default function PlayerFilters({ filters, onFilterChange, allTags }) {
  const [selectedTags, setSelectedTags] = useState(filters.tags || []);
  const { t } = useLanguage();

  const handleTagToggle = (tag) => {
    const newTags = selectedTags.includes(tag)
      ? selectedTags.filter(t => t !== tag)
      : [...selectedTags, tag];
    setSelectedTags(newTags);
    onFilterChange({ ...filters, tags: newTags });
  };

  const ageGroups = ["U10", "U12", "U14", "U16", "U18", "Senior"];

  return (
    <div className="bg-white p-4 rounded-lg shadow space-y-6">
      <div>
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Filter className="w-5 h-5" />{t('playersPage.filters.title')}
        </h3>
      </div>
      
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input
          placeholder={t('playersPage.filters.search_placeholder')}
          value={filters.search || ''}
          onChange={(e) => onFilterChange({ ...filters, search: e.target.value })}
          className="ps-10"
        />
      </div>
      
      <div className="space-y-2">
        <Label className="text-sm font-medium">{t('playersPage.filters.position')}</Label>
        <Select value={filters.position || 'all'} onValueChange={(value) => onFilterChange({ ...filters, position: value })}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('playersPage.filters.all_positions')}</SelectItem>
            <SelectItem value="goalkeeper">{t('playersPage.positions.goalkeeper')}</SelectItem>
            <SelectItem value="defender">{t('playersPage.positions.defender')}</SelectItem>
            <SelectItem value="midfielder">{t('playersPage.positions.midfielder')}</SelectItem>
            <SelectItem value="forward">{t('playersPage.positions.forward')}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label className="text-sm font-medium">{t('playersPage.filters.status')}</Label>
        <Select value={filters.status || 'all'} onValueChange={(value) => onFilterChange({ ...filters, status: value })}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('playersPage.filters.all_status')}</SelectItem>
            <SelectItem value="active">{t('playersPage.statuses.active')}</SelectItem>
            <SelectItem value="inactive">{t('playersPage.statuses.inactive')}</SelectItem>
            <SelectItem value="injured">{t('playersPage.statuses.injured')}</SelectItem>
            <SelectItem value="suspended">{t('playersPage.statuses.suspended')}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label className="text-sm font-medium">{t('playersPage.filters.age_group')}</Label>
        <Select value={filters.ageGroup || 'all'} onValueChange={(value) => onFilterChange({ ...filters, ageGroup: value })}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('playersPage.filters.all_age_groups')}</SelectItem>
            {ageGroups.map(group => (
              <SelectItem key={group} value={group}>{group}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {allTags.length > 0 && (
        <div className="space-y-2">
          <Label className="text-sm font-medium flex items-center gap-1"><Tag className="w-3 h-3"/> {t('playersPage.filters.tags')}</Label>
          <div className="flex flex-wrap gap-2">
            {allTags.map(tag => (
              <Badge
                key={tag}
                variant={selectedTags.includes(tag) ? 'default' : 'outline'}
                onClick={() => handleTagToggle(tag)}
                className="cursor-pointer"
              >
                {tag}
              </Badge>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}