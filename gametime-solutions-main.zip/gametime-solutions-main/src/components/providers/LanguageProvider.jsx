
import React, { createContext, useState, useContext, useEffect } from 'react';

const en = {
  "nav": {
    "dashboard": "Dashboard", "dashboard_desc": "Overview & insights",
    "players": "Players", "players_desc": "Manage roster",
    "teams": "Teams", "teams_desc": "Create training teams",
    "matches": "Matches", "matches_desc": "Schedule & record",
    "analytics": "Analytics", "analytics_desc": "Performance data",
    "highlights": "Highlights", "highlights_desc": "Video clips",
    "fields": "Fields",
    "fields_desc": "Fields & cameras",
    "coaches": "Coaches",
    "coaches_desc": "Manage coaches and staff"
  },
  "user": {
    "coach": "Coach", "logout": "Logout", "language": "Language"
  },
  "header": {
    "title": "Abwab", "subtitle": "Football Analytics"
  },
  "playersPage": {
    "title": "Players", "description": "Manage your complete academy roster.",
    "toolbar": {
      "add": "Add Player", "bulk_upload": "Bulk Upload", "export": "Export CSV",
      "bulk_edit": "Bulk Edit", "delete": "Delete", "selected": "{{count}} selected"
    },
    "filters": {
      "title": "Filters", "search_placeholder": "Search by name or #",
      "position": "Position", "all_positions": "All Positions",
      "status": "Status", "all_status": "All Status",
      "age_group": "Age Group", "all_age_groups": "All Age Groups", "tags": "Tags"
    },
    "grid": {
      "no_players_title": "No players found",
      "no_players_desc": "Try adjusting your filters or adding a new player.",
      "age": "Age: {{age}}"
    },
    "table": {
      "name": "Name", "jersey": "Jersey", "position": "Position", "age": "Age",
      "status": "Status",
      "tags": "Tags",
      "actions": "Actions"
    },
    "actions": { "view_profile": "View Profile", "edit": "Edit", "delete": "Delete" },
    "positions": { "goalkeeper": "Goalkeeper", "defender": "Defender", "midfielder": "Midfielder", "forward": "Forward" },
    "statuses": { "active": "Active", "inactive": "Inactive", "injured": "Injured", "suspended": "Suspended" },
    "modal": {
      "add_title": "Add New Player", "edit_title": "Edit Player",
      "create_title": "Add New Player",
      "description": "Fill in the player's information.",
      "first_name": "First Name", "last_name": "Last Name",
      "player_info": "Player Information",
      "player_profile": "Player Profile",
      "middle_name": "Middle Name",
      "jersey": "Jersey Number", "position": "Position", "select_position": "Select position",
      "select_pos": "Select position", // Added
      "age": "Age", "height": "Height (cm)", "weight": "Weight (kg)", "status": "Status",
      "pref_foot": "Preferred Foot", "right": "Right", "left": "Left", "both": "Both",
      "player_phone_e164": "Player Phone (E.164)",
      "dob": "Date of Birth",
      "pick_date": "Pick a date",
      "team": "Team",
      "assign_team": "Assign to team",
      "no_team": "No team",
      "photo": "Photo",
      "upload_photo": "Upload a photo",
      "tags": "Tags", "add_tag_placeholder": "Add a tag and press Enter", "add": "Add",
      "tags_placeholder": "Add tags and press Enter",
      "notes": "Notes",
      "notes_placeholder": "Additional notes...",
      "photo_url": "Photo URL",
      "guardian_info": "Guardian Information", // Added
      "guardian_name": "Guardian Name",       // Added
      "guardian_phone": "Guardian Phone",     // Added
      "cancel": "Cancel", "saving": "Saving...",
      // toasts
      "toast": {
        "select_team_to_link": "Select a team to link this player.",
        "linked_to_existing": "Linked to existing player.",
        "error_title": "Something went wrong",
        "duplicate_title": "Duplicate detected",
        "duplicate_description": "This player may already exist. You can link instead.",
        "update_success": "Player updated successfully.",
        "create_success": "Player created successfully."
      },
      // action labels
      "creating": "Creating...",
      "save": "Save Player",
      "save_changes": "Save Changes",
      "create_player": "Create Player",
      // errors
      "errors": {
        "first_name_req": "First name is required.",
        "last_name_req": "Last name is required.",
        "position_req": "Position is required.",
        "photo_req": "Photo is required.",
        "phone_e164_invalid": "Valid E.164 phone is required (e.g., +966512345678)."
      }
    },
    "bulk_upload": {
      "title": "Bulk Upload Players", "error_title": "Upload Error:",
      "processing": "Processing file...", "dropzone_text": "Drag & drop a CSV file here, or click to select a file.",
      "download_template": "Download CSV Template", "preview_title": "Upload Preview",
      "preview_desc": "Found {{count}} valid players to import. {{errors}} rows have errors and will be skipped.",
      "errors_found": "Errors Found:", "more_errors": "...and {{count}} more.", "back": "Back",
      "import_button": "Import {{count}} Players", "importing": "Importing...",
      "complete_title": "Upload Complete!", "complete_desc": "{{count}} players have been successfully added to your roster.",
      "done": "Done"
    },
    "bulk_edit": {
      "title": "Bulk Edit Players", "title_selected": "Bulk Edit Players ({{count}} selected)",
      "update_status": "Update Status", "select_status": "Select new status",
      "update_foot": "Update Preferred Foot", "select_foot": "Select preferred foot",
      "update_tags": "Update Tags", "add_tags": "Add Tags", "remove_tags": "Remove Tags",
      "updating": "Updating...", "update_button": "Update {{count}} Players"
    },
    "profile": {
      "title": "Player Profile", "age_years": "{{age}} years", "height_cm": "{{height}} cm",
      "weight_kg": "{{weight}} kg", "basic_info": "Basic Information",
      "recent_perf": "Recent Performance", "perf_placeholder": "Performance data will be available after match recordings.",
      "match_history": "Match History", "history_placeholder": "Match history will appear here once matches are completed."
    },
    "delete_confirm": "Are you sure you want to delete this player?",
    "bulk_delete_confirm": "Are you sure you want to delete {{count}} selected players?"
  }
};

const ar = {
  "nav": {
    "dashboard": "لوحة التحكم", "dashboard_desc": "نظرة عامة وإحصائيات",
    "players": "اللاعبون", "players_desc": "إدارة القائمة",
    "teams": "الفِرق", "teams_desc": "إنشاء فِرق تدريب",
    "matches": "المباريات", "matches_desc": "جدولة وتسجيل",
    "analytics": "التحليلات", "analytics_desc": "بيانات الأداء",
    "highlights": "أبرز اللقطات", "highlights_desc": "مقاطع فيديو",
    "fields": "الملاعب",
    "fields_desc": "الملاعب والكاميرات",
    "coaches": "المدربون",
    "coaches_desc": "إدارة المدربين والطاقم"
  },
  "user": {
    "coach": "مدرب", "logout": "تسجيل الخروج", "language": "اللغة"
  },
  "header": {
    "title": "أبواب", "subtitle": "تحليلات كرة القدم"
  },
  "playersPage": {
    "title": "اللاعبون", "description": "إدارة القائمة الكاملة للاعبين في أكاديميتك.",
    "toolbar": {
      "add": "إضافة لاعب", "bulk_upload": "رفع جماعي", "export": "تصدير CSV",
      "bulk_edit": "تعديل جماعي", "delete": "حذف", "selected": "تم تحديد {{count}}"
    },
    "filters": {
      "title": "عوامل التصفية", "search_placeholder": "ابحث بالاسم أو الرقم",
      "position": "المركز", "all_positions": "كل المراكز",
      "status": "الحالة", "all_status": "كل الحالات",
      "age_group": "الفئة العمرية", "all_age_groups": "كل الفئات العمرية", "tags": "الوسوم"
    },
    "grid": {
      "no_players_title": "لم يتم العثور على لاعبين",
      "no_players_desc": "حاول تعديل عوامل التصفية أو إضافة لاعب جديد.",
      "age": "العمر: {{age}}"
    },
    "table": {
      "name": "الاسم", "jersey": "القميص", "position": "المركز", "age": "العمر",
      "status": "الحالة",
      "tags": "الوسوم",
      "actions": "الإجراءات"
    },
    "actions": { "view_profile": "عرض الملف الشخصي", "edit": "تعديل", "delete": "حذف" },
    "positions": { "goalkeeper": "حارس مرمى", "defender": "مدافع", "midfielder": "لاعب وسط", "forward": "مهاجم" },
    "statuses": { "active": "نشط", "inactive": "غير نشط", "injured": "مصاب", "suspended": "موقوف" },
    "modal": {
      "add_title": "إضافة لاعب جديد", "edit_title": "تعديل اللاعب",
      "create_title": "إضافة لاعب جديد",
      "description": "أدخل معلومات اللاعب.",
      "first_name": "الاسم الأول", "last_name": "اسم العائلة",
      "player_info": "معلومات اللاعب",
      "player_profile": "الملف الشخصي للاعب",
      "middle_name": "الاسم الأوسط",
      "jersey": "رقم القميص", "position": "المركز", "select_position": "اختر المركز",
      "select_pos": "اختر المركز", // Added
      "age": "العمر", "height": "الطول (سم)", "weight": "الوزن (كجم)", "status": "الحالة",
      "pref_foot": "القدم المفضلة", "right": "يمنى", "left": "يسرى", "both": "كلتاهما",
      "player_phone_e164": "هاتف اللاعب (E.164)",
      "dob": "تاريخ الميلاد",
      "pick_date": "اختر التاريخ",
      "team": "الفريق",
      "assign_team": "إسناد إلى فريق",
      "no_team": "بدون فريق",
      "photo": "الصورة",
      "upload_photo": "رفع صورة",
      "tags": "الوسوم", "add_tag_placeholder": "أضف وسمًا واضغط على Enter", "add": "إضافة",
      "tags_placeholder": "أضف وسوماً واضغط Enter",
      "notes": "ملاحظات",
      "notes_placeholder": "ملاحظات إضافية...",
      "photo_url": "رابط الصورة",
      "guardian_info": "بيانات ولي الأمر", // Added
      "guardian_name": "اسم ولي الأمر",   // Added
      "guardian_phone": "هاتف ولي الأمر", // Added
      "cancel": "إلغاء", "saving": "جارٍ الحفظ...",
      "toast": {
        "select_team_to_link": "يرجى اختيار فريق لربط هذا اللاعب.",
        "linked_to_existing": "تم الربط بلاعب موجود.",
        "error_title": "حدث خطأ ما",
        "duplicate_title": "تم اكتشاف تكرار",
        "duplicate_description": "قد يكون هذا اللاعب موجودًا بالفعل. يمكنك الربط بدلًا من ذلك.",
        "update_success": "تم تحديث اللاعب بنجاح.",
        "create_success": "تم إنشاء اللاعب بنجاح."
      },
      "creating": "جارٍ الإنشاء...",
      "save": "حفظ اللاعب",
      "save_changes": "حفظ التغييرات",
      "create_player": "إنشاء اللاعب",
      "errors": {
        "first_name_req": "الاسم الأول مطلوب.",
        "last_name_req": "اسم العائلة مطلوب.",
        "position_req": "المركز مطلوب.",
        "photo_req": "الصورة مطلوبة.",
        "phone_e164_invalid": "مطلوب رقم هاتف بصيغة E.164 (مثال: ‎+9665xxxxxxx)."
      }
    },
    "bulk_upload": {
      "title": "رفع جماعي للاعبين", "error_title": "خطأ في الرفع:",
      "processing": "جارٍ معالجة الملف...", "dropzone_text": "اسحب وأفلت ملف CSV هنا، أو انقر لتحديد ملف.",
      "download_template": "تنزيل قالب CSV", "preview_title": "معاينة الرفع",
      "preview_desc": "تم العثور على {{count}} لاعب صالح للاستيراد. {{errors}} صفوف بها أخطاء سيتم تخطيها.",
      "errors_found": "تم العثور على أخطاء:", "more_errors": "...و {{count}} أخرى.", "back": "رجوع",
      "import_button": "استيراد {{count}} لاعب", "importing": "جارٍ الاستيراد...",
      "complete_title": "اكتمل الرفع!", "complete_desc": "تمت إضافة {{count}} لاعب بنجاح إلى قائمتك.",
      "done": "تم"
    },
    "bulk_edit": {
      "title": "تعديل جماعي للاعبين", "title_selected": "تعديل جماعي ({{count}} محدد)",
      "update_status": "تحديث الحالة", "select_status": "اختر حالة جديدة",
      "update_foot": "تحديث القدم المفضلة", "select_foot": "اختر القدم المفضلة",
      "update_tags": "تحديث الوسوم", "add_tags": "إضافة وسوم", "remove_tags": "إزالة وسوم",
      "updating": "جارٍ التحديث...", "update_button": "تحديث {{count}} لاعب"
    },
    "profile": {
      "title": "الملف الشخصي للاعب", "age_years": "{{age}} سنة", "height_cm": "{{height}} سم",
      "weight_kg": "{{weight}} كجم", "basic_info": "المعلومات الأساسية",
      "recent_perf": "الأداء الأخير", "perf_placeholder": "ستتوفر بيانات الأداء بعد تسجيل المباريات.",
      "match_history": "سجل المباريات", "history_placeholder": "سيظهر سجل المباريات هنا بمجرد اكتمالها."
    },
    "delete_confirm": "هل أنت متأكد أنك تريد حذف هذا اللاعب؟",
    "bulk_delete_confirm": "هل أنت متأكد أنك تريد حذف {{count}} من اللاعبين المختارين؟"
  }
};

const translations = { en, ar };
const LanguageContext = createContext();

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState(localStorage.getItem('abwab-lang') || 'en');
  const messages = translations[language];

  useEffect(() => {
    localStorage.setItem('abwab-lang', language);
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  const t = (key, options = {}) => {
    const keys = key.split('.');
    let result = messages;
    for (const k of keys) {
      result = result?.[k];
      if (result === undefined) return key;
    }
    if (typeof result === 'string') {
      return Object.entries(options).reduce(
        (str, [optKey, optValue]) => str.replace(`{{${optKey}}}`, optValue),
        result
      );
    }
    return result;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);
