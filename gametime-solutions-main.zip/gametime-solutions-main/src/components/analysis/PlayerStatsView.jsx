
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart3, Activity, Clock, Zap, TrendingUp,
  MapPin, Timer, Target, Award, User
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { afterMatchAnalysis } from "@/api/functions";
import { Player } from "@/api/entities";
import { useToast } from "@/components/ui/use-toast";

export default function PlayerStatsView({ jobs }) {
  const [selectedJob, setSelectedJob] = useState(null);
  const [playerStats, setPlayerStats] = useState([]);
  const [players, setPlayers] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (jobs.length > 0 && !selectedJob) {
      setSelectedJob(jobs[0]);
    }
  }, [jobs, selectedJob]);

  const loadPlayerStats = React.useCallback(async () => {
    setIsLoading(true);
    try {
      // Load all players for this academy
      const allPlayers = await Player.list();
      setPlayers(allPlayers);

      // Load stats for each player in this job
      const statsPromises = allPlayers.map(async (player) => {
        try {
          const { data: response, error } = await afterMatchAnalysis({
            action: 'player-stats',
            job_id: selectedJob.external_job_id,
            player_id: player.id
          });

          if (error) {
            return null; // Player didn't participate or no stats
          }

          return {
            player,
            stats: response.player_stats
          };
        } catch (error) {
          return null;
        }
      });

      const results = await Promise.all(statsPromises);
      const validStats = results.filter(result => result !== null);
      setPlayerStats(validStats);
      
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Loading Error", 
        description: "Failed to load player statistics"
      });
    }
    setIsLoading(false);
  }, [selectedJob, toast]); // selectedJob is used in the function, toast is used as well

  useEffect(() => {
    if (selectedJob) {
      loadPlayerStats();
    }
  }, [selectedJob, loadPlayerStats]); // loadPlayerStats is now a dependency as it's memoized with useCallback

  if (jobs.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <BarChart3 className="w-12 h-12 mx-auto mb-4 text-slate-300" />
          <h3 className="text-lg font-medium mb-2">No Finalized Jobs</h3>
          <p className="text-slate-600">
            Complete tracking jobs and player assignments to view statistics
          </p>
        </CardContent>
      </Card>
    );
  }

  const formatDuration = (minutes) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  const formatDistance = (meters) => {
    const km = (meters / 1000).toFixed(2);
    return `${km} km`;
  };

  const formatSpeed = (kmh) => {
    return `${kmh.toFixed(1)} km/h`;
  };

  return (
    <div className="space-y-6">
      {/* Job selector */}
      <Card>
        <CardHeader>
          <CardTitle>Select Match Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 flex-wrap">
            {jobs.map(job => (
              <Button
                key={job.id}
                variant={selectedJob?.id === job.id ? "default" : "outline"}
                onClick={() => setSelectedJob(job)}
                size="sm"
              >
                Job {job.external_job_id.slice(-6)}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {selectedJob && (
        <Tabs defaultValue="overview">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="individual">Individual Stats</TabsTrigger>
            <TabsTrigger value="comparison">Team Comparison</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Summary cards */}
            <div className="grid md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <User className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <div className="text-2xl font-bold">{playerStats.length}</div>
                      <div className="text-sm text-slate-600">Players Tracked</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-green-100 rounded-lg">
                      <MapPin className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <div className="text-2xl font-bold">
                        {formatDistance(
                          playerStats.reduce((sum, p) => sum + (p.stats.total_distance || 0), 0)
                        )}
                      </div>
                      <div className="text-sm text-slate-600">Total Distance</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-orange-100 rounded-lg">
                      <Zap className="w-5 h-5 text-orange-600" />
                    </div>
                    <div>
                      <div className="text-2xl font-bold">
                        {playerStats.length > 0 ? formatSpeed(
                          Math.max(...playerStats.map(p => p.stats.max_speed || 0))
                        ) : '0 km/h'}
                      </div>
                      <div className="text-sm text-slate-600">Top Speed</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-purple-100 rounded-lg">
                      <Timer className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <div className="text-2xl font-bold">
                        {playerStats.length > 0 ? formatDuration(
                          Math.round(playerStats.reduce((sum, p) => sum + (p.stats.minutes_played || 0), 0) / playerStats.length)
                        ) : '0m'}
                      </div>
                      <div className="text-sm text-slate-600">Avg. Play Time</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Distance chart */}
            <Card>
              <CardHeader>
                <CardTitle>Distance Covered by Player</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={playerStats.slice(0, 10)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey={entry => `${entry.player.first_name} ${entry.player.last_name.charAt(0)}.`}
                        fontSize={12}
                      />
                      <YAxis />
                      <Tooltip 
                        formatter={(value) => [formatDistance(value), "Distance"]}
                        labelFormatter={(label) => label}
                      />
                      <Bar dataKey="stats.total_distance" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="individual" className="space-y-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {playerStats.map(({ player, stats }) => (
                <Card key={player.id} className="border-l-4 border-l-blue-500">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">
                      #{player.jersey_number} {player.first_name} {player.last_name}
                    </CardTitle>
                    <Badge variant="outline" className="w-fit">
                      {player.position}
                    </Badge>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <div className="flex items-center gap-1 text-slate-600">
                          <Clock className="w-3 h-3" />
                          Play Time
                        </div>
                        <div className="font-semibold">{formatDuration(stats.minutes_played || 0)}</div>
                      </div>
                      <div>
                        <div className="flex items-center gap-1 text-slate-600">
                          <MapPin className="w-3 h-3" />
                          Distance
                        </div>
                        <div className="font-semibold">{formatDistance(stats.total_distance || 0)}</div>
                      </div>
                      <div>
                        <div className="flex items-center gap-1 text-slate-600">
                          <Zap className="w-3 h-3" />
                          Max Speed
                        </div>
                        <div className="font-semibold">{formatSpeed(stats.max_speed || 0)}</div>
                      </div>
                      <div>
                        <div className="flex items-center gap-1 text-slate-600">
                          <TrendingUp className="w-3 h-3" />
                          Avg Speed
                        </div>
                        <div className="font-semibold">{formatSpeed(stats.avg_speed || 0)}</div>
                      </div>
                      <div>
                        <div className="flex items-center gap-1 text-slate-600">
                          <Target className="w-3 h-3" />
                          Sprints
                        </div>
                        <div className="font-semibold">{stats.sprints || 0}</div>
                      </div>
                      <div>
                        <div className="flex items-center gap-1 text-slate-600">
                          <Activity className="w-3 h-3" />
                          High Intensity
                        </div>
                        <div className="font-semibold">{stats.high_intensity_runs || 0}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="comparison">
            <Card>
              <CardContent className="p-8 text-center">
                <BarChart3 className="w-12 h-12 mx-auto mb-4 text-slate-300" />
                <h3 className="text-lg font-medium mb-2">Team Comparison</h3>
                <p className="text-slate-600">
                  Advanced team comparison features coming soon
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
