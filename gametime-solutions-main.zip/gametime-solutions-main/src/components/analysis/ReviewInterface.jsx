
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Users, Eye, CheckCircle2, ArrowRight, 
  Loader, AlertCircle, User, Target
} from "lucide-react";
import { afterMatchAnalysis } from "@/api/functions";
import { useToast } from "@/components/ui/use-toast";

export default function ReviewInterface({ job, onComplete }) {
  const [situations, setSituations] = useState([]);
  const [teamPlayers, setTeamPlayers] = useState([]);
  const [assignments, setAssignments] = useState({});
  const [currentSituation, setCurrentSituation] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState(null);
  const { toast } = useToast();

  const loadReviewSituations = React.useCallback(async () => {
    setIsLoading(true);
    try {
      const { data: response, error } = await afterMatchAnalysis({
        action: 'review-situations',
        job_id: job.external_job_id,
        team_id: selectedTeam
      });

      if (error) {
        toast({
          variant: "destructive",
          title: "Loading Failed",
          description: error.details || "Failed to load review situations"
        });
        return;
      }

      setSituations(response.situations || []);
      setTeamPlayers(response.team_players || []);
      
      const existingAssignments = {};
      (response.existing_assignments || []).forEach(assignment => {
        const key = `${assignment.situation_id}-${assignment.track_id}`;
        existingAssignments[key] = assignment.player_id;
      });
      setAssignments(existingAssignments);
      
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load review data"
      });
    }
    setIsLoading(false);
  }, [job, selectedTeam, toast]);

  useEffect(() => {
    if (job && selectedTeam) {
      loadReviewSituations();
    }
  }, [job, selectedTeam, loadReviewSituations]);

  const assignTrackToPlayer = (situationId, trackId, playerId) => {
    const key = `${situationId}-${trackId}`;
    setAssignments(prev => ({
      ...prev,
      [key]: playerId
    }));
  };

  const submitAssignments = async () => {
    setIsSubmitting(true);
    try {
      // Convert assignments to API format
      const assignmentArray = Object.entries(assignments).map(([key, playerId]) => {
        const [situationId, trackId] = key.split('-');
        return {
          situation_id: situationId,
          track_id: trackId,
          player_id: playerId
        };
      });

      const { data: response, error } = await afterMatchAnalysis({
        action: 'submit-assignments',
        job_id: job.external_job_id,
        team_id: selectedTeam,
        assignments: assignmentArray
      });

      if (error) {
        toast({
          variant: "destructive", 
          title: "Submission Failed",
          description: error.details || "Failed to submit assignments"
        });
        return;
      }

      toast({
        title: "Assignments Submitted",
        description: response.message || "Player assignments have been saved"
      });

      if (response.both_teams_reviewed) {
        toast({
          title: "Analysis Complete",
          description: "Both teams reviewed. Stats are being finalized."
        });
      }

      onComplete();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to submit assignments"
      });
    }
    setIsSubmitting(false);
  };

  if (!selectedTeam) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Select Team to Review</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <Button
              variant="outline"
              className="h-24"
              onClick={() => setSelectedTeam('home')}
            >
              <div className="text-center">
                <Users className="w-8 h-8 mx-auto mb-2" />
                <div className="font-medium">Home Team</div>
              </div>
            </Button>
            <Button
              variant="outline" 
              className="h-24"
              onClick={() => setSelectedTeam('away')}
            >
              <div className="text-center">
                <Users className="w-8 h-8 mx-auto mb-2" />
                <div className="font-medium">Away Team</div>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Loader className="w-8 h-8 mx-auto mb-4 animate-spin" />
          <p>Loading review situations...</p>
        </CardContent>
      </Card>
    );
  }

  if (situations.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <CheckCircle2 className="w-12 h-12 mx-auto mb-4 text-green-500" />
          <h3 className="text-lg font-medium mb-2">No Review Required</h3>
          <p className="text-slate-600">All tracks have been automatically assigned for this team.</p>
        </CardContent>
      </Card>
    );
  }

  const currentSit = situations[currentSituation];
  const totalAssignments = situations.reduce((total, sit) => total + sit.tracks.length, 0);
  const completedAssignments = Object.keys(assignments).length;

  return (
    <div className="space-y-6">
      {/* Progress */}
      <Card>
        <CardContent className="p-4">
          <div className="flex justify-between items-center mb-2">
            <span className="font-medium">Assignment Progress</span>
            <Badge variant="outline">
              {completedAssignments} / {totalAssignments} assigned
            </Badge>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-slate-600">
              Situation {currentSituation + 1} of {situations.length}
            </span>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentSituation(Math.max(0, currentSituation - 1))}
                disabled={currentSituation === 0}
              >
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentSituation(Math.min(situations.length - 1, currentSituation + 1))}
                disabled={currentSituation === situations.length - 1}
              >
                Next
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Current situation */}
      {currentSit && (
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Frame image */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5" />
                Frame {currentSit.frame_no}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative">
                <img
                  src={currentSit.frame_image_url}
                  alt={`Frame ${currentSit.frame_no}`}
                  className="w-full rounded-lg border"
                />
                {/* Overlay bounding boxes */}
                {currentSit.tracks.map((track, idx) => (
                  <div
                    key={track.track_id}
                    className="absolute border-2 border-red-500"
                    style={{
                      left: `${track.bbox.x}%`,
                      top: `${track.bbox.y}%`,
                      width: `${track.bbox.width}%`,
                      height: `${track.bbox.height}%`
                    }}
                  >
                    <span className="absolute -top-6 -left-1 bg-red-500 text-white px-2 py-1 text-xs rounded">
                      Track {idx + 1}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Track assignments */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5" />
                Assign Players to Tracks
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {currentSit.tracks.map((track, idx) => {
                  const assignmentKey = `${currentSit.id}-${track.track_id}`;
                  const currentAssignment = assignments[assignmentKey];

                  return (
                    <div key={track.track_id} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-medium">Track {idx + 1}</span>
                        {currentAssignment && (
                          <Badge className="bg-green-100 text-green-800">
                            <CheckCircle2 className="w-3 h-3 mr-1" />
                            Assigned
                          </Badge>
                        )}
                      </div>
                      
                      <Select
                        value={currentAssignment || ""}
                        onValueChange={(value) => assignTrackToPlayer(currentSit.id, track.track_id, value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select player..." />
                        </SelectTrigger>
                        <SelectContent>
                          {teamPlayers.map(player => (
                            <SelectItem key={player.id} value={player.id}>
                              <div className="flex items-center gap-2">
                                <User className="w-4 h-4" />
                                #{player.jersey_number} {player.first_name} {player.last_name}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Actions */}
      <Card>
        <CardContent className="p-4">
          <div className="flex justify-between items-center">
            <div className="text-sm text-slate-600">
              {completedAssignments >= totalAssignments ? (
                <span className="text-green-600 font-medium">All tracks assigned! Ready to submit.</span>
              ) : (
                <span>Assign remaining tracks to continue</span>
              )}
            </div>
            
            <Button
              onClick={submitAssignments}
              disabled={isSubmitting || completedAssignments < totalAssignments}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isSubmitting ? (
                <>
                  <Loader className="w-4 h-4 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <ArrowRight className="w-4 h-4 mr-2" />
                  Submit Assignments
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
