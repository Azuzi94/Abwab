import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Clock, Loader, Eye, CheckCircle2, AlertCircle, 
  RefreshCw, Play, Calendar, Users
} from "lucide-react";

export default function TrackingJobCard({ job, match, onRefresh, onSelect }) {
  const getStatusIcon = (status) => {
    const icons = {
      'PENDING': Clock,
      'PROCESSING': Loader,
      'REVIEW_REQUIRED': Eye,
      'FINALIZED': CheckCircle2,
      'FAILED': AlertCircle
    };
    return icons[status] || Clock;
  };

  const getStatusColor = (status) => {
    const colors = {
      'PENDING': 'bg-yellow-100 text-yellow-800',
      'PROCESSING': 'bg-blue-100 text-blue-800',
      'REVIEW_REQUIRED': 'bg-orange-100 text-orange-800',
      'FINALIZED': 'bg-green-100 text-green-800',
      'FAILED': 'bg-red-100 text-red-800'
    };
    return colors[status] || colors['PENDING'];
  };

  const getProgressValue = (status) => {
    const progress = {
      'PENDING': 10,
      'PROCESSING': 60,
      'REVIEW_REQUIRED': 80,
      'FINALIZED': 100,
      'FAILED': 0
    };
    return progress[status] || 0;
  };

  const StatusIcon = getStatusIcon(job.status);

  return (
    <Card className="border-l-4 border-l-blue-500">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h4 className="font-semibold text-lg">
              {match.home_team_name} vs {match.away_team_name}
            </h4>
            <div className="flex items-center gap-4 mt-1 text-sm text-slate-600">
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {new Date(match.match_date).toLocaleDateString()}
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {new Date(job.created_at).toLocaleTimeString()}
              </div>
            </div>
          </div>
          
          <Badge className={getStatusColor(job.status)}>
            <StatusIcon className="w-3 h-3 mr-1" />
            {job.status.replace('_', ' ')}
          </Badge>
        </div>

        {/* Progress bar */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium">Analysis Progress</span>
            <span className="text-sm text-slate-600">{getProgressValue(job.status)}%</span>
          </div>
          <Progress value={getProgressValue(job.status)} className="h-2" />
        </div>

        {/* Job details */}
        {job.external_data && (
          <div className="text-sm text-slate-600 mb-4">
            <p>External Job ID: <code className="bg-slate-100 px-1 rounded">{job.external_job_id}</code></p>
            {job.external_data.estimated_completion && (
              <p>Est. Completion: {new Date(job.external_data.estimated_completion).toLocaleString()}</p>
            )}
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onRefresh}
            disabled={job.status === 'FINALIZED'}
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh Status
          </Button>
          
          {job.status === 'REVIEW_REQUIRED' && (
            <Button
              size="sm"
              onClick={onSelect}
              className="bg-orange-600 hover:bg-orange-700"
            >
              <Eye className="w-4 h-4 mr-2" />
              Review Assignments
            </Button>
          )}
          
          {job.status === 'FINALIZED' && (
            <Button
              size="sm"
              onClick={onSelect}
              className="bg-green-600 hover:bg-green-700"
            >
              <CheckCircle2 className="w-4 h-4 mr-2" />
              View Stats
            </Button>
          )}
        </div>

        {/* Error message */}
        {job.status === 'FAILED' && job.error_message && (
          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded">
            <p className="text-sm text-red-800">{job.error_message}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}